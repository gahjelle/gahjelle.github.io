# Dash
#
# HTML - Innhold
# CSS - Utseende
# JavaScript - Oppførsel

from dash import Dash, html, dcc, Input, Output

app = Dash()
app.layout = html.Div(
    [
        html.H2("Velkommen"),
        html.P("Hva heter du?"),
        dcc.Input(id="navn"), #, value="pannekake"),
        html.P("Hei, navn", id="hilsen"),
    ]
)

@app.callback(
    Output("hilsen", "children"),
    Input("navn", "value"),
    # prevent_initial_call=True,
)
def si_hei(navn):
    if navn is None:
        return "Jeg vet ikke hva du heter"
    return f"Hei, {navn}"

app.run_server(debug=True)
