from dash import Dash, dcc, html, Input, Output
import dash_bootstrap_components as dbc
import plotly.express as px
import pandas as pd
import json

data = px.data.iris()
#data = pd.read_excel("iris.xlsx")


app = Dash(external_stylesheets=[dbc.themes.JOURNAL])
app.layout = html.Div(
    [
        dbc.NavbarSimple(brand="Dashboardkurs", color="dark", dark=True),
        dbc.Select(
            id="x-akse",
            value="sepal_width",
            options=[
                {"label": "Bergbladbredde", "value": "sepal_width"},
                {"label": "Bergbladlengde", "value": "sepal_length"},
                {"label": "Kronbladbredde", "value": "petal_width"},
                {"label": "Kronbladlengde", "value": "petal_length"}]),
        dbc.Select(
            id="y-akse",
            value="sepal_length",
            options=[
                {"label": "Bergbladbredde", "value": "sepal_width"},
                {"label": "Bergbladlengde", "value": "sepal_length"},
                {"label": "Kronbladbredde", "value": "petal_width"},
                {"label": "Kronbladlengde", "value": "petal_length"}]),
        dcc.Graph(id="figur"),
        html.P(id="info")
    ]
)

@app.callback(
    Output("figur", "figure"),
    Input("x-akse", "value"),
    Input("y-akse", "value"),
    # prevent_initial_callback=True,
)
def oppdater_akser(x, y):
    return px.scatter(data, x=x, y=y, color="species")

@app.callback(
    Output("info", "children"),
    Input("figur", "clickData"),
    prevent_initial_callback=True
    )
def vis_info(info):
    return json.dumps(info)

app.run_server(debug=True)
