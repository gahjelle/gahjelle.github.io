def si_hei():
    navn = input("Hva heter du?")
    print(f"Hei, {navn}")

