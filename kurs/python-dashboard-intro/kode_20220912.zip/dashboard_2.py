# Dash
#
# HTML - Innhold
# CSS - Utseende
# JavaScript - Oppførsel

from dash import Dash, html, dcc, Input, Output, State

app = Dash()
app.layout = html.Div(
    [
        html.H2("Velkommen", style={"color": "red", "fontSize": 64}),
        html.P("Hva heter du?"),
        dcc.Input(id="navn"), #, value="pannekake"),
        html.Button("OK", id="ok_knapp"),
        html.P("Hei, navn", id="hilsen"),
    ]
)

@app.callback(
    Output("hilsen", "style"),
    Input("navn", "value"),
    )
def endre_farge(navn):
    if navn == "Geir Arne":
        return {"color": "green"}
    else:
        return {"color": "blue"}


@app.callback(
    Output("hilsen", "children"),
    Input("ok_knapp", "n_clicks"),
    State("navn", "value"),
    # prevent_initial_call=True,
)
def si_hei(antall_klikk, navn):
    if navn is None:
        return "Jeg vet ikke hva du heter"
    return f"Hei, {navn}"



app.run_server(debug=True)
