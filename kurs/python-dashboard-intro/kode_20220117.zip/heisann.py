def si_hei(navn):
    print(f"Heisann {navn}")


si_hei("fra scriptet")
