import dash
from dash import dcc, html

app = dash.Dash()
app.layout = html.Div(
    [
     html.H1("Heisann"),
     html.P(["Velkommen til ", html.B("et kult "), "Dashkurs!"]),
     dcc.Markdown("""
# Heisann

Velkommen til **et kult** Dashkurs med Markdown!
""")
    ]
)
app.run_server(debug=True)
