import dash
import dash_bootstrap_components as dbc
import plotly.express as px
from dash import dcc, html, Input, Output

# import pandas as pd
# pd.read_csv()

data = px.data.iris()

app = dash.Dash(external_stylesheets=[dbc.themes.FLATLY])

app.layout = html.Div(
    [
     dbc.NavbarSimple(brand="IRIS", color="dark", dark=True),
     dbc.Select(id="x-aksen", options=[
             {"label": "Bergbladlengde", "value": "sepal_length"},
             {"label": "Bergbladbredde", "value": "sepal_width"},
             {"label": "Kronbladlengde", "value": "petal_length"},
             {"label": "Kronbladbredde", "value": "petal_width"},
         ]),
     dbc.Select(id="y-aksen", options=[
             {"label": "Bergbladlengde", "value": "sepal_length"},
             {"label": "Bergbladbredde", "value": "sepal_width"},
             {"label": "Kronbladlengde", "value": "petal_length"},
             {"label": "Kronbladbredde", "value": "petal_width"},
         ]),
     dcc.Graph(id="figur"),
     dcc.Markdown(id="info"),
     dcc.Graph(id="linjeplott"),
     ]
    )

@app.callback(
    Output("figur", "figure"),
    Input("x-aksen", "value"),
    Input("y-aksen", "value"),
    prevent_initial_call=True
    )
def oppdater_figur(x_akse, y_akse):
    return px.scatter(
             data,
             x=x_akse,
             y=y_akse,
             color="species")
         

@app.callback(
    Output("info", "children"),
    Input("figur", "hoverData"),
    Input("figur", "clickData"),
    )
def vis_info(hover_data, click_data):
    if click_data is not None:
        markerte_data = click_data
    else:
        markerte_data = hover_data
    
    if markerte_data is not None:
        idx = markerte_data["points"][0]["pointIndex"]
        return str(data.iloc[idx])
    
    
@app.callback(
    Output("linjeplott", "figure"),
    Input("y-aksen", "value"),
    prevent_initial_call=True
    )
def oppdater_linjeplott(y_akse):
    return px.line(
             data,
             y=y_akse,
             color="species")


app.run_server(debug=True)
