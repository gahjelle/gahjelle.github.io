#
# Introduksjon
#
1 + 2
print  # Referanse til funksjon
print(42)  # Utfør funksjon
"Geir Arne"  # Tekst
Geir Arne  # Feil, Python klarer ikke å tolke Geir Arne
Tekna  # Feil, Python kjenner ikke navnet Tekna
navn = "Geir Arne"
navn
f"Hei {navn}"
"Hei {navn}"

#
# Definer egen funksjon
#
def si_hei(navn):
    print(f"Heisann {navn}")

si_hei
si_hei("Geir Arne")
si_hei("Tekna")

# Dersom vi lager en fil som heter heisann.py kan den
# importeres som et bibliotek
import heisann
heisann.si_hei("fra import")

#
# Lister i Python
#
navn = "Geir Arne"
[1, 2, 3]
alle_navn = ["Geir Arne", "Tekna", "Kristin"]

#
# None brukes for å representere null-verdier
#
None
Ingenting  # Feil, None er et spesielt navn i Python

#
# Eksempeldata i Plotly
#
import plotly.express as px
px.data.iris
px.data.iris()
data = px.data.iris()
data
type(data)
data.columns
