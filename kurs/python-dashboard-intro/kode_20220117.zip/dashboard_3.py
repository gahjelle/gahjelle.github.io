import pathlib

import dash
from dash import dcc, html, Input, Output, State

app = dash.Dash()
app.layout = html.Div(
    [
     dcc.Markdown(pathlib.Path("intro.md").read_text(),
                  id="overskrift",
                  style={"color": "red"}),
     dcc.Input(id="navn", value=""
               , placeholder="Hva heter du?"),
     dcc.Input(id="bosted", value=""
               , placeholder="Hvor bor du?"),
     html.Button("OK", id="ok-knapp"),
     html.P(children="Hei", id="hilsen"),
    ]
)

@app.callback(
    Output("hilsen", "children"),
    Input("ok-knapp", "n_clicks"),
    State("navn", "value"),
    State("bosted", "value"),
#    prevent_initial_call=True,
    )
def oppdater_hilsen(_antall_klikk, navn, sted):
    return f"Heisann {navn} i {sted}"


@app.callback(
    Output("hilsen", "style"),
    Input("navn", "value"),
    )
def bytt_farge(navn):
    if navn == "Tekna":
        return {"color": "yellow"}

def skriv_baklengs(navn):
    return navn[::-1]


app.run_server(debug=True)
