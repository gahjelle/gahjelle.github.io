import pathlib

import dash
from dash import dcc, html, Input, Output

app = dash.Dash()
app.layout = html.Div(
    [
     dcc.Markdown(pathlib.Path("intro.md").read_text()),
     dcc.Input(id="navn", value=""
               , placeholder="Hva heter du?"),
     dcc.Input(id="bosted", value=""
               , placeholder="Hvor bor du?"),
     html.P("Hei", id="hilsen"),
    ]
)

@app.callback(
    Output("hilsen", "children"),
    Input("navn", "value"),
    Input("bosted", "value"),
#    prevent_initial_call=True,
    )
def oppdater_hilsen(navn, sted):
    return f"Heisann {navn} i {sted}"


def skriv_baklengs(navn):
    return navn[::-1]


app.run_server(debug=True)
