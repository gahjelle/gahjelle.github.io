import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output, State

app = dash.Dash()
app.layout = html.Div(
    [
        html.H1("Hei alle sammen!", style={"color": "blue"}),
        dcc.Input(id="navn", placeholder="Hva heter du?"),
        dcc.Input(id="bosted", placeholder="Hvor bor du?"),
        html.Button("OK", id="ok"),
        html.P(
            "Her er et avsnitt!",
            id="hilsen",
            style={"fontSize": 20, "marginTop": 50}
        ),
        html.P("Hi there!", id="greeting"),
    ], style={"textAlign": "center", "fontFamily": "verdana"}
)

@app.callback(
    Output("hilsen", "children"),
    Output("greeting", "children"),
    Input("ok", "n_clicks"),
    State("navn", "value"),
    State("bosted", "value"),
)
def si_hei(ok_knapp, navn, sted):
    if navn:
        return f"Hei {navn} fra {sted}", f"Hi {navn} from {sted}"
    else:
        return "Velkommen til kurs!", "Welcome to the tutorial!"


@app.callback(
    Output("hilsen", "style"),
    Input("bosted", "value"),
)
def oppdater_farge(bosted):
    if bosted == "Oslo":
        return {"color": "red"}
    else:
        return {"color": "green"}


app.run_server(debug=True)
