import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output

app = dash.Dash()
app.layout = html.Div(
    [
        html.H1("Hei alle sammen!", style={"color": "blue"}),
        dcc.Input(id="navn", placeholder="Hva heter du?"),
        html.P(
            "Her er et avsnitt!",
            id="hilsen",
            style={"fontSize": 20, "marginTop": 50}
        ),
    ], style={"textAlign": "center", "fontFamily": "verdana"}
)

@app.callback(
    Output("hilsen", "children"),
    Input("navn", "value")
)
def si_hei(navn):
    return f"Hei {navn}"

app.run_server(debug=True)
