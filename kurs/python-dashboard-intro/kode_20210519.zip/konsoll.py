1 + 2
print("Hei verden!")
piint("Hei verden!")
print("Hei vedn!")
navn = "Geir Arne"
tall = 42
print(navn)
print(f"Hei {navn}")
print("Hei {navn}")
print(f"Hei navn")
navn = input("Hva heter du? ")
print(f"Hei {navn}")
runfile('C:/Users/giron/kurs/heisann.py', wdir='C:/Users/giron/kurs')
runfile('C:/Users/giron/kurs/heisann.py', wdir='C:/Users/giron/kurs')
si_hei()
runfile('C:/Users/giron/kurs/heisann.py', wdir='C:/Users/giron/kurs')
def si_hei(navn):
    return f"Hei {navn}"
si_hei("Geir Arne")
import numpy as np
x = np.array([0, 1, 2, 3, 4])
x
x + 1
x * 3
x ** 2
import plotly.express as px
px.data.iris()
data = px.data.iris()
import pandas as pd
pd.read_excel("navn.xlsx")
import plotly.express as px
data = px.data.iris()
type(data)
range(20)
list(range(20))
def befolkning(start, vekstrate, maks, antall_tidssteg=20):
    tidsserie = []
    
    nå = start
    for tidssteg in range(antall_tidssteg):
        tidsserie.append(nå)
        nå = nå + nå * vekstrate
befolkning(100, 0.05, 200, 3)
def befolkning(start, vekstrate, maks, antall_tidssteg=20):
    tidsserie = []
    
    nå = start
    for tidssteg in range(antall_tidssteg):
        tidsserie.append(nå)
        nå = nå + nå * vekstrate
    
    return tidsserie
befolkning(100, 0.05, 200, 3)
def befolkning(start, vekstrate, maks, antall_tidssteg=20):
    tidsserie = []
    
    nå = start
    for tidssteg in range(antall_tidssteg):
        tidsserie.append(nå)
        nå = nå + nå * vekstrate * (1 - nå / maks)
    
    return tidsserie
befolkning(100, 0.05, 200, 3)
history -f konsoll.py
