import dash
import dash_core_components as dcc
import dash_html_components as html
import numpy as np
import plotly.express as px
from dash.dependencies import Input, Output

data = px.data.iris()

app = dash.Dash()

kolonnenavn = [
            {'label': 'Bergbladbredde', 'value': 'sepal_width'},
            {"label": "Kronbladbredde", "value": "petal_width"},
            {'label': 'Bergbladlengde', 'value': 'sepal_length'},
            {"label": "Kronbladlengde", "value": "petal_length"},
        ]

app.layout = html.Div(
    [
        dcc.Dropdown(id="x-aksen", options=kolonnenavn, value="sepal_width"),
        dcc.Dropdown(id="y-aksen", options=kolonnenavn, value="sepal_length"),
        dcc.Graph(id="graf"),
        html.Div(id="info"),
    ]
)


@app.callback(
    Output("graf", "figure"),
    Input("x-aksen", "value"),    
    Input("y-aksen", "value"),    
)
def tegn_graf(x_aksen, y_aksen):
    return px.scatter(
        data, x=x_aksen, y=y_aksen, color="species"
)

@app.callback(
    Output("info", "children"),
    Input("graf", "hoverData")
)
def vis_info(hover_info):
    return str(hover_info)



app.run_server(debug=True)
