import dash
import dash_html_components as html

app = dash.Dash()
app.layout = html.Div(
    [
        html.H1("Hei alle sammen!", style={"color": "blue"}),
        html.P(
            "Her er et avsnitt!",
            style={"fontSize": 20, "marginTop": 50}
        ),
    ], style={"textAlign": "center", "fontFamily": "verdana"}
)

app.run_server(debug=True)
