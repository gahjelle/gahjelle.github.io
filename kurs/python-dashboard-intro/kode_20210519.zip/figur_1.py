import dash
import dash_core_components as dcc
import dash_html_components as html
import numpy as np
import plotly.express as px
from dash.dependencies import Input, Output


app = dash.Dash()
app.layout = html.Div(
    [
        dcc.Slider(id="eksponent", min=0, max=4, step=0.5, value=2),
        dcc.Graph(id="graf"),
    ]
)


@app.callback(
    Output("graf", "figure"),
    Input("eksponent", "value")    
)
def tegn_graf(eksponent):
    x = np.array([0, 1, 2, 3, 4])
    return px.scatter(x=x, y=x ** eksponent)

app.run_server(debug=True)
