import dash
import dash_core_components as dcc
import dash_html_components as html
import numpy as np
import plotly.express as px
from dash.dependencies import Input, Output

data = px.data.iris()

app = dash.Dash()
app.layout = html.Div(
    [
        dcc.Dropdown(id="x-aksen", options=[
            {'label': 'Bergbladbredde', 'value': 'sepal_width'},
            {"label": "Kronbladbredde", "value": "petal_width"},
        ], value="sepal_width"),
        dcc.Graph(id="graf"),
    ]
)


@app.callback(
    Output("graf", "figure"),
    Input("x-aksen", "value")    
)
def tegn_graf(x_aksen):
    return px.scatter(
        data, x=x_aksen, y="sepal_length", color="species"
)

app.run_server(debug=True)
