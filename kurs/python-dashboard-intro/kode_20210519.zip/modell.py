import dash
import dash_core_components as dcc
import dash_html_components as html
import numpy as np
import plotly.express as px
from dash.dependencies import Input, Output


app = dash.Dash()
app.layout = html.Div(
    [
        html.H1("Befolkningsmodell", className="overskrift"),
        dcc.Slider(id="start", min=0, max=1000, value=100,
                   marks={0: {"label": "0"}, 500: {"label": "500"},
                          1000: {"label": "1000", "style": {"color": "red"}}}),
        dcc.Graph(id="befolkning_over_tid"),    
    ]
)


@app.callback(
    Output("befolkning_over_tid", "figure"),
    Input("start", "value")
)
def befolkningsgraf(start):
    data = {"befolkning": befolkning(start, 0.05, 500, 100)}
    return px.line(data, range_y=(0, 1000))


def befolkning(start, vekstrate, maks, antall_tidssteg=20):
    tidsserie = []
    
    nå = start
    for tidssteg in range(antall_tidssteg):
        tidsserie.append(nå)
        nå = nå + nå * vekstrate * (1 - nå / maks)

    return tidsserie

app.run_server(debug=True)