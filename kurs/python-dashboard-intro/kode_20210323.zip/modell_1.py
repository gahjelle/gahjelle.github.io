import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input
import plotly.express as px

app = dash.Dash()

app.layout = html.Div(
    [
        dcc.Slider(id="start-slider", min=0, max=1000, step=10, value=100),
        dcc.Graph(id="befolkning")     
    ]
)

@app.callback(
    Output("befolkning", "figure"),
    Input("start-slider", "value"),
)
def oppdater_befolkningsgraf(start):
    data = befolkning(start, vekstrate=0.05, maks=500)
    return px.line(data)


def befolkning(start, vekstrate, maks, antall_tidssteg=20):
    tidsserie = []

    nå = start
    for _ in range(antall_tidssteg):
        tidsserie.append(nå)
        nå = nå + nå * vekstrate * (1 - nå / maks)

    return tidsserie




app.run_server(debug=True)
