import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input
import plotly.express as px

app = dash.Dash()

app.layout = html.Div(
    [
        html.H1("Befolkningsvekst", className="header", style={"color": "white"}),
        dcc.Slider(id="start-slider", min=0, max=1000, step=10, value=100,
                   marks={0: {"label": "0"}, 500: {"label": "500"}, 1000: {"label": "1000"}}
                   ),
        dcc.RadioItems(id="vekstrate", options=[
                {"label": "1%", "value": 0.01},
                {"label": "5%", "value": 0.05},
                {"label": "25%", "value": 0.25},
            ], value=0.05),
        dcc.Graph(id="befolkning")     
    ]
)

@app.callback(
    Output("befolkning", "figure"),
    Input("start-slider", "value"),
    Input("vekstrate", "value"),
)
def oppdater_befolkningsgraf(start, vekstrate):
    data = {"befolkning": befolkning(start, vekstrate=vekstrate, maks=500,
                                     antall_tidssteg=100)}
    return px.line(data, range_y=(0, 1000))


def befolkning(start, vekstrate, maks, antall_tidssteg=20):
    tidsserie = []

    nå = start
    for _ in range(antall_tidssteg):
        tidsserie.append(nå)
        nå = nå + nå * vekstrate * (1 - nå / maks)

    return tidsserie




app.run_server(debug=True)
