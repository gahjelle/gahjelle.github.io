import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input


app = dash.Dash()

app.layout = html.Div(
    [
        dcc.Markdown(
            """
            # Hei Markdown!
            
            Hallo **Geir Arne**
        """
        ),
        dcc.Input(id="navn", placeholder="Hva heter du?"),
        html.Div("Hei!", id="hilsen"),
    ]
)


@app.callback(
    Output("hilsen", "children"), Input("navn", "value"),
)
def si_hei(navn):
    if navn:
        return f"Heisann {navn}!"
    else:
        return f"Hei på deg!"


app.run_server(debug=True)
