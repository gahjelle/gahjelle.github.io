import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input
import plotly.express as px

data = px.data.iris()

app = dash.Dash()

aksenavn = [
    {"label": "Bergbladbredde", "value": "sepal_width"},
    {"label": "Bergbladlengde", "value": "sepal_length"},
    {"label": "Kronbladbredde", "value": "petal_width"},
    {"label": "Kronbladlengde", "value": "petal_length"},
]

app.layout = html.Div(
    [
        dcc.Dropdown(id="x_aksen", options=aksenavn, value="sepal_width"),
        dcc.Dropdown(id="y_aksen", options=aksenavn, value="sepal_length"),
        dcc.Graph(id="figur"),
    ]
)


@app.callback(
    Output("figur", "figure"), Input("x_aksen", "value"), Input("y_aksen", "value"),
)
def oppdater_figur(x, y):
    return px.scatter(data, x=x, y=y, color="species")


app.run_server(debug=True)
