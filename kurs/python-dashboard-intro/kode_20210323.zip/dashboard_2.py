import dash
import dash_core_components as dcc
import dash_html_components as html


app = dash.Dash()

app.layout = html.Div(
    [
        dcc.Markdown(
            """
            # Hei Markdown!
            
            Hallo **Geir Arne**
        """
        ),
        #        html.H1(
        #            "Hei Dash!",
        #            style={"color": "red", "textAlign": "center"}
        #        ),
        #        html.P(["Hallo ", html.B("Geir Arne")], style={"fontSize": 20, "marginLeft": 100}),
    ]
)

app.run_server(debug=True)
