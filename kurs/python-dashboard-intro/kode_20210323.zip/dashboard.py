import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input, State


app = dash.Dash()

app.layout = html.Div(
    [
        dcc.Markdown(
            """
            # Hei Markdown!
            
            Hallo **Geir Arne**
        """,
            id="overskrift",
        ),
        dcc.Input(id="navn", placeholder="Hva heter du?"),
        dcc.Input(id="bosted", placeholder="Hvor bor du?"),
        html.Button("OK", id="send_inn"),
        html.Div("Hei!", id="hilsen"),
        html.Div("Hi!", id="greeting"),
    ]
)


@app.callback(
    Output("hilsen", "children"),
    Output("greeting", "children"),
    Input("send_inn", "n_clicks"),
    State("navn", "value"),
    State("bosted", "value"),
)
def si_hei(_, navn, sted):
    if navn:
        return (f"Heisann {navn} fra {sted}!", f"Hello {navn} from {sted}")
    else:
        return f"Hei på deg!", "Hi there!"


@app.callback(
    Output("overskrift", "style"), Input("bosted", "value"),
)
def oppdater_farge(sted):
    if sted == "Oslo":
        return {"color": "blue"}
    else:
        return {"color": "red"}


app.run_server(debug=True)
