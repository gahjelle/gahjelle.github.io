#
# Introduksjon til Python
#
1 + 1
tall = 42       # Definer variabel
tall            # Bruk variabel
print()         # Med paranteser kaller vi en funksjon
print           # Uten paranteser referer vi til en funksjon

# Definer en egen funksjon
def si_hei(noens_navn):
    print(f"Heisann {noens_navn}")

si_hei                 # Referer til funksjonen
si_hei("Geir Arne")    # Kall funksjonen


#
# Introduksjon til Dash
#
import dash     # import laster inn biblioteket og gjør det tilgjengelig
dash            # Referer til biblioteket

# Bruk av fnutter/anførselstegn:  " og ' er ekvivalente, men må komme i par
"value"
'value'
# Neste linje er FEIL: " kan ikke avsluttes av '
"value'
"It's raining"
# Neste linje er FEIL: ' kan ikke brukes direkte innenfor en tekst avgrenset med '
'It's raining'
'It\'s raining'   # Bakoverskråstrek foran ' markerer at ' ikke avgrenser teksten (men det er oftest enklere å bruke " i disse tilfellene)

# None brukes ofte i Dash for å markere at verdier ikke har blitt satt
None

# Neste linje er FEIL: Kan ikke bruke to argumenter som begge heter _
def test(_, _, a):
    return a + 1

# Bruk _1, _2 osv i stedet om du har flere "throw-away"-argumenter
def test(_1, _2, a):
    return a + 1

#
# Plott og figurer
#
import plotly.express as px
px.data.iris()
data = px.data.iris()
type(data)

data.columns
[{"label": col, "value": col} for col in data.columns]

#
# Modellering
#

# Enkel modell for beolkningsvekst
def befolkning(start, vekstrate, maks, antall_tidssteg=20):
    tidsserie = []

    nå = start
    for _ in range(antall_tidssteg):
        tidsserie.append(nå)
        nå = nå + nå * vekstrate * (1 - nå / maks)

    return tidsserie

befolkning(100, 0.02)
befolkning(100, 0.10, 1000)
befolkning(100, 0.10, 1000, 1000)

# Tips for å "rydde opp" koden: Black (https://black.readthedocs.io/) kan
# automatisk formattere koden slik at den blir konsistent og lesbar
#
# Tips fra Yann van Crombrugge: [Nyere versjoner av] Spyder støtter black.
# Det finner du under Preferences -> Completion and linting -> Code formatting 
# -> tick "Autoformat files on save" og velg "Black" som formatting provider

