def si_hei(noens_navn):
    print(f"Heisann {noens_navn}")


navn = input("Hva heter du? ")
si_hei(navn)
