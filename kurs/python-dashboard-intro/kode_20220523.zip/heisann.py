# Nettside
#
# - Innhold:   HTML
# - Utseende:  CSS
# - Oppførsel: JavaScript

navn = input("Hva heter du? ")
print(f"Hei {navn}")
