import dash_bootstrap_components as dbc
from dash import Dash, html, dcc
import plotly.express as px

app = Dash(external_stylesheets=[dbc.themes.JOURNAL])
iris = px.data.iris()

app.layout = html.Div(
    [
        dbc.NavbarSimple(brand="Dashboardkurs", color="dark", dark=True),
        dcc.Graph(figure=px.line(y=[7, 6, 1, 4, 1, 8, 0, 6])),
    ]
)

app.run_server(debug=True)
