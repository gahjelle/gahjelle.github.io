from dash import Dash, dcc, html, Input, Output, State

app = Dash()

app.layout = html.Div(
    [
        html.H1("Velkommen", className="pannekake", style={"fontSize": 64}),
        html.P("Hva heter du?"),
        dcc.Input(id="les_navn", value=""),
        html.Button("OK", id="ok_navn"),
        html.P("Pannekake", id="hilsen"),
    ]
)


@app.callback(
    Output("hilsen", "children"),
    State("les_navn", "value"),
    Input("ok_navn", "n_clicks"),
    prevent_initial_call=True,
)
def si_heisann(navn, _antall_klikk):
    if not navn:
        return "Jeg vet ikke hva du heter!"
    else:
        return f"Heisann {navn}"


@app.callback(
    Output("hilsen", "style"),
    Input("les_navn", "value"),
)
def endre_farge(navn):
    if navn == "Geir Arne":
        return {"color": "yellow"}
    else:
        return {"color": "black"}


app.run_server(debug=True)
