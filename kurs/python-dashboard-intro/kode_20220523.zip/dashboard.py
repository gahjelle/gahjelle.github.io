import dash_bootstrap_components as dbc
from dash import Dash, dcc, html, Input, Output, State

app = Dash(external_stylesheets=[dbc.themes.SANDSTONE])

app.layout = html.Div(
    [
        dbc.NavbarSimple(brand="Velkommen til Dashkurs", color="dark", dark=True),
        dcc.Markdown(
            """
                 # Velkommen
                 
                 Dette er et **dashboard** som _vi_ lager på Teknakurs
                 """
        ),
        dbc.Label("Hva heter du?"),
        dbc.Input(id="les_navn", value="", placeholder="Hva heter du?"),
        dbc.Button("OK", id="ok_navn", color="success"),
        html.P("Pannekake", id="hilsen"),
        html.P("", id="greeting"),
    ]
)


@app.callback(
    Output("hilsen", "children"),
    Output("greeting", "children"),
    State("les_navn", "value"),
    Input("ok_navn", "n_clicks"),
    prevent_initial_call=True,
)
def si_heisann(navn, _antall_klikk):
    if not navn:
        return "Jeg vet ikke hva du heter!", "I don't know your name!"
    else:
        return f"Heisann {navn}", f"Hi there, {navn}"


@app.callback(
    Output("hilsen", "style"),
    Input("les_navn", "value"),
)
def endre_farge(navn):
    if navn == "Geir Arne":
        return {"color": "yellow"}
    else:
        return {"color": "black"}


app.run_server(debug=True)
