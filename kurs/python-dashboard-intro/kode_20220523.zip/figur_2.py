import dash_bootstrap_components as dbc
from dash import Dash, html, dcc, Input, Output
import plotly.express as px

app = Dash(external_stylesheets=[dbc.themes.JOURNAL])
iris = px.data.iris()
iris_columns = [
    {"label": "Bergbladbredde", "value": "sepal_width"},
    {"label": "Bergbladlengde", "value": "sepal_length"},
    {"label": "Kronbladbredde", "value": "petal_width"},
    {"label": "Kronbladlengde", "value": "petal_length"},
]

app.layout = html.Div(
    [
        dbc.NavbarSimple(brand="Dashboardkurs", color="dark", dark=True),
        dbc.Select(id="x-axis", value="sepal_length", options=iris_columns),
        dbc.Select(id="y-axis", value="sepal_width", options=iris_columns),
        dcc.Graph(id="figur"),
    ]
)


@app.callback(
    Output("figur", "figure"),
    Input("x-axis", "value"),
    Input("y-axis", "value"),
)
def update_axis(x, y):
    return px.scatter(iris, x=x, y=y, color="species")


app.run_server(debug=True)
