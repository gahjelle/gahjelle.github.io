from dash import Dash, dcc, html, Input, Output

app = Dash()

app.layout = html.Div(
    [
        html.H1("Velkommen"),
        html.P("Hva heter du?"),
        dcc.Input(id="les_navn", value=""),
        html.P("Pannekake", id="hilsen"),
    ]
)


@app.callback(
    Output("hilsen", "children"),
    Input("les_navn", "value"),
    # prevent_initial_call=True,
)
def si_heisann(navn):
    if not navn:
        return "Jeg vet ikke hva du heter!"
    else:
        return f"Heisann {navn}"


app.run_server(debug=True)
