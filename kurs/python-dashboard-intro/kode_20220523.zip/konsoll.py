1 + 2

navn = "Geir Arne"
print(f"Hei {navn}")
f"{navn.upper()}"
f"{21 + 21}"

navn = input("Hva heter du? ")
print(f"Hei {navn}")

import plotly.express as px

px.data
px.data.carshare()
type(px.data.carshare())

iris = px.data.iris()
iris
iris.columns
iris.to_csv("iris.csv")

import pandas as pd

pd.read_csv("iris.csv")
pd.read_csv("iris.csv", sep=";")  # norsk
