import pandas as pd

inntekter = pd.read_excel(
    "https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx",
    header=1,
    na_values="-",
    names=["Category", "2019", "2020", "2021"],
)

# Oppgave: Regn ut gjennomsnittet for hver kategori over de tre årene
(
    inntekter
    .set_index("Category")
    .mean(axis="columns")
    .reset_index()
    .rename(columns={0: "Average Income"})
)

# Tidy Data Analysis
#
# Hver rad er EN observasjon
# Hver kolonne er en variabel
# Hver celle er atomisk

tidy_inntekter = inntekter.melt(
    id_vars="Category",
    value_vars=["2019", "2020", "2021"],
    value_name="income",
    var_name="year",
)
(
    tidy_inntekter
    .groupby("Category", as_index=False)
    .agg(average_income=("income", "mean"))
)

