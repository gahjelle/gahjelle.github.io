import pandas as pd

schedule = pd.read_csv(
    "https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/schedule.csv",
)

for_print = schedule.pivot_table(
    index="timestamp",
    columns="room",
    values="title",
    aggfunc="first",
)

# OPPGAVE: Bruk .melt for å konvertere for_print tilbake til tidy-form
(
    for_print
    .reset_index()
    .melt(
        id_vars="timestamp",
        value_vars=[5, 6],
        value_name="title",
        var_name="room"
    )
    .sort_values(by=["timestamp", "room"])
    .reset_index(drop=True)
)