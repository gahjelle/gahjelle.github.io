import pandas as pd

songs = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_songs.csv")
ranks = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_ranks.csv")

# Analysesteg
#
# 1. Filtrering av data: df[], .query(), .loc[]
# 2. Sammenslåing av data: .merge(), .concat()
# 3. Aggregering av data: .groupby(), .agg()
# 4. Transformering av data: .assign(), lambda
# 5. Sortering av data: .sort_values()

def minimum_is_1(song_ranks):
    return song_ranks.min() == 1
    
def song_score(billboard):
    return billboard["num_weeks"] * (100 - billboard["average_position"])

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=("rank", minimum_is_1),
    )
    .assign(
        one=1,
        score=lambda billboard: billboard["num_weeks"] * (100 - billboard["average_position"]),
        score2=song_score,
    )
    .sort_values(by="score", ascending=False)
)
