# Data

- https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx
- https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/schedule.csv
- https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_songs.csv
- https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_ranks.csv


# Oppgraderer pandas:

python -m pip install -U pandas
