#
# Introeksempel
#
1 + 2
import pandas as pd
pd.__version__

pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx")
pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx", header=1)
inntekter = pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx", header=1)
inntekter.info()
inntekter = pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx", header=1, na_values="-")
inntekter.info()
inntekter = pd.read_excel(
    "https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx",
    header=1,
    na_values="-",
    names=["Category", "2019", "2020", "2021"],
)
inntekter.columns

# Oppgave: Regn ut gjennomsnittet for hver kategori over de tre årene
inntekter
inntekter.mean()
inntekter.set_index("Category")
inntekter.set_index("Category").mean()
inntekter.set_index("Category").mean(axis="columns")
inntekter.set_index("Category").mean(axis="columns").reset_index()
inntekter.set_index("Category").mean(axis="columns").reset_index().rename(columns={0: "Average Income"})

# Method chaining i stedet for å stadig lage nye variabelnavn, eller 
# overskrive eksisterende navn (inntekter = inntekter.set_index("Category"))
inntekt_med_kategoriindeks = inntekter.set_index("Category")
inntekt_med_kategoriindeks.mean()

# Bruk .melt() for å konvertere til tidy data
inntekter.melt(id_vars="Category")
inntekter.melt(id_vars="Category", value_vars=["2019", "2020"])
inntekter.melt(id_vars="Category", value_vars=["2019", "2020", "2021"])
inntekter.melt(id_vars="Category", value_vars=["2019", "2020", "2021"], value_name="income")
inntekter.melt(id_vars="Category", value_vars=["2019", "2020", "2021"], value_name="income", var_name="year")
tidy_inntekter = inntekter.melt(
    id_vars="Category",
    value_vars=["2019", "2020", "2021"],
    value_name="income",
    var_name="year",
)

# Med tidy data kan vi gjøre en groupby:
tidy_inntekter.groupby("Category")
tidy_inntekter.groupby("Category").agg(average_income=("income", "mean"))

# Bruk .loc[] for å hente ut spesifikke rader basert på indeks
inntekter
inntekter.loc[4]
inntekter.loc[4:6]
inntekter.set_index("Category")
inntekter.set_index("Category").loc["Tilskudd og overføringer"]

# Tommelfingerregel: Hold dataene i dataframe'n, ikke i indeksen
(
    tidy_inntekter
    .groupby("Category", as_index=False)
    .agg(average_income=("income", "mean"))
)

# PAUSE TIL 10:27

#
# Pivotering av data for presentasjon
#
schedule = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/schedule.csv")
schedule.pivot_table()  # Feil, .pivot_table() trenger litt informasjon
schedule
schedule.pivot_table(index="timestamp", columns="room", values="title")  # Feil, .pivot_table klarer ikke å regne gjennomsnitt av tekstkolonner
schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first")
schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first").reset_index()

# Gi nytt navn til kolonnene
schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first").columns
schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first").rename(columns={5: "Room 5", 6: "Room 6"})
for_print = schedule.pivot_table(
    index="timestamp",
    columns="room",
    values="title",
    aggfunc="first",
)
for_print.columns
for_print.columns = ["Room 5", "Room 6"]  # Overskriv kolonnenavn
for_print.columns
for_print

# Oppgave: Bruk .melt() for å konvertere schedule tilbake til tidy form
for_print = schedule.pivot_table(
    index="timestamp",
    columns="room",
    values="title",
    aggfunc="first",
)
for_print.melt()

#
# Topp 100-liste
#
songs = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_songs.csv")
ranks = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_ranks.csv")
songs

# Hent ut kolonne eller kolonner
songs["artist"]
songs[["artist", "track"]]
songs[["track", "artist"]]
songs.drop(columns="id")
songs.drop(columns=["id", "time"])

# Filtrer rader
songs["genre"] == "Rock"
songs.loc[songs["genre"] == "Rock"]
songs[songs["genre"] == "Rock"]
songs.query("genre == 'Rock'")

songs["artist"].str.startswith("M")
songs[songs["artist"].str.startswith("M")]
songs.loc[songs["artist"].str.startswith("M")]
songs.query("artist.str.startswith('M')")

# Bruk ` (backtick) for å angi kolonnenavn med mellomrom i .query()
songs.rename(columns={"artist": "artist name"})
songs.rename(columns={"artist": "artist name"}).query("artist name == 'Santana'")  # Feil, tolker ikke artist name som ett navn
songs.rename(columns={"artist": "artist name"}).query("`artist name` == 'Santana'")

# Bedre løsning: gjør en omnavning når data leses slik at ingen kolonnenavn
# inneholder mellomrom og andre spesialtegn utover understrek (_)
songs.rename(columns={"artist": "artist name"}).rename(columns={"artist name": "artist_name"})
songs.rename(columns={"artist": "artist name"}).rename(columns={"artist name": "artist_name"}).query("artist_name == 'Santana'")

# Kombiner spørringer
songs.query("artist.str.startswith('M')")
songs.query("artist.str.startswith('M') and genre == 'Rock'")
songs.query("artist.str.startswith('M') or genre == 'Rock'")
songs.query("artist.str.startswith('M')").query("genre == 'Rock'")

# Databaselignende sammenslåinger
pd.merge(songs, ranks)
billboard = pd.merge(songs, ranks)
songs.merge(ranks)

songs.rename(columns={"id": "song_id"})
songs.rename(columns={"id": "song_id"}).merge(ranks)  # Feil, ingen felles kolonner å merge' på
songs.rename(columns={"id": "song_id"}).merge(ranks, left_on="song_id", right_on="id")

songs.merge(ranks, on="id")  # Fint å være eksplisitt uansett :)
songs.query("artist.str.startswith('M')")
songs.query("artist.str.startswith('M')").merge(ranks, on="id")
songs.query("artist.str.startswith('M')").merge(ranks, on="id", how="inner")
songs.query("artist.str.startswith('M')").merge(ranks, on="id", how="outer")
songs.query("artist.str.startswith('M')").merge(ranks, on="id", how="left")
songs.query("artist.str.startswith('M')").merge(ranks, on="id", how="right")
songs.query("artist.str.startswith('M')").merge(ranks, on="id", how="right", indicator=True)
songs.query("artist.str.startswith('M')").merge(ranks, on="id", how="outer", indicator=True)

# pd.concat() kan legge flere tabeller etter hverandre
pd.concat([schedule, schedule])

# PAUSE til 12:00
pd.set_option("display.max_columns", 10)

# Aggregering av data:  groupby() -> agg()
songs.merge(ranks, on="id")
songs.merge(ranks, on="id").groupby("id", as_index=False)
songs.merge(ranks, on="id").groupby("id", as_index=False).agg(average_position=("rank", "mean"))
songs.merge(ranks, on="id").groupby("id", as_index=False).agg(average_position=("rank", "mean"), artist=("artist", "first"))
songs.merge(ranks, on="id").groupby(["id", "artist", "track"], as_index=False).agg(average_position=("rank", "mean"))
songs.merge(ranks, on="id").groupby(["id", "artist", "track"], as_index=False).agg(average_position=("rank", "mean"), first_entered=("date", "first"))
songs.merge(ranks, on="id").groupby(["id", "artist", "track"], as_index=False).agg(average_position=("rank", "mean"), first_entered=("date", "min"))

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
    )
)

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
    )
)

# Bruk egne funksjoner til aggregering
(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=("rank", "min == 1"),  # Feil, min == 1 er ikke en funksjon
    )
)

# Definer egne funksjoner i Python
def si_hei():
    print("Hei")
si_hei()

def si_hei(navn):
    print(f"Hei, {navn}")
si_hei()  # Feil, si_hei() krever nå et navn
si_hei("Geir Arne")

def minimum_is_1():
    ...
minimum_is_1()

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=("rank", minimum_is_1),  # Feil, minimum_is_1 får tilsendt ett argument
    )
)

def minimum_is_1(arg):
    print(arg)  # Skriv ut hva som blir tilsendt for å få innblikk i hvordan agg-funksjonen virker

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=("rank", minimum_is_1),
    )
)

def minimum_is_1(song_ranks):
    return song_ranks.min() == 1

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=("rank", minimum_is_1),
    )
)

minimum_is_1(billboard["rank"])  # Under panseret kaller .agg() på minimum_is_1() for hver gruppe av sanger

def minimum_is_1(song_ranks, date):  # Feil, for å brukes som en funksjon i agg må minimum_is_1() ta nøyaktig ett argument
    return song_ranks.min() == 1

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=(["rank", "date"], minimum_is_1),  # Feil, kan ikke sende inn to kolonner til agg
    )
)

def minimum_is_1(song_ranks):
    return song_ranks.min() == 1

# Legg til nye kolonner (transformer data) med .assign()
billboard
billboard.assign(first_letter=billboard["artist"].str[0])
billboard.assign(first_letter=billboard["artist"].str[0], one=1)

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=("rank", minimum_is_1),
    )
    .assign(
        one=1,
        score=billboard["num_weeks"] * (100 - billboard["average_position"]),  # Feil, billboard har ikke disse kolonnene
    )
)

# .assign() kan bruke en funksjon for å generere/transformere data
# lambda definerer en "bruk-og-kast" funksjon
(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=("rank", minimum_is_1),
    )
    .assign(
        one=1,
        score=lambda billboard: billboard["num_weeks"] * (100 - billboard["average_position"]),
    )
)

28 * (100 - 14.82)  # Sammenlign utregning av score for en sang

# Navngitte funksjoner vs lambda (anonyme) funksjoner
def double(x):
    return 2 * x
double(4)

lambda x: 2 * x
(lambda x: 2 * x)(4)

# .assign() kan også bruke navngitte funksjoner
def song_score(billboard):
    return billboard["num_weeks"] * (100 - billboard["average_position"])

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=("rank", minimum_is_1),
    )
    .assign(
        one=1,
        score=lambda billboard: billboard["num_weeks"] * (100 - billboard["average_position"]),
        score2=song_score,
    )
)

# Sortering av data
billboard
billboard.sort_values(by="rank")
billboard.sort_values(by=["rank", "date"])  # Sorter på to kolonner
billboard.sort_values(by="rank", ascending=False)  # Sorter synkende
billboard.sort_values(by=["rank", "date"], ascending=False)
billboard.sort_values(by=["rank", "date"], ascending=[False, True])  # Sorter rank-kolonne synkende, deretter date-kolonne stigende
billboard.sort_values("artist")  # matchbox twenty blir sortert sist pga liten forbokstav
billboard.sort_values("artist", key=lambda artist: artist.str.lower())  # Konverter alle artistnavn til små bokstaver før de sammenlignes

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),  # eller "min"
        num_weeks=("id", "count"),
        reached_no_1=("rank", minimum_is_1),
    )
    .assign(
        one=1,
        score=lambda billboard: billboard["num_weeks"] * (100 - billboard["average_position"]),
        score2=song_score,
    )
    .sort_values(by="score", ascending=False)
)
