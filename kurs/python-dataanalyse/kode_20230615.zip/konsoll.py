#
# Introeksempel
#
1 + 2
import pandas as pd
pd.__version__

pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/master/data/driftsinntekter-2021.xlsx")
pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/master/data/driftsinntekter-2021.xlsx", header=1, na_values="-")
data = pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/master/data/driftsinntekter-2021.xlsx", header=1, na_values="-")

data.mean()  # Feil eller advarsel: kan ikke ta snitt av tekstkolonne
data

data.set_index("Category")
data.set_index("Category").mean()
data.set_index("Category").mean(axis="columns")
data.set_index("Category").mean(axis="columns").reset_index()
data.set_index("Category").mean(axis="columns").reset_index().rename(columns={0: "average_income"})

data.melt(id_vars="Category")
data.melt(id_vars="Category", var_name="year", value_name="income")
tidy = data.melt(id_vars="Category", var_name="year", value_name="income")

tidy.groupby("Category")
tidy.groupby("Category").agg(average_income=("income", "mean"))
tidy.groupby("Category", as_index=False).agg(average_income=("income", "mean"))

#
# Pivotering av tidy data for presentasjon
#
pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/schedule.csv")
pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/schedule.csv", parse_dates=["timestamp"])
schedule = pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/schedule.csv", parse_dates=["timestamp"])
schedule.pivot_table?
schedule.pivot_table(index="timestamp", columns="room", values="title")  # Feil, kan ikke aggregere tekst
schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first")
for_print = schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first")

schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first").reset_index()
for_print = schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first").reset_index()

data.info()
data.set_index("Category").info()

#
# Bruk .loc for å plukke ut rader
schedule
schedule.loc[0]
schedule.loc[2:5]
schedule.set_index("timestamp")
schedule.set_index("timestamp").loc[0]  # Feil, er ikke lenger en telleindex
schedule.set_index("timestamp").loc["2022-08-29"]
schedule.set_index("timestamp")
schedule.set_index("timestamp").loc["2022"]
schedule.set_index("timestamp").info()

# Oppgave: Konverter for_print tilbake til ryddig form
for_print
for_print.melt?
for_print.melt(id_vars="timestamp")
for_print.melt(id_vars="timestamp").columns
for_print.melt(id_vars="timestamp", var_name="pancake").columns
for_print.melt(id_vars="timestamp", var_name="pancake", value_name="title")
for_print.melt(id_vars=["timestamp", "HS118"], var_name="pancake", value_name="title")
wrong = for_print.melt(id_vars=["timestamp", "HS118"], var_name="pancake", value_name="title")
wrong = for_print.melt(id_vars=["timestamp"], var_name="room", value_name="title", value_vars=["HS118", "HS120"])
wrong = for_print.melt(id_vars=["timestamp"], var_name="room", value_name="title", value_vars=["HS120"])
for_print.melt(id_vars=["timestamp"], var_name="room", value_name="title", value_vars=["HS118", "HS120"])

# Oversikt over innlesingsfunksjoner i pandas
[function for function in dir(pd) if function.startswith("read_")]
pd.read_table?
pd.read_html?

# Eksempel på resampling av tidsrekkedata
for_print
for_print.resample?
for_print.set_index("timestamp")
for_print.set_index("timestamp").resample("H")
for_print.set_index("timestamp").resample("H").first()
hourly = for_print.set_index("timestamp").resample("H").first()
hourly = for_print.set_index("timestamp").resample("H").bfill()

#
# Filtrering av data
#
songs = pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_songs.csv")
ranks = pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_ranks.csv", parse_dates=["date"])
songs.loc[1]
songs.columns
songs.loc[:]
songs.loc[2:8]
songs.loc[:, ["artist", "track", "time"]]
schedule.loc[:, ["timestamp", "title"]]
schedule.drop(columns=["room"])
schedule = schedule.drop(columns=["room"])
schedule = schedule.drop(columns=["room"])  # Feil, schedule har ikke lenger "room"-kolonne

schedule = pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/schedule.csv", parse_dates=["timestamp"])
schedule.set_index("timestamp")
schedule.set_index("timestamp").loc["2022-08-30"]

schedule.query("room == 'HS118'")
room = "HS118"
schedule.query("room == room")
schedule.query("room == @room")
schedule.room
schedule["room"]
schedule["room"] == room
schedule["room"] == "HS118"
schedule.loc[schedule["room"] == "HS118"]
schedule.query("room == 'HS118'")

schedule.query("timestamp.dt.hour == 10")
dir(schedule.timestamp.dt)
schedule.timestamp.dt.day
schedule.query("timestamp.dt.day == 30")
schedule.query("timestamp.dt.day == 30 and timestamp.dt.hour < 12")

schedule.query("title.str.startswith('Intro')")
dir(schedule.title.str)
schedule.query("title.str.contains('scikit')")

songs.query("artist == 'Jay-Z'")
songs.query("artist == 'Jay-Z'").loc[:, ["track", "time"]]
ranks
ranks.info()
ranks.select_dtypes?
ranks.select_dtypes(include="int")
ranks.select_dtypes(include="number")
schedule.select_dtypes(include="object")
schedule.select_dtypes(exclude="datetime")

ranks.sum()
ranks.select_dtypes(include="number")
ranks.select_dtypes(include="number").sum()
ranks.select_dtypes(include="number").mean()

#
# Aggregering
#
ranks.groupby("id").size()
ranks
ranks.groupby("id").size().sort_values()
songs.query("id == 46")
ranks.groupby("id").agg(average_position=("rank", "mean"))

(
    ranks
    .groupby("id")
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
    )
)

(
    ranks
    .groupby("id", as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
    )
)

(
    ranks
    .groupby("id", as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
    )
)

(
    ranks
    .groupby("id", as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        reached_no_1=("rank", contains_1)  # Feil, contains_1 er ikke definert enda
    )
)

def contains_1():
    print("hei")
contains_1()
contains_1

(
    ranks
    .groupby("id", as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        reached_no_1=("rank", contains_1)  # Feil, contains_1 har feil antall parametre
    )
)

def contains_1(param):
    print(param)
contains_1()  # Feil, contains_1 må kalles med en parameter
contains_1("hei")

(
    ranks
    .groupby("id", as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        reached_no_1=("rank", contains_1)
    )
)

def contains_1(column):
    return column.min() == 1

(
    ranks
    .groupby("id", as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        reached_no_1=("rank", contains_1)
    )
)

# Grupper kan også loopes over med en for-løkke
ranks.groupby("id")
for navn in ["Geir Arne", "Andre", "Jan Arne", "Lars"]:
    print(navn)

for info in ranks.groupby("id"):
    print(info)

for song_id, info in ranks.groupby("id"):
    print(info)

for song_id, info in ranks.groupby("id"):
    print(song_id, info.date.min())

#
# pd.merge for databaseaktige joins
#
songs
ranks
pd.merge?
pd.merge(songs, ranks)
billboard = pd.merge(songs, ranks)

ranks.rename(columns={"id": "song_id"})
ranks = ranks.rename(columns={"id": "song_id"})
pd.merge(songs, ranks)  # Feil, songs og ranks har ikke lenger en felles kolonne
pd.merge(songs, ranks, left_on="id", right_on="song_id")

songs.merge(ranks, left_on="id", right_on="song_id")
songs.query("artist.str.startswith('D')").merge(ranks, left_on="id", right_on="song_id")

#
# pd.concat for å legge dataframes etter hverandre
#
pd.concat?
url = "https://data.urbansharing.com/oslobysykkel.no/trips/v1/2023/{month:02d}.csv"
url.format(month=1)
url.format(month=11)
for month in [1, 2, 3, 4, 5]:
    print(url.format(month=month))

datasets = []
for month in [1, 2, 3, 4, 5]:
    datasets.append(pd.read_csv(url.format(month=month)))
datasets

pd.concat(datasets)
data = pd.concat(datasets)

data.loc[123]
pd.concat(datasets).reset_index()
pd.concat(datasets).reset_index(drop=True)

#
# Transformasjoner, legg til nye kolonner basert på eksisterende data
#
schedule
schedule.timestamp.dt.date
schedule.assign(date=123)
schedule.assign(date=schedule.timestamp.dt.date)

schedule.assign(
    date=schedule.timestamp.dt.date,
    time=schedule.timestamp.dt.time,
)

schedule.assign(
    date=schedule.timestamp.dt.date,
    time=schedule.timestamp.dt.time,
    sum=123,
)

data = schedule.assign(
    date=schedule.timestamp.dt.date,
    time=schedule.timestamp.dt.time,
    sum=123,
)

data.sum
data["sum"]
data.sum()
dir(data)
len(dir(data))

(
    billboard
    .groupby("id", as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        reached_no_1=("rank", contains_1)
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        reached_no_1=("rank", contains_1)
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        num_weeks=("id", "size"),
        reached_no_1=("rank", contains_1)
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        num_weeks=("id", "size"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        score=billboard["num_weeks"] * (100 - billboard["average_position"])    
    )  # Feil, billboard har ikke disse kolonnene
)

lambda x: x*2
double = lambda x: x*2
double(3)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        num_weeks=("id", "size"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        score=lambda df: df["num_weeks"] * (100 - df["average_position"])    
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        num_weeks=("id", "size"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        score=lambda df: df["num_weeks"] * (100 - df["average_position"]),
        double_score=lambda df: df["score"] * 2,
    )
)

#
# Sortering av data
#
billboard
billboard.sort_index()
billboard.sort_index(ascending=False)
billboard.sort_values(by="artist")
songs.sort_values(by="artist")
songs.sort_values?
songs.sort_values(by="artist", key=lambda artist: artist.str.lower())

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        num_weeks=("id", "size"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        score=lambda df: df["num_weeks"] * (100 - df["average_position"]),
        double_score=lambda df: df["score"] * 2,
    )
    .sort_values(by=["num_weeks", "average_position"])
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        num_weeks=("id", "size"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        score=lambda df: df["num_weeks"] * (100 - df["average_position"]),
        double_score=lambda df: df["score"] * 2,
    )
    .sort_values(by=["num_weeks", "average_position"])
    .loc[:, ["track", "num_weeks", "average_position"]]
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        num_weeks=("id", "size"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        score=lambda df: df["num_weeks"] * (100 - df["average_position"]),
        double_score=lambda df: df["score"] * 2,
    )
    .sort_values(by=["num_weeks", "average_position"], ascending=False)
    .loc[:, ["track", "num_weeks", "average_position"]]
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        num_weeks=("id", "size"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        score=lambda df: df["num_weeks"] * (100 - df["average_position"]),
        double_score=lambda df: df["score"] * 2,
    )
    .sort_values(
        by=["num_weeks", "average_position"],
        ascending=[False, True],
    )
    .loc[:, ["track", "num_weeks", "average_position"]]
)
