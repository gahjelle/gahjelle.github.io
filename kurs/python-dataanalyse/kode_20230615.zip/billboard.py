import pandas as pd

songs = pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_songs.csv")
ranks = pd.read_csv(
    "https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_ranks.csv",
    parse_dates=["date"],
)

def contains_1(column):
    return column.min() == 1

(
    ranks
    .groupby("id", as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        reached_no_1=("rank", contains_1)
    )
)

billboard = pd.merge(songs, ranks)
(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        highest_position=("rank", "min"),
        first_entered=("date", "first"),
        num_weeks=("id", "size"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        score=lambda df: df["num_weeks"] * (100 - df["average_position"]),
        double_score=lambda df: df["score"] * 2,
    )
    .sort_values(
        by=["num_weeks", "average_position"],
        ascending=[False, True],
    )
).loc[:, ["track", "num_weeks", "average_position"]]
