import pandas as pd

schedule = pd.read_csv(
    "https://github.com/gahjelle/pandas-introduction/raw/main/data/schedule.csv",
    parse_dates=["timestamp"],
)

schedule.pivot_table(
    index="timestamp",
    columns="room",
    values="title",
    aggfunc="first",
)

schedule.assign(
    date=schedule["timestamp"].dt.date,
    time=schedule["timestamp"].dt.time,
)