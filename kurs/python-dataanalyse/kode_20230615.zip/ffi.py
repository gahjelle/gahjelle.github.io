import pandas as pd

data = pd.read_excel(
    "https://github.com/auroravoje/intro_data_processing/raw/master/data/driftsinntekter-2021.xlsx",
    header=1,
    na_values="-",
    engine="openpyxl",
)

(
    data
    .set_index("Category")
    .mean(axis="columns")
    .reset_index()
    .rename(columns={0: "average_income"})
)

tidy = data.melt(
    id_vars="Category",
    var_name="year",
    value_name="income",
)

(
    tidy
    .groupby("Category", as_index=False)
    .agg(average_income=("income", "mean"))
)