import pandas as pd

url = "https://data.urbansharing.com/oslobysykkel.no/trips/v1/2023/{month:02d}.csv"

datasets = []
for month in [1, 2, 3, 4, 5]:
    datasets.append(pd.read_csv(url.format(month=month)))
    
data = pd.concat(datasets).reset_index(drop=True)
