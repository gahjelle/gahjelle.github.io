#
# Introduksjon
#

1 + 2
import pandas as pd
pd.__version__

pandas  # FEIL: Navnet pandas er ikke tilgjengelig
import pandas

pandas
pd

pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx")
dir(pd)  # Se på hvilke read_* funksjoner som finnes i pandas

# Les inn en Excelfil, angi opsjoner for riktige kolonnenavn og manglende verdier
inntekter = pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx")
inntekter = pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx", header=1)
inntekter = pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx", header=1, na_values="-")

dir(inntekter)  # Se hvilke metoder som finnes på en DataFrame
inntekter.info()  # Se informasjon om en DataFrame

# Regn ut gjennomsnitt over kolonner i pandas
inntekter.mean()  # FEIL: Kan ikke ta gjennomsnitt over tekstkolonner
inntekter.set_index("Category")
inntekter
inntekter.set_index("Category").info()
inntekter.set_index("Category").mean()
inntekter.set_index("Category").mean(axis="columns")
inntekter.set_index("Category").mean(axis="columns").reset_index()
inntekter.set_index("Category").mean(axis="columns").reset_index().rename(columns={0: "Average income"})

# PAUSE TIL 10:25

#
# Tidy data
#
inntekter
inntekter.melt(id_vars="Category")
inntekter.melt(id_vars="Category", value_name="Income", var_name="Year")
tidy_inntekter = inntekter.melt(id_vars="Category", value_name="Income", var_name="Year")

# Regn ut gjennomsnitt på en tidy DataFrame
tidy_inntekter.groupby("Category")
tidy_inntekter.groupby("Category").agg(average_income=("Income", "mean"))
tidy_inntekter.groupby("Category", as_index=False).agg(average_income=("Income", "mean"))

# .melt() brukes for å konvertere en DataFrame til en tidy form
inntekter
inntekter.melt(id_vars="Category")
inntekter.melt(id_vars=["Category", 2019])
inntekter.melt(id_vars=["Category"])
inntekter.melt(id_vars=["Category"], value_vars=[2019, 2020])

# Gjør om en tidy schedule til en "timeplan" hvor hver rad viser alle foredrag for hvert klokkeslett
schedule = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/schedule.csv")
schedule.pivot_table(index="timestamp", columns="room", values="title")  # Feil: aggfunc må angis om verdiene er tekst
schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first")
for_print = schedule.pivot_table(index="timestamp", columns="room", values="title", aggfunc="first")

# Oppgave: Bruk .melt() på for_print for å gjøre den tidy igjen
for_print.reset_index()
for_print.reset_index().melt(id_vars="timestamp")
for_print.reset_index().melt(id_vars="timestamp", value_name="title")
for_print.reset_index().melt(id_vars="timestamp", value_vars=[5, 6], value_name="title")
for_print.reset_index().melt(id_vars="timestamp", value_vars=[5, 6], var_name="room", value_name="title")

# LUNSJPAUSE TIL 12:00

# Billboard-data
songs = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_songs.csv")
ranks = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_ranks.csv")

# Bruk .info() for å sjekke minnebruk for hver DataFrame
songs.info()
ranks.info()
inntekter.info()
tidy_inntekter.info()

# Bruk .columns for å se kolonnenavn på en DataFrame 
songs
songs.columns
for_print.columns

#
# Filtrer kolonner
#
songs["artist"]  # En kolonne som en Series
songs[["artist"]]  # En kolonne som en DataFrame
songs[["artist", "title"]]

columns_to_keep = ["artist", "track", "genre"]
songs[columns_to_keep]

songs.drop(columns=["id"])

#
# Filtrer rader med .query() eller .loc[]
#

# Alternativ 1: .query()
songs.query("genre == 'Rock'")

# Alternativ 2: .loc[]
songs["genre"] == "Rock"
songs.loc[songs["genre"] == "Rock"]
songs[songs["genre"] == "Rock"]  # Fungerer, men kan gi dårligere feilmeldinger

# Alternativ 3: .loc[] med en navngitt maske
is_rock = songs["genre"] == "Rock"
songs.loc[is_rock]

# Finn låtnavn som begynner på M, tre alternativer
songs.query("track.str.startswith('M')")
songs.loc[songs["track"].str.startswith("M")]
starts_with_m = songs["track"].str.startswith("M")
songs.loc[starts_with_m]

# Kombinere flere spørringer
songs.query("genre == 'Rock' and track.str.startswith('M')")
songs.query("genre == 'Rock' or track.str.startswith('M')")

songs.loc[songs["genre"] == "Rock" and songs["track"].str.startswith("M")]  # FEIL: and kaller på ren Python og kan ikke brukes i pandas
songs.loc[songs["genre"] == "Rock" & songs["track"].str.startswith("M")]  # FEIL: Trenger parenteser for å samle hver spørring
songs.loc[(songs["genre"] == "Rock") & (songs["track"].str.startswith("M"))]

songs.loc[is_rock & starts_with_m]  # & brukes som og (and)
songs.loc[is_rock | starts_with_m]  # | brukes som eller (or)

songs.loc[0]

#
# Slå sammen tabeller
#
songs.merge(ranks)  # Virker, men bedre å være eksplisitt på hva some skjer
ranks.rename(columns={"id": "song_id"})
songs.merge(ranks.rename(columns={"id": "song_id"}))  # FEIL: ingen kolonner med matchende navn
songs.merge(ranks.rename(columns={"id": "song_id"}), left_on="id", right_on="song_id")
songs.merge(ranks, left_on="id", right_on="id")
songs.merge(ranks, on="id")  # Bra å være eksplisitt

rock_songs = songs[is_rock]
top_ten = ranks[ranks["rank"] <= 10]

rock_songs.merge(top_ten, on="id")
rock_songs.merge(top_ten, on="id", how="inner")
rock_songs.merge(top_ten, on="id", how="left")
rock_songs.merge(top_ten, on="id", how="right")
rock_songs.merge(top_ten, on="id", how="outer")

rock_songs.merge(top_ten, how="cross")

songs.set_index("id")
songs.set_index("id").merge(ranks, left_index=True, right_on="id")  # Slå sammen en DataFrame på indeks og en på en kolonne

# indicator legger til en kolonne som rapporterer om venstre, høyre, eller begge DataFrames ble brukt i en join
rock_songs.merge(top_ten, on="id", how="outer", indicator=True)
rock_songs.merge(top_ten, on="id", how="outer", indicator=True).query("_merge == 'right_only'")

#
# Slå sammen tabeller vertikalt, f.eks. månedlige datasett fra forskjellige måneder
#
pd.concat([schedule, schedule])

# PAUSE TIL 13:40
rock_songs.merge(top_ten, on="id")
pd.concat([schedule, schedule])
dir(songs)
pd.merge(songs, ranks, on="id")

#
# Aggregering av data
#
songs.merge(ranks, on="id").groupby("id").agg(best_position=("rank", "min"))

(
    songs
    .merge(ranks, on="id")
    .groupby("id")
    .agg(
        artist=("artist", "first"),
        best_position=("rank", "min"),
    )
)

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"])
    .agg(
        best_position=("rank", "min"),
    )
)

(
    songs
    .merge(ranks, on="id")
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
    )
)

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
    )
)

# Vis flere kolonner i det interaktive konsollet
pd.set_option("display.max_columns", 10)

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        first_entered("date", "first"),
    )
)

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
    )
)

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
    )
)

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", "min == 1"),  # FEIL: kan ikke angi "kompliserte" funksjoner på denne måten
    )
)

# Definer egne funksjoner
def si_hei():
    return "Hei alle sammen"

si_hei
si_hei()

def si_hei(navn):
    return f"Hei {navn}"
si_hei()  # FEIL: si_hei() behøver nå en parameter (navn)
si_hei("Geir Arne")
si_hei("Runar")

def minimum_is_1():
    ...   # Tre prikker ... er gyldig Pythonsyntaks og kan brukes for å angi kode du skal fylle inn senere

minimum_is_1()

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
)

def minimum_is_1(parameter):
    print(parameter)

minimum_is_1("Geir Arne")
minimum_is_1(42)

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
)

def minimum_is_1(ranks):
    return ranks.min() == 1

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
)

billboard = (
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
)

#
# Transformer data: legg til nye kolonner
#
billboard.assign(one=1)
billboard.assign(one=1, first_letter=billboard["artist"].str[0])
billboard.assign(one=1, first_letter=billboard["artist"].str[0], score=billboard["num_weeks"] * (100 - billboard["average_position"]))

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
    .assign(
        one=1
    )
)

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
    .assign(
        one=1,
        first_letter=lambda data: data["artist"].str[0],
    )
)

lambda tall: tall + 1
(lambda tall: tall + 1)(42)

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
    .assign(
        one=1,
        first_letter=lambda data: data["artist"].str[0],
        score=lambda data: data["num_weeks"] * (100 - data["average_position"])
    )
)

def calculate_score(data):
    return data["num_weeks"] * (100 - data["average_position"])

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
    .assign(
        one=1,
        first_letter=lambda data: data["artist"].str[0],
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        score_2=calculate_score,
    )
)

#
# Sorter data
#
billboard.sort_values(by="best_position")
billboard.sort_values(by=["best_position", "num_weeks"])
billboard.sort_values(by=["best_position", "num_weeks", "first_entered"])
billboard.sort_values(by=["num_weeks", "best_position", "first_entered"])
billboard.sort_values(by="num_weeks")

billboard.sort_values(by="num_weeks", ascending=False)
billboard.sort_values(by=["best_position", "num_weeks"], ascending=[True, False])

billboard.sort_values(by="artist")
billboard.sort_values(by="artist", key=lambda artists: artists.str.lower())

(
    billboard
    .assign(score=calculate_score)
    .sort_values(by="score", ascending=False)
)

#
# Presenter data
#
dir(billboard)  # Se på .to_* metoder du kan bruke forå lagre DataFrame'n i forskjellige formater
billboard.to_excel("billboard.xlsx")
billboard.plot()

#
# Lag plott
#
import plotly.express as px
import pathlib

fig = px.histogram(billboard, x="average_position")
fig.show()  # Virker kun i Jupyter og lignende

fig.to_html()  # Skriver HTML til skjermen
pathlib.Path("songs.html").write_text(fig.to_html())  # Skriv HTML til en fil som kan åpnes i nettleseren


fig.to_image()  # Skriver PNG bytes til skjermen
pathlib.Path("songs.png").write_bytes(fig.to_image())  # Skriv PNG til en fil
