import pandas as pd

inntekter = pd.read_excel(
    "https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx",
    header=1,
    na_values="-"
)

snitt_inntekt = (
   inntekter
   .set_index("Category")
   .mean(axis="columns")
   .reset_index()
   .rename(columns={0: "Average income"})
)

"""
Tidy Data

- Hver rad er EN observasjon
- Hver kolonne er en variabel
- Hver celle er atomisk
"""

tidy_inntekter = inntekter.melt(
    id_vars="Category",
    value_name="Income",
    var_name="Year"
)
(
    tidy_inntekter
    .groupby("Category", as_index=False)
    .agg(average_income=("Income", "mean"))
)


"""
Tidy Analysis

1. Omstrukturer data til tidy: .melt()
2. Filtrering av data: [], .loc[], .query()
3. Slå sammen data: .merge(), concat()
4. Aggregering av data: .groupby(), .agg()
5. Transformering av data: .assign()
6. Sortering av data: .sort_values()
7. Presentasjon av data: .pivot_table(), .to_excel()

"""

songs = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_songs.csv")
ranks = pd.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_ranks.csv")

songs.query("genre == 'Rock'")
songs.loc[songs["genre"] == "Rock"]
is_rock = songs["genre"] == "Rock"
songs.loc[is_rock]

songs.query("track.str.startswith('M')")
songs.loc[songs["track"].str.startswith("M")]
starts_with_m = songs["track"].str.startswith("M")
songs.loc[starts_with_m]

songs.query("genre == 'Rock' and track.str.startswith('M')")
songs.loc[(songs["genre"] == "Rock") & (songs["track"].str.startswith("M"))]
songs.loc[is_rock & starts_with_m]

songs.query("genre == 'Rock' or track.str.startswith('M')")
songs.loc[is_rock | starts_with_m]

# Slå sammen data
songs.merge(
    ranks.rename(columns={"id": "song_id"}),
    left_on="id",
    right_on="song_id"
)
songs.merge(ranks, left_on="id", right_on="id")
songs.merge(ranks, on="id")
pd.merge(songs, ranks, on="id")
songs.set_index("id").merge(ranks, left_index=True, right_on="id")

rock_songs = songs[is_rock]
top_ten = ranks[ranks["rank"] <= 10]
rock_songs.merge(top_ten, on="id", how="inner")
rock_songs.merge(top_ten, on="id", how="left")
rock_songs.merge(top_ten, on="id", how="right")
rock_songs.merge(top_ten, on="id", how="outer")
rock_songs.merge(top_ten, how="cross")  # Kartesisk produkt
rock_songs.merge(top_ten, on="id", how="outer", indicator=True)

# pd.concat([schedule, schedule])

def minimum_is_1(ranks):
    return ranks.min() == 1

billboard = (
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        # artist=("artist", "first"),
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
)

billboard.assign(
    one=1,
    first_letter=billboard["artist"].str[0],
    score=billboard["num_weeks"] * (100 - billboard["average_position"])
)

def calculate_score(data):
    return data["num_weeks"] * (100 - data["average_position"])

(
    songs
    .merge(ranks, on="id")
    .groupby(
        ["id", "artist", "track"],
        as_index=False
    )
    .agg(
        # artist=("artist", "first"),
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
        num_weeks=("id", "count"),
        reached_num_1=("rank", minimum_is_1),
    )
    .assign(
        one=1,
        first_letter=lambda data: data["artist"].str[0],
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        score_2=calculate_score,
    )
)

billboard.sort_values(by="best_position")
billboard.sort_values(by=["best_position", "num_weeks"])
billboard.sort_values(by=["best_position", "num_weeks", "first_entered"])
billboard.sort_values(by=["num_weeks", "best_position"])

billboard.sort_values(by="num_weeks")
billboard.sort_values(by="num_weeks", ascending=False)
billboard.sort_values(
    by=["best_position", "num_weeks"],
    ascending=[True, False]
)

billboard.sort_values(by="artist")
billboard.sort_values(
    by="artist",
    key=lambda artists: artists.str.lower()
)

(
    billboard
    .assign(score=calculate_score)
    .sort_values(by="score", ascending=False)
)