import pandas

inntekter = pandas.read_excel(
    "https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx",
    header=1,
    na_values="-",
)

# Regn ut gjennomsnittlig inntekt for hver kategori på tvers av årene
(
    inntekter
    .set_index("Category")
    .mean(axis="columns")
    .reset_index()
    .rename(columns={0: "Average income"})
)

# Tidy data - Hadley Wickham
#
# En dataframe er tidy hvis:
#     1. Hver rad er EN observasjon
#     2. Hver kolonne er en variabel (statistikk)
#     3. Hver celle er atomisk

# Trykk Ctrl+I for å vise hjelp i Help-panelet i Spyder

tidy_inntekter = inntekter.melt(
    id_vars="Category",
    value_vars=[2019, 2020, 2021],
    var_name="Year",
    value_name="Income",
)

# Regn ut gjennomsnittlig inntekt for hver kategori på tvers av årene
(
    tidy_inntekter
    .fillna({"Income": 0})
    .groupby("Category", as_index=False)
    .agg(average_income=("Income", "mean"))
)

# Tidy Analysis
#
# 1. Omstrukturere data til tidy: .melt()
# 2. Filtrere data: [], .loc[], .query()
# 3. Slå sammen data: .merge(), .concat()
# 4. Aggregere data: .groupby(), .agg()
# 5. Transformere data: .assign()
# 6. Sortere data: .sort_values() 
# 7. Omstrukturere data til presentasjon: .pivot_table(), .to_excel() 

songs = pandas.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_songs.csv")
ranks = pandas.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_ranks.csv")

billboard = pandas.merge(songs, ranks, on="id")

(
    billboard
    .groupby("id", as_index=False)
    .agg(
        artist=("artist", "first"),
        best_position=("rank", "min"),
        
    )
)

def minimum_is_1(values):
    return min(values) == 1
 
top_list = (
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entered=("date", "first"),
        average_position=("rank", "mean"),
        num_weeks=("date", len),
        reached_num_1=("rank", minimum_is_1),
    )
)


def calculate_score(data):
    return data["num_weeks"] * (100 - data["average_position"])

def lowercase(values):
    return values.str.lower()

def length(values):
    return values.str.len()

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by="artist", key=lowercase)
)




adresse = """
   Geir Arne Hjelle
Fauchaldsgate 11
   0365 Oslo    """
