
def calculate_score(data):
    return data["num_weeks"] * (100 - data["average_position"])

def lowercase(values):
    return values.str.lower()

def length(values):
    return values.str.len()

