#
# Intro: Les inntektstabell fra Excel
#
1 + 2
import pandas
pandas.read_excel(
    "https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx"
)
inntekter = pandas.read_excel(
    "https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx"
)
inntekter.info()
inntekter = pandas.read_excel(
    "https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx",
    header=1,
)
inntekter.info()
inntekter = pandas.read_excel(
    "https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx",
    header=1,
    na_values="-",
)
inntekter.info()

#
# Motiverende eksempel: regn ut gjennomsnittlig inntekt for hver kategori
#
inntekter.mean()
inntekter.set_index("Category")
inntekter.set_index("Category").info()
inntekter.set_index("Category").mean()
inntekter.set_index("Category").mean(axis="columns")
inntekter.set_index("Category").mean(axis="columns").reset_index()
inntekter.set_index("Category").mean(axis="columns").reset_index().rename(columns={0: "Average income"})

#
# Konverter til Tidy Data
#
inntekter.melt(id_vars="Category")
inntekter.melt(id_vars="Category", value_vars="2019")  # Feil, kolonnenavnet er ikke en tekststreng
inntekter.melt(id_vars="Category", value_vars=2019)
inntekter.melt(id_vars="Category", value_vars=[2019, 2020, 2021])
inntekter.melt(id_vars="Category", value_vars=[2019, 2020, 2021], var_name="Year")
inntekter.melt(
    id_vars="Category",
    value_vars=[2019, 2020, 2021],
    var_name="Year",
    value_name="Income",
)
tidy_inntekter = inntekter.melt(
    id_vars="Category",
    value_vars=[2019, 2020, 2021],
    var_name="Year",
    value_name="Income",
)

#
# Regn ut gjennomsnitt av data på tidy form
#
tidy_inntekter.groupby("Category")
tidy_inntekter.groupby("Category").agg(average_income=("Income", "mean"))

(
    tidy_inntekter
    .groupby("Category", as_index=False)
    .agg(average_income=("Income", "mean"))
)

(
    tidy_inntekter
    .groupby("Category", as_index=False)
    .agg(average income=("Income", "mean"))
)

(
    tidy_inntekter
    .fillna({"Income": 0})
    .groupby("Category", as_index=False)
    .agg(average_income=("Income", "mean"))
)

tidy_inntekter.fillna({"Income": 0})

# Oversikt over funksjoner og metoder i pandas
dir(pandas)
len(dir(pandas))
len(dir(inntekter))

# Pause 10:30

#
# Tidy dataanalyse: Billboardsanger
#
songs = pandas.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_songs.csv")
ranks = pandas.read_csv("https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_ranks.csv")
songs.info()
ranks.info()
pandas.to_datetime(ranks["date"])

#
# Filtrering: plukk ut kolonner og rader
#
songs["artist"]
songs[["artist", "genre", "track"]]
columns_to_keep = ["artist", "genre", "track"]
songs[columns_to_keep]
songs.drop(columns=["time"])
songs.drop(columns=["time", "id"])

songs.query("genre == 'Rock'")
songs["genre"] == "Rock"

songs.loc[songs["genre"] == "Rock"]
songs.query("genre == 'Rock' and artist.str.startswith('M')")
songs.query("genre == 'Rock' and artist.str.startswith('Ma')")
songs.query("genre == 'Rock' or artist.str.startswith('M')")

songs.artist.str.len()
songs.assign(group=songs.artist.str.len())
songs.assign(group=songs.artist.str.len()).groupby("group").agg(num_songs=("group", "count"))

songs.query("genre == 'Rock' and artist.str.startswith('Ma')")
songs.loc[songs["genre"] == "Rock"]
songs.loc[(songs["genre"] == "Rock") & (songs["artist"].str.startswith("M"))]
songs["genre"] == "Rock"
is_rock = songs["genre"] == "Rock"
starts_with_m = songs["artist"].str.startswith("M")
songs.loc[is_rock]
songs.loc[is_rock & starts_with_m]
songs.loc[is_rock | starts_with_m]

#
# Slå sammen tabeller
#
pandas.merge(songs, ranks)  # Bedre å være eksplisitt
pandas.merge(songs, ranks, on="id")
ranks.info()
ranks.astype({"id": str})
ranks.astype({"id": str}).info()
pandas.merge(songs, ranks.astype({"id": str}), on="id")  # Feil: Kan ikke slå sammen kolonner med forskjellige typer
ranks.rename({"id": "song_id"})
ranks.rename(columns={"id": "song_id"})
pandas.merge(songs, ranks.rename(columns={"id": "song_id"}))  # Feil: Må angi hvilke kolonner som skal matches
pandas.merge(songs, ranks.rename(columns={"id": "song_id"}), on="id")
pandas.merge(songs, ranks.rename(columns={"id": "song_id"}), left_on="id", right_on="song_id")
billboard = pandas.merge(songs, ranks, on="id")

pandas.merge(songs, ranks, on="id", how="inner")
pandas.merge(songs, ranks, on="id", how="left")
rock_songs = songs[is_rock]
top_ten = ranks.loc[ranks["rank"] <= 10]
top_ten

pandas.merge(rock_songs, top_ten, on="id")
pandas.merge(rock_songs, top_ten, on="id", how="inner")
pandas.merge(rock_songs, top_ten, on="id", how="outer")
pandas.merge(rock_songs, top_ten, on="id", how="left")
pandas.merge(rock_songs, top_ten, on="id", how="right")
pandas.merge(rock_songs, top_ten, on="id", how="cross")  # Feil: Cross-join matcher alle rader, ikke angi kolonner
pandas.merge(rock_songs, top_ten, how="cross")

pandas.concat([tidy_inntekter, tidy_inntekter])
billboard = pandas.merge(songs, ranks, on="id")

#
# Aggregering: Hent ut innsikt av grupperte data
#
billboard.groupby("id", as_index=False).agg(best_position=("rank", "min"))

(
    billboard
    .groupby("id", as_index=False)
    .agg(
        artist=("artist", "first"),
        best_position=("rank", "min"),    
    )
)

(
    billboard
    .groupby(["id", "artist"], as_index=False)
    .agg(
        best_position=("rank", "min"),    
    )
)

(
    billboard
    .groupby("artist", as_index=False)
    .agg(
        best_position=("rank", "min"),    
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
    )
)

pandas.set_option("display.max_columns", 10)  # Se flere kolonner på skjermen

(

    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),    
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entered=("date", "first"),    
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entered=("date", "first"),
        average_position=("rank", "mean"),    
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entered=("date", "first"),
        average_position=("rank", mean),  # Feil: mean er ikke en global funksjon i Python    
    )
)

# Bruk funksjoner i aggregeringen
len("Geir Arne")
len([1, 2, 3])
len(billboard)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entered=("date", "first"),
        average_position=("rank", "mean"),
        num_weeks=("date", len),
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entered=("date", "first"),
        average_position=("rank", "mean"),
        num_weeks=("date", len),
        reached_num_1=("rank", "min == 1"),  # Feil, kan ikke bruke uttrykk som funksjoner
    )
)

# Definer egne funksjoner
def si_hei(navn):
    return f"Hei, {navn}!"
si_hei("Jonathan")
si_hei("Olha")

def minimum_is_1(values):
    return min(values) == 1

minimum_is_1([3, 1, 6, 9])
minimum_is_1([3, 2, 6, 9])

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entered=("date", "first"),
        average_position=("rank", "mean"),
        num_weeks=("date", len),
        reached_num_1=("rank", minimum_is_1),
    )
)

# Pause til 12:00

#
# Rensk tekst
#
adresse = """
   Geir Arne Hjelle
Fauchaldsgate 11
   0365 Oslo    """
adresse
adresse.strip()
adresse.replace("\n", " ")
adresse.replace("\n", " ").strip()
adresse.replace("\n", " ").replace("a", "")

# Regular expressions
import re
re.sub(r"\s+", " ", adresse)
re.sub(r"\s+", " ", adresse).strip()
re.sub(r"[^a-zA-Z]", " ", adresse).strip()

adresse = """
   Geir Arne Blåbær Hjelle
Fauchaldsgate 11
   0365 Oslo    """

re.sub(r"[^a-zA-Z]", " ", adresse).strip()
re.sub(r"[^a-zA-ZæøåÆÅØ]", " ", adresse).strip()

#
# Avansert håndtering av manglende verdier
#
tidy_inntekter
tidy_inntekter.groupby("Category").agg("Income", "mean")
tidy_inntekter.groupby("Category").agg(average_income=("Income", "mean"))
tidy_inntekter.groupby("Category").transform(average_income=("Income", "mean"))
tidy_inntekter.groupby("Category").transform("mean")
tidy_inntekter.groupby("Category")["Income"].transform("mean")
tidy_inntekter.fillna({"Income": tidy_inntekter.groupby("Category")["Income"].transform("mean")})

#
# Transformering av kolonner
#
top_list = (
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entered=("date", "first"),
        average_position=("rank", "mean"),
        num_weeks=("date", len),
        reached_num_1=("rank", minimum_is_1),
    )
)

top_list.assign(one=1)
top_list["artist"].str[0]
top_list["num_weeks"] * top_list["average_position"]
top_list.assign(first_letter=top_list["artist"].str[0])

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=top_list["num_weeks"] * (100 - top_list["average_position"]),
    )
 )

def calculate_score(data):
    return data["num_weeks"] * (100 - data["average_position"])

calculate_score(top_list)

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
 )

#
# Sortering av rader
#
(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by="score")
)

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by="score", ascending=False)
)

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by="best_position", ascending=True)
)

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by=["best_position", "num_weeks"], ascending=True)
)

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by=["best_position", "num_weeks"], ascending=[True, False])
)

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by="artist")
)

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by="artist", key=str.lower)
)

def lowercase(values):
    return values.str.lower()

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by="artist", key=lowercase)
)

def length(values):
    return values.str.len()

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by="artist", key=length)
)

#
# Skriv data til andre formater
#
billboard.to_excel("billboard.xlsx")

dir(billboard)  # Se etter metoder som begynner med to_

billboard.to_html()
billboard.to_html("billboard.html")

# Legg funksjoner i en bibliotekfil
import analysis

analysis.lowercase(songs["artist"])

(
    top_list
    .assign(
        first_letter=top_list["artist"].str[0],
        score=calculate_score,
    )
    .sort_values(by="artist", key=analysis.lowercase)
)

#
# Tegn plott
#
billboard.plot()
top_list.plot()
top_list.plot.scatter(x="average_position", y="num_weeks")

import plotly.express as px

px.scatter(top_list, x="average_position", y="num_weeks")
fig = px.scatter(top_list, x="average_position", y="num_weeks")
fig.show()
fig.to_html()

import pathlib
pathlib.Path("songs.html").write_text(fig.to_html())
