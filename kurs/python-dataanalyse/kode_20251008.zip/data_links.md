# Data

- https://github.com/auroravoje/intro_data_processing/raw/refs/heads/master/data/driftsinntekter-2021.xlsx
- https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_songs.csv
- https://raw.githubusercontent.com/gahjelle/polars-introduction/refs/heads/main/data/billboard_ranks.csv


# Oppgraderer pandas

```
python -m pip install -U pandas
```

# Lenker

- pandas dokumentasjon: https://pandas.pydata.org/docs/reference/api/pandas.read_excel.html
- Tidy Data paper: https://vita.had.co.nz/papers/tidy-data.pdf
- Plotly for plotting: https://plotly.com/python/
- Eksperimentering med regular expressions: https://regex101.com/

# Andre nyttige lenker

- Modin, pandas for store datasett: https://modin.readthedocs.io/en/stable/
- Polars, raskere pakke for DataFrames: https://pola.rs/
- Parquet, effektivt dataformat: https://parquet.apache.org/
- Arrow, standard for minnelayout for DataFrames: https://arrow.apache.org/
- Tidsrekker i pandas: https://pandas.pydata.org/docs/user_guide/timeseries.html
- Great Tables, lag tabeller: https://posit-dev.github.io/great-tables/articles/intro.html
- Openpyxl, formatter Excelark fra Python/pandas: https://realpython.com/openpyxl-excel-spreadsheets-python/
