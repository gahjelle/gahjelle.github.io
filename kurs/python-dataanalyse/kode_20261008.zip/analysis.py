name = "Geir Arne"

def calculate_score(data):
    return data["num_weeks"] * (100 - data["average_position"])
