#
# Motivasjon: Årsrapport/driftsinntekter
#
import pandas
pandas.read_excel("driftsinntekter-2021.xlsx")
data = pandas.read_excel("driftsinntekter-2021.xlsx")
data = pandas.read_excel("driftsinntekter-2021.xlsx", header=1)
data = pandas.read_excel("driftsinntekter-2021.xlsx", header=1, na_values="-")
data.info()

data.mean()
data.mean(axis="columns")  # Feil: kan ikke ta gjennomsnitt av tekstkolonner
data.mean(axis="columns", numeric_only=True)
data.assign(mean=data.mean(axis="columns", numeric_only=True))

data.set_index("Category")
data
data.set_index("Category").mean()
data.set_index("Category").mean(axis="columns")
data.set_index("Category").mean(axis="columns").reset_index()
data.set_index("Category").mean(axis="columns").reset_index().rename(columns={0: "mean"})

data[[2019]]
data[[2019, 2020, 2021]]
data[[2019, 2020, 2021]].mean(axis="columns")
data.assign(mean=data[[2019, 2020, 2021]].mean(axis="columns"))

data.columns
[str(name) for name in data.columns]
data.columns = [str(name) for name in data.columns]
data.columns
data.assign(mean=data[["2019", "2020", "2021"]].mean(axis="columns"))
data
data["mean"] = data[["2019", "2020", "2021"]].mean(axis="columns")
data

data = pandas.read_excel("driftsinntekter-2021.xlsx", header=1, na_values="-")
data
data.assign(mean=data[["2019", "2020", "2021"]].mean(axis="columns"))
data.columns = [str(name) for name in data.columns]
data.assign(mean=data[["2019", "2020", "2021"]].mean(axis="columns"))
data_m_gjsnitt = data.assign(mean=data[["2019", "2020", "2021"]].mean(axis="columns"))
data_m_gjsnitt
data = data.assign(mean=data[["2019", "2020", "2021"]].mean(axis="columns"))

data
(
    data
    .assign(
        år2022=1,
        år2023=2,
    )
    .set_index("Category")
    .mean(axis="columns")
    .reset_index()
    .rename(columns={0: "mean"})
)

(
    data
    .assign(
        år2022=1,
        år2023=2,
    )
    .set_index("Category")
)

data.set_index("Category").mean(axis="columns").reset_index()

# Pause til 10:35
data = pandas.read_excel("driftsinntekter-2021.xlsx", header=1, na_values="-")
data.melt(id_vars="Category")
data.melt(id_vars=["Category"])
data.melt(id_vars=["Category"], var_name="Year", value_name="Income")
tidy = data.melt(id_vars=["Category"], var_name="Year", value_name="Income")

tidy.groupby("Category").mean()
tidy.groupby("Category", as_index=False).mean()
tidy.groupby("Category", as_index=False)
for group in tidy.groupby("Category", as_index=False):
    print(group)

data.melt(id_vars=["Category"])
data.melt(id_vars=["Category"], value_name="Income", var_name="Year")
data.melt(id_vars=["Category"], value_vars=[2019, 2020], value_name="Income", var_name="Year")
data.melt(id_vars=["Category", 2021], value_vars=[2019, 2020], value_name="Income", var_name="Year")

tidy.groupby("Category", as_index=False)
tidy.groupby("Category", as_index=False).mean()
tidy.groupby("Category", as_index=False).agg(Mean=("Income", "mean"))
tidy.groupby("Category", as_index=False).agg(Mean=("Income", "mean"), Count=("Income", "count"))
tidy.groupby("Year", as_index=False).agg(Mean=("Income", "mean"))

tidy
tidy.pivot_table(index="Category", columns="Year", values="Income")

#
# Billboard top 100: Full tidy utforskende arbeidsflyt
#
# 1. Les inn data - pandas.read_...
# 2. Konvertere til tidy data - .melt()  (disse dataene er allerede tidy)
#
pandas.read_csv("billboard_songs.csv")
pandas.read_csv("C:\downloads\billboard_songs.csv")  # Feil: bakoverslash er et spesialtegn
pandas.read_csv("C:\users\geirarne\downloads\billboard_songs.csv")  # Feil: bakoverslash er et spesialtegn
print("Hei\nalle\nsammen")
pandas.read_csv(r"C:\users\geirarne\downloads\billboard_songs.csv")
songs = pandas.read_csv("billboard_songs.csv")
ranks = pandas.read_csv("billboard_ranks.csv")
songs
songs.info()
ranks.info()
ranks.describe()
ranks = pandas.read_csv("billboard_ranks.csv", parse_dates=["date"])
ranks.info()
ranks.describe()

#
# 3. Filtrere data - [], .drop(), .query(), .loc[]
#
songs
songs.columns
songs[["artist", "track"]]
songs[["track", "artist"]]
songs.drop(columns=["time", "genre"])
songs.query("genre == 'Rock'")
songs.query("genre == 'Rock' or genre == 'Pop'")
songs.query("genre == 'Rock' and genre == 'Pop'")
songs.query("genre == 'Rock' and artist == 'Madonna'")
songs.query("genre == 'Rock'").query("artist == 'Madonna'")
artist_name = "Madonna"
songs.query("artist == artist_name")  # Feil: artist_name er ikke en kolonne
songs.assign(artist_name="Madonna").query("artist == artist_name")
songs.query("artist == @artist_name")
songs["artist"] == artist_name
songs.loc[songs["artist"] == artist_name]
songs.query("artist == @artist_name")
songs.query("genre == 'Rock' or genre == 'Pop'")
songs["genre"] == "Rock" or songs["genre"] == "Pop"  # Feil: kan ikke bruke "or" på hele kolonner
songs["genre"] == "Rock" | songs["genre"] == "Pop"  # Feil: | binder tettere enn ==
(songs["genre"] == "Rock") | (songs["genre"] == "Pop")
songs.loc[(songs["genre"] == "Rock") | (songs["genre"] == "Pop")]
songs.query("genre == 'Rock' or genre == 'Pop'")
songs.loc[(pandas.col("genre") == "Rock")]
songs.loc[songs["artist"] == artist_name]
# Lunsj
songs.loc[(songs["genre"] == "Rock") | (songs["genre"] == "Pop")]
songs["artist"]
songs["artist"].str.lower()
songs["artist"].str.startswith("M")
songs.loc[(songs["genre"] == "Rock") | (songs["artist"].str.startswith("M"))]
songs.loc[(songs["genre"] == "Rock") & (songs["artist"].str.startswith("M"))]
is_rock = songs["genre"] == "Rock"
starts_with_m = songs["artist"].str.startswith("M")
songs.loc[is_rock & starts_with_m]
songs.query("artist.str.startswith('M')")
songs.query("artist.str.startswith('M') and genre == 'Rock'")

ranks.info()
ranks.query("date.dt.month == 7")
ranks.query("date.dt.month == 7 and rank < 10")

#
# 4. Slå sammen data - .merge()
#
songs
ranks
songs.merge(ranks)
ranks.merge(songs)
songs.merge(ranks, on="id")
songs.merge(ranks, left_on="id", right_on="rank")
top_20 = ranks.query("rank <= 20")
top_20.info()
top_20 = ranks.query("rank <= 20").rename(columns={"id": "song_id"})
top_20
songs.merge(top_20)  # Feil: Ingen felles kolonner
songs.merge(top_20, left_on="id", right_on="song_id")
songs.value_counts()
songs["artist"].value_counts()
songs["track"].value_counts()
songs.merge(top_20, left_on="id", right_on="song_id")["artist"].value_counts()
songs.merge(top_20, left_on="id", right_on="song_id")
songs.merge(top_20, left_on="id", right_on="song_id", how="outer")
songs.merge(top_20, left_on="id", right_on="song_id", how="outer")["artist"].value_counts()
songs.merge(top_20, left_on="id", right_on="song_id", how="outer", indicator=True)
songs.value_counts()
songs["artist"].value_counts()
songs["genre"].value_counts()
billboard = songs.merge(ranks, on="id")

#
# 5. Aggregere data - .groupby(), .agg()
#
# Oppgave: Finn beste plassering for hver sang
#
billboard.groupby("track").agg(best_position=("rank", "min"))
songs["track"].value_counts()
songs.query("track == 'Where I Wanna Be'")

billboard.groupby("track").agg(best_position=("rank", "min"))
billboard.groupby(["artist", "track"]).agg(best_position=("rank", "min"))
billboard.groupby(["id"]).agg(best_position=("rank", "min"))
billboard.groupby(["id"], as_index=False).agg(best_position=("rank", "min"))
billboard.merge(billboard.groupby(["id"], as_index=False).agg(best_position=("rank", "min")))
billboard.groupby(["artist", "track"], as_index=False).agg(best_position=("rank", "min"))

(
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min")
    )
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
    )
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entry=("date", "first"),  # "first" tar øverste rad, den er bare første dato om radene er sortert
    )
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entry=("date", "min"),
    )
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entry=("date", "min"),
        num_weeks=("", "count"),  # Feil: må angi en kolonne
    )
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),
    )
)

# Pause til 13:45
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
    )
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", "min == 1"),  # Feil: "min == 1" er ikke en gyldig operasjon
    )
)

def return_42():
    return 42
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        # reached_number_1=("rank", "min == 1"),
        always_42=("rank", return_42)  # Feil: operasjonen må akseptere 1 parameter
    )
)

def return_42(ting):
    return 42
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        # reached_number_1=("rank", "min == 1"),
        always_42=("rank", return_42)
    )
)

def return_42(ting):
    print(ting)
    return 42
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        # reached_number_1=("rank", "min == 1"),
        always_42=("rank", return_42)
    )
)

def return_42(column):
    return 42
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        # reached_number_1=("rank", "min == 1"),
        always_42=("rank", return_42)
    )
)

def reached_1(rank):
    return rank.min()
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        always_42=("rank", return_42)
    )
)

def reached_1(rank):
    return rank.min() == 1
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        always_42=("rank", return_42)
    )
)

def duration(date):
    return date.max() - date.min()
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
)

insights.info()
pandas.Timedelta(days=7)
def duration(date):
    return (date.max() - date.min()).days
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry, antall dager
    )
)

def duration(date):
    return (date.max() - date.min()) / pandas.Timedelta(days=7)
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry, antall uker
    )
)

def duration(date):
    return (date.max() - date.min()) / pandas.Timedelta(days=365)
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry, antall år
    )
)

def duration(date):
    return (date.max() - date.min()) / pandas.Timedelta(days=7)
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry, antall uker (igjen)
    )
)

insights.info()
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    
    )
)

#
# 6. Transformere data - .assign(), pandas.col()
#
(lambda en, to: en + to)(5, 12)
pandas.__version__  # pandas.col() virker bare i v3.0.0 og senere
pandas.col
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .assign(
        one=1,
    )
)

insights["duration"]
insights["duration"] * 7
insights["num_weeks"] * (100 - insights["average_position"])

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"])
    )
)

def score(data):
    return data["num_weeks"] * (100 - data["average_position"])
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
    )
)

pandas.col("num_weeks")
pandas.col("num_weeks") * (100 - pandas.col("average_position"))
pandas.col("pannekake")
score_expr = pandas.col("num_weeks") * (100 - pandas.col("average_position"))

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
    )
)

pandas.col("artist").str[0]
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        first_letter=pandas.col("artist").str[0]
    )
)

pandas.col("pannekake")
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        first_letter=pandas.col("artist").str[0],
        tull=pandas.col("pannekake"),  # Feil: kolonnen pannekake eksisterer ikke
    )
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        first_letter=pandas.col("artist").str[0],
    )
)

#
# 7. Sortere data - .sort_values()
#
insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        # first_letter=lambda data: data["artist"].str[0],
        first_letter=pandas.col("artist").str[0],
    )
    .sort_values(by="score")
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        # first_letter=lambda data: data["artist"].str[0],
        first_letter=pandas.col("artist").str[0],
    )
    .sort_values(by="score", ascending=False)
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        # first_letter=lambda data: data["artist"].str[0],
        first_letter=pandas.col("artist").str[0],
    )
    .sort_values(by="artist", ascending=True)
)

ord("M")
ord("m")
[ord(char) for char in "ABCDEFGHIJKLMNOPQSTUVWXYZÆØÅ"]
[ord(char) for char in "ABCDEFGHIJKLMNOPQSTUVWXYZÆØÅ".lower()]

sorted(["1", "5", "12"])
sorted(["1", "5", "12"], key=int)
sorted(["Madonna", "REM", "matchbox twenty"])
str.lower
sorted(["Madonna", "REM", "matchbox twenty"], key=str.lower)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        # first_letter=lambda data: data["artist"].str[0],
        first_letter=pandas.col("artist").str[0],
    )
    .sort_values(by="artist", ascending=True, key=lambda artist: artist.str.lower())
)
sorted(["Madonna", "REM", "matchbox twenty"], key=str.lower)

# Pause til 15:00
billboard.resample("1ME", on="date")
billboard.resample("1ME", on="date").agg(pos=("rank", "mean"))
billboard.resample("1ME", on="date").agg(num=("rank", "count"))
billboard.resample("1MS", on="date").agg(num=("rank", "count"))
billboard["date"].sort_values()

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        # first_letter=lambda data: data["artist"].str[0],
        first_letter=pandas.col("artist").str[0],
    )
    .sort_values(by="artist", ascending=True)
    #.sort_values(by="artist", ascending=True, key=lambda artist: artist.str.lower())
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        # first_letter=lambda data: data["artist"].str[0],
        first_letter=pandas.col("artist").str[0],
    )
    .sort_values(by=["artist", "average_position"], ascending=True)
    #.sort_values(by="artist", ascending=True, key=lambda artist: artist.str.lower())
)

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        # first_letter=lambda data: data["artist"].str[0],
        first_letter=pandas.col("artist").str[0],
    )
    .sort_values(by=["artist", "average_position"], ascending=[True, False])
    #.sort_values(by="artist", ascending=True, key=lambda artist: artist.str.lower())
)

#
# Strukturering av kode: navnerom
#
dir(data)
len(dir(data))
len(dir(pandas))
[name for name in dir(pandas) if name.startswith("read")]

import analysis  # Last filen analysis.py i gjeldende katalog
analysis.name
import analysis
analysis.calculate_score()

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        imported_score=analysis.calculate_score,
        # first_letter=lambda data: data["artist"].str[0],
        first_letter=pandas.col("artist").str[0],
    )
    .sort_values(by=["artist", "average_position"], ascending=[True, False])
    #.sort_values(by="artist", ascending=True, key=lambda artist: artist.str.lower())
)

import transforms.analysis  # Last filen analysis.py i katalogen transforms/ innenfor gjeldende katalog

#
# 8. Presentere data - .pivot_table(), .plot....(), .to_...()
#
insights
insights.info()
insights.plot()
insights.plot()
import math
import matplotlib.pyplot as plt
plt.show()
insights.plot.bar()
insights.plot.bar(x="track", y="score")
insights.iloc[:15].plot.bar(x="track", y="score")
ax = insights.iloc[:15].plot.bar(x="track", y="score")
ax.set_ylabel("poeng")
plt.show()
ax

#
# Plott med Plotly
#
import plotly.express as px
fig = px.bar(insights, x="track", y="score")
fig.show()
fig.to_html("tracks.html")
from pathlib import Path
Path("tracks.html").write_text(fig.to_html())

# Alternativer til pandas:
#
# Modin for store datamengder
# Polars for raskere analyse
