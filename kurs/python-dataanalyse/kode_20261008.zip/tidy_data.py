# Datalenker
#
# https://shorturl.at/BFa2U
# https://shorturl.at/hMXu9
#   schedule.csv, billboard_ranks.csv, billboard_songs.csv

# ipython
#
# <python> -m pip install ipython
# ipython 

# Pyjanitor

# Tidy Data - Hadley Wickham

import pandas
import transforms.analysis

# %%

# Skriv https://shorturl.at/BFa2U inn i nettleser
# Dette laster ned driftsinntekter-2021.xlsx
# Flytt denne filen inn i gjeldende katalog
data = pandas.read_excel("driftsinntekter-2021.xlsx", header=1, na_values="-")

# Pass på at alle kolonnenavn er tekst
data.columns = [str(name) for name in data.columns]

# Regn ut gjennomsnitt for hver kategori
data.assign(mean=data.mean(axis="columns", numeric_only=True))
data.assign(mean=data[["2019", "2020", "2021"]].mean(axis="columns"))

transformert = (
    data
    .assign(
        år2022=1,
        år2023=2,
    )
    .set_index("Category")
    .mean(axis="columns")
    .reset_index()
    .rename(columns={0: "mean"})
)

data["mean"] = data[["2019", "2020", "2021"]].mean(axis="columns")


# Tidy data

# 1. Hver kolonne er en (statistisk) variabel
# 2. Hver rad er en observasjon
# 3. Hver tabell er en konsistent enhet

tidy = data.melt(
    id_vars=["Category"], var_name="Year", value_name="Income"
)
(
    tidy
    .groupby("Category", as_index=False)
    .agg(
        Mean=("Income", "mean"),
        Count=("Income", "count"),
    )
)

# Utforskende arbeidsflyt

# 1. Les inn data - pandas.read_...
# 2. Konvertere til tidy data - .melt()
# 3. Filtrere data - [], .drop(), .query(), .loc[]
# 4. Slå sammen data - .merge()
# 5. Aggregere data - .groupby(), .agg()
# 6. Transformere data - .assign(), pandas.col()
# 7. Sortere data - .sort_values()
# 8. Presentere data - .pivot_table(), .plot....(), .to_...()

# Last ned fra https://shorturl.at/hMXu9
#   billboard_ranks.csv, billboard_songs.csv

songs = pandas.read_csv("billboard_songs.csv")
ranks = pandas.read_csv("billboard_ranks.csv", parse_dates=["date"])
top_20 = ranks.query("rank <= 20").rename(columns={"id": "song_id"})

# Inner join - Kun data som eksisterer begge steder
# Outer join - Alle data, selv om de bare finnes i en tabell
# Left/right join - Alle data fra den ene tabellen
billboard = songs.merge(ranks, on="id")

# Oppgaver:
#    
#   - Finn beste plassering for hver sang
#   - Når kom hver sang inn på lista for første gang
#   - Hvor mange uker var hver sang på lista?
def return_42(column):
    return 42

def reached_1(rank):
    return rank.min() == 1

def duration(date):
    return (date.max() - date.min()) / pandas.Timedelta(days=7)

def score(data):
    return data["num_weeks"] * (100 - data["average_position"])

score_expr = pandas.col("num_weeks") * (100 - pandas.col("average_position"))

insights = (
    billboard
    .groupby(["artist", "track"], as_index=False)
    .agg(
        best_position=("rank", "min"),
        average_position=("rank", "mean"),
        first_entry=("date", "min"),
        num_weeks=("id", "count"),  # Kolonnenavnet spiller strengt tatt ingen rolle
        reached_number_1=("rank", reached_1),
        also_reached_number_1=("rank", lambda rank: rank.min() == 1),
        always_42=("rank", return_42),
        duration=("date", duration), # Tid mellom første og siste entry
    )
    .query("reached_number_1")
    .assign(
        one=1,
        score=lambda data: data["num_weeks"] * (100 - data["average_position"]),
        also_score=score,
        v3_score=score_expr,
        imported_score=transforms.analysis.calculate_score,
        # first_letter=lambda data: data["artist"].str[0],
        first_letter=pandas.col("artist").str[0],
    )
    .sort_values(by=["artist", "average_position"], ascending=[True, False])
    #.sort_values(by="artist", ascending=True, key=lambda artist: artist.str.lower())
)
