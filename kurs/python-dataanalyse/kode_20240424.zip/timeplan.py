import pandas as pd

schedule = pd.read_csv(
    "https://github.com/gahjelle/pandas-introduction/raw/main/data/schedule.csv",
    parse_dates=["timestamp"],
)

for_print = schedule.pivot_table(
    values="title",
    index="timestamp",
    columns="room",
    aggfunc="first",
)

(
    for_print
    .reset_index()
    .melt(
        id_vars="HS118",
        value_name="title",
        var_name="room",
    )
)

(
    for_print
    .reset_index()
    .assign(count=12)
    .melt(
        id_vars="timestamp",
        value_vars=["HS118", "HS120"],
        value_name="title",
        var_name="room",
    )
)