#
# Introduksjon, regn gjennomsnitt av driftsinntekter
#
2 + 3
import pandas as pd

pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/master/data/driftsinntekter-2021.xlsx")
pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/master/data/driftsinntekter-2021.xlsx", header=1)
data = pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/master/data/driftsinntekter-2021.xlsx", header=1)
data.info()

data = pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/master/data/driftsinntekter-2021.xlsx", header=1, na_values="-")
data.info()

data = pd.read_excel("https://github.com/auroravoje/intro_data_processing/raw/master/data/driftsinntekter-2021.xlsx", header=1, na_values="-").convert_dtypes()
data.info()

data
data.mean()  # Feil, kan ikke regne snitt av tekstkolonnen

data
data.set_index("Category")
data.set_index("Category").mean()
data.set_index("Category").mean(axis="columns")
data.set_index("Category").mean(axis="columns").reset_index()
data.set_index("Category").mean(axis="columns").reset_index().rename(columns={0: "average_income"})

data
data.melt(id_vars="Category")
data.melt(id_vars="Category", var_names="year")
data.melt(id_vars="Category", var_name="year")
data.melt(id_vars="Category", var_name="year", value_name="income")
tidy = data.melt(id_vars="Category", var_name="year", value_name="income")

# PAUSE til 09:55

tidy.groupby("Category")
tidy.groupby("Category").agg(average_income=("income", "mean"))

#
# Konverter fra tidy til messy data
#
pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/schedule.csv")
schedule = pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/schedule.csv")

schedule.pivot_table(values="title", index="timestamp", columns="room")  # Feil, må overstyre aggregeringsfunksjonen når verdiene er tekst
schedule.pivot_table(values="title", index="timestamp", columns="room", aggfunc="first")
schedule
for_print = schedule.pivot_table(values="title", index="timestamp", columns="room", aggfunc="first")

# OPPGAVE: Konverter for_print tilbake til tidy form

for_print.melt(id_vars="timestamp")
for_print = schedule.pivot_table(values="title", index="timestamp", columns="room", aggfunc="first")
for_print
for_print.reset_index()
for_print.reset_index().melt(id_vars="timestamp")
schedule
for_print.reset_index().melt(id_vars="timestamp", value_name="title")
for_print.reset_index().melt(id_vars="timestamp", value_name="title", var_name="room")
for_print.reset_index().melt(id_vars="timestamp", value_name="title", var_name="kake")
for_print.reset_index().melt(id_vars="timestamp", value_name="title", var_name="room")
for_print

for_print.reset_index().melt(id_vars="HS118", value_name="title", var_name="room")
tidy = for_print.reset_index().melt(id_vars="HS118", value_name="title", var_name="room")
tidy = for_print.reset_index().melt(id_vars=["timestamp", "HS118"], value_name="title", var_name="room")
tidy = for_print.reset_index().melt(id_vars=["timestamp"], value_name="title", var_name="room")

for_print.reset_index()
for_print.reset_index().assign(count=12)
for_print.reset_index().assign(count=12).melt(id_vars="timestamp")
for_print.reset_index().assign(count=12).melt(id_vars="timestamp", value_vars=["HS118", "HS120"])
for_print.reset_index().assign(count=12).melt(id_vars="timestamp", value_vars=["HS118", "HS120"], value_name="title", var_name="room")
for_print
for_print_wo_index = for_print.reset_index()
for_print_wo_index.melt(id_vars="timestamp")

tidy = data.melt(
    id_vars="Category",
    var_name="year",
    value_name="income",
)
tidy

tidy.groupby("Category").agg(average_income=("income", "mean"))
(
     tidy
     .groupby("Category", as_index=False)
     .agg(average_income=("income", "mean"))
)
data

#
# Filtrering av rader og kolonner
#
schedule
schedule.loc[4]
schedule.loc[4:8]
schedule.loc[:5]
schedule.set_index("room")
schedule.set_index("room").loc["HS118"]
schedule.query("room == 'HS118'")
schedule.info()
schedule = pd.read_csv(
    "https://github.com/gahjelle/pandas-introduction/raw/main/data/schedule.csv",
    parse_dates=["timestamp"],
)
schedule.info()
schedule

schedule.set_index("timestamp")
schedule.set_index("timestamp").loc["2022-08-29"]
schedule.set_index("timestamp").loc["2022"]

schedule.set_index("timestamp").resample("H")
schedule.set_index("timestamp").resample("H").first()

for_print
for_print.reset_index()
dir(pd)
[func for func in dir(pd) if func.startswith("read_")]
[func for func in dir(pd) if func.startswith("to_")]   # Feil, skrivemetodene ligger på hver DataFrame
[func for func in dir(for_print) if func.startswith("to_")]

#
# Musikktopplister
#
songs = pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_songs.csv")
ranks = pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_ranks.csv")
songs.info()
songs.loc[0]
songs = (
    pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_songs.csv")
    .convert_dtypes()
)
songs.loc[0]
songs.info()
ranks = (
    pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_ranks.csv")
    .convert_dtypes()
)
ranks.info()
ranks.loc[0]
ranks = (
    pd.read_csv(
        "https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_ranks.csv",
        parse_dates=["date"],
    )
    .convert_dtypes()
)
ranks.loc[0]
ranks.info()

songs
songs.loc[2:8]
songs.loc[:, ["track", "artist", "time"]]
songs[["track", "artist", "time"]]
songs.drop(columns=["genre"])
songs.drop(columns=["genre", "id"])
songs.query("artist == 'Madonna'")
artist_name = "Madonna"
songs.query("artist == artist_name")  # Feil, artist_name er ikke en kolonne i songs
songs.query("artist == @artist_name")
songs.artist
songs.artist == "Madonna"
songs[songs.artist == "Madonna"]
songs.query("artist == @artist_name")
songs.query("track.str.contains('American')")
songs.query("track.str.contains('can')")
songs.query("track.str.contains('a')")
songs.query("track.str.contains('z')")

dir(songs.track.str)
songs.query("track.str.contains('z')")
ranks
ranks.date
dir(ranks.date.dt)

ranks.date.dt.month_name()
ranks
ranks[["date", "rank"]]
ranks.query("rank == 1")
songs.query("id == 0")

# PAUSE TIL 11:30

#
# Manglende verdier
#
data
data.fillna(0)
tidy
tidy.fillna(0)
tidy.fillna(0).groupby("Category").agg(average_income=("income", "mean"))
tidy.groupby("Category").agg(average_income=("income", "mean"))
tidy
tidy.ffill()
tidy.dropna()
songs
ranks

#
# Slå sammen tabeller, legg data ved siden av hverandre
#
pd.merge(songs, ranks)
billboard = pd.merge(songs, ranks)
ranks.query("rank == 1")
billboard.query("rank == 1")

ranks.rename(columns={"id": "song_id"})
ranks = ranks.rename(columns={"id": "song_id"})
pd.merge(songs, ranks)  # Feil, ingen feller kolonne å slå sammen dataene på
pd.merge(songs, ranks, left_on="id", right_on="song_id")
songs.merge(ranks, left_on="id", right_on="song_id")
songs.query("artist == 'Madonna'")
songs.query("artist == 'Madonna'").merge(ranks, left_on="id", right_on="song_id")
songs.query("artist == 'Madonna'").merge(ranks, left_on="id", right_on="song_id", how="inner")
songs.query("artist == 'Madonna'").merge(ranks, left_on="id", right_on="song_id", how="outer")

ranks
ranks.query("rank == 1")
ranks
ranks.info()
pd.__version__
ranks[ranks.rank == 1]  # Feil, .rank er en metode på DataFrames
ranks.rank == 1  # Feil, .rank er en metode på DataFrames
ranks["rank"] == 1
ranks[ranks["rank"] == 1]
songs.artist
ranks.rank
ranks["rank"]
ranks[["rank", "date"]]
ranks[ranks["rank"] == 1]

#
# Slå sammen tabeller, legg data etter hverandre
#
pd.read_csv("https://data.urbansharing.com/oslobysykkel.no/trips/v1/2024/04.csv")
april = pd.read_csv("https://data.urbansharing.com/oslobysykkel.no/trips/v1/2024/04.csv")
mars = pd.read_csv("https://data.urbansharing.com/oslobysykkel.no/trips/v1/2024/03.csv")
mars.info()
april.info()
pd.concat([mars, april])

url = "https://data.urbansharing.com/oslobysykkel.no/trips/v1/2024/{month:02d}.csv"
url.format(month=4)
url.format(month=11)

for navn in ["Geir Arne", "Jofrid", "Tonje"]:
    print(f"Hei, {navn}")

url = "https://data.urbansharing.com/oslobysykkel.no/trips/v1/2024/{month:02d}.csv"
months = []
for month in [1, 2, 3, 4]:
    print(f"Leser måned {month}")
    months.append(pd.read_csv(url.format(month=month)))
months

url = "https://data.urbansharing.com/oslobysykkel.no/trips/v1/2024/{month:02d}.csv"
months = []
for month in [1, 2, 3, 4]:
    print(f"Leser måned {month}")
    months.append(pd.read_csv(url.format(month=month)))
bike_trips = pd.concat(months)
bike_trips

bike_trips.loc[0]
bike_trips.reset_index()
bike_trips.reset_index(drop=True)

import pathlib
pathlib.Path("kurs/python-dataanalyse/20240424/underveis")
pathlib.Path("kurs/python-dataanalyse/20240424/underveis").iterdir()
list(pathlib.Path("kurs/python-dataanalyse/20240424/underveis").iterdir())

for file_name in pathlib.Path("kurs/python-dataanalyse/20240424/underveis").iterdir():
    print(f"Leser {file_name}")

for file_name in pathlib.Path("kurs/python-dataanalyse/20240424/underveis").glob("*.py"):
    print(f"Leser {file_name}")

#
# Aggregeringer
#
songs = (
    pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_songs.csv")
    .convert_dtypes()
)
ranks = (
    pd.read_csv(
        "https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_ranks.csv",
        parse_dates=["date"],
    )
    .convert_dtypes()
    .rename(columns={"id": "song_id"})
)

billboard = pd.merge(songs, ranks, left_on="id", right_on="song_id")
billboard.groupby("id")
billboard.groupby("id").size()
billboard.groupby("id").size().sort_values()

songs.query("id == 46")
billboard.query("id == 46")

for group in billboard.groupby("id"):
    print(group)

for id, group in billboard.groupby("id"):
    print(f"\nId {id} er følgende data:")
    print(group)

billboard.groupby("id").agg(average_position=("rank", "mean"))
billboard.groupby(["id", "artist", "track"]).agg(average_position=("rank", "mean"))
billboard.groupby("id").agg(artist=("artist", "first"), average_position=("rank", "mean"))
billboard.groupby(["id", "artist", "track"], as_index=False).agg(average_position=("rank", "mean"))

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
    )
)

pd.set_option("display.max_columns", None)
(

    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "first"),
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
    )
)

def greet(name):
    return f"Heisann, {name}"
greet("Geir Arne")

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", greet)
    )
)

def contains_1(column):
    return column.min() == 1

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1)
    )
)

#
# Transformer: legg til nye kolonner basert på eksisterende data
#
billboard
billboard.assign(month=billboard.date.dt.month)
billboard.assign(month=billboard.date.dt.month_name())
billboard.assign(month=billboard.date.dt.month_name(), year=billboard.date.dt.year)

billboard.date.dt
billboard["date"].dt
billboard.assign(month=billboard.date.dt.month_name(), year=billboard.date.dt.year)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        entered_month=billboard.first_entered.dt.month_name(),  # Feil, billboard har ingen kolonne som heter first_entered
    )
)

billboard
billboard_aggregated = (
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1)
    )
)

billboard_aggregated.assign(entered_month=billboard_aggregated.first_entered.dt.month_name())

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1)
    )
    .assign(
        entered_month=lambda rows: rows.first_entered.dt.month_name(),
    )
)

lambda x, y: x + y

def add(x, y):
    return x + y

add(2, 3)
(lambda x, y: x + y)(2, 3)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1),
        num_weeks=("rank", "count"),
    )
    .assign(
        entered_month=lambda rows: rows.first_entered.dt.month_name(),
        score=lambda rows: rows.num_weeks * (100 - rows.average_position),
    )
)

#
# Sorter data
#
billboard
songs
songs.sort_values(by="track")
songs.sort_values(by="track", ascending=False)
songs.sort_values(by="artist")
songs.sort_values(by=["artist", "track"])

songs.sort_values(by=["artist", "track"], ascending=False)
songs.sort_values(by=["artist", "track"], ascending=[True, False])

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1),
        num_weeks=("rank", "count"),
    )
    .assign(
        entered_month=lambda rows: rows.first_entered.dt.month_name(),
        score=lambda rows: rows.num_weeks * (100 - rows.average_position),
    )
    .sort_values(by="score", ascending=False)
)

(

    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1),
        num_weeks=("rank", "count"),
    )
    .assign(
        entered_month=lambda rows: rows.first_entered.dt.month_name(),
        score=lambda rows: rows.num_weeks * (100 - rows.average_position),
    )
    .sort_values(by=["highest_position", "score"], ascending=False)
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1),
        num_weeks=("rank", "count"),
    )
    .assign(
        entered_month=lambda rows: rows.first_entered.dt.month_name(),
        score=lambda rows: rows.num_weeks * (100 - rows.average_position),
    )
    .sort_values(
        by=["highest_position", "score"],
        ascending=[True, False],
    )
)

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1),
        num_weeks=("rank", "count"),
    )
    .assign(
        entered_month=lambda rows: rows.first_entered.dt.month_name(),
        score=lambda rows: rows.num_weeks * (100 - rows.average_position),
    )
    .sort_values(
        by=["highest_position", "score"],
        ascending=[True, False],
    )
    .drop(columns=["average_position", "score"])
)
