import pandas as pd

songs = (
    pd.read_csv("https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_songs.csv")
    .convert_dtypes()
)
ranks = (
    pd.read_csv(
        "https://github.com/gahjelle/pandas-introduction/raw/main/data/billboard_ranks.csv",
        parse_dates=["date"],
    )
    .convert_dtypes()
    .rename(columns={"id": "song_id"})
)


billboard = pd.merge(songs, ranks, left_on="id", right_on="song_id")

def contains_1(column):
    return column.min() == 1

(
    billboard
    .groupby(["id", "artist", "track"], as_index=False)
    .agg(
        average_position=("rank", "mean"),
        first_entered=("date", "min"),
        highest_position=("rank", "min"),
        reached_no_1=("rank", contains_1),
        num_weeks=("rank", "count"),
    )
    .assign(
        entered_month=lambda rows: rows.first_entered.dt.month_name(),
        score=lambda rows: rows.num_weeks * (100 - rows.average_position),
    )
    .sort_values(
        by=["highest_position", "score"],
        ascending=[True, False],
    )
    .drop(columns=["average_position", "score"])
)