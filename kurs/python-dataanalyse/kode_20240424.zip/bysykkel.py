import pandas as pd

mars = pd.read_csv("https://data.urbansharing.com/oslobysykkel.no/trips/v1/2024/03.csv")
april = pd.read_csv("https://data.urbansharing.com/oslobysykkel.no/trips/v1/2024/04.csv")


url = "https://data.urbansharing.com/oslobysykkel.no/trips/v1/2024/{month:02d}.csv"
months = []
for month in [1, 2, 3, 4]:
    print(f"Leser måned {month}")
    months.append(pd.read_csv(url.format(month=month)))
bike_trips = pd.concat(months).reset_index(drop=True)

for file_name in pathlib.Path("kurs/python-dataanalyse/20240424/underveis").glob("*.csv"):
    print(f"Leser {file_name}")
    