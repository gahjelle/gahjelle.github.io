#
# Introduksjon
#
1 + 2
tall = 42
tall
tall + 5
2 * tall
fornavn = "Geir Arne"
'Geir Arne'
"Geir Arne'  # Feil: fnutter må komme i par
tall+5
fornavn="Geir Arne"

#
# Les Excelark inn i pandas
#
import pandas
pandas.read_excel
pandas.read_excel()  # Feil: må angi filnavn
pandas.read_excel("kap1.xlsx")
pandas.read_excel("kap1.xlsx", sheet_name="1.2")
budsjett = pandas.read_excel("kap1.xlsx", sheet_name="1.2")
budsjett = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
budsjett = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
budsjett
budsjett.info()

budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4
)

budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
)

budsjett.info()

budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
)

budsjett.info()

budsjett["Budsjettiltak"]
budsjett["Budsjettiltak"] * 3
budsjett["Budsjettiltak"] * 3 + 22
budsjett["Budsjettiltak"] + budsjett["Lån og garantier"]
budsjett["Budsjetttiltak"] + budsjett["Lån og garantier"]  # Feil: skrivefeil i kolonnenavn

[1, 2, 4]

budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
)

budsjett.info()

budsjett["tiltak"] + budsjett["lån"]

# PAUSE TIL 10:25

#
# Spørring: Hent ut spesifikke rader
#
budsjett
budsjett["land"]
budsjett.loc[14]
budsjett.loc[14, "tiltak"]
budsjett.query("tiltak > 5")
budsjett.query("lån < 8")
budsjett.query("tiltak > 5 and lån < 8")
budsjett.query("land == 'Norge'")
budsjett.query("land == "Norge"")  # Feil: må bruke ' inne i " eller omvendt

#
# Transformer data: Legg til nye kolonner
budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"])
budsjett

analysert = budsjett.assign(
    total=budsjett["tiltak"] + budsjett["lån"]
)
analysert = budsjett.assign(
    total=budsjett["tiltak"] + 2 * budsjett["lån"]
)
analysert = budsjett.assign(
    total=budsjett["tiltak"] + budsjett["lån"],
    tallet_en=1,
)
budsjett["tiltak"].mean()
budsjett["lån"].mean()

#
# Håndtering av manglende data
#
budsjett
budsjett.dropna()
budsjett.dropna(axis="columns")
budsjett.fillna(0)
budsjett.fillna(99)
budsjett.ffill()
budsjett.bfill()

budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
).fillna(0)
budsjett
analysert = budsjett.assign(
    total=budsjett["tiltak"] + budsjett["lån"],
    tallet_en=1,
)

#
# Del data: eksporter til Excel, tegn plott
#
analysert
analysert.to_excel("budsjett.xlsx")
analysert.plot()
import matplotlib.pyplot as plt
plt.show()

analysert.plot.bar()
analysert.plot.bar(x="land")
analysert.plot.barh(x="land")
analysert.plot.barh(x="land", stacked=True)
analysert.plot.barh(x="land", y=["tiltak", "lån", "total"], stacked=True)
analysert.plot.barh(x="land", y=["tiltak", "lån"], stacked=True)
plt.savefig("budsjett.png")

#
# Bysykler: større datasett med gruppering og aggregering
#
import pandas
pandas.read_csv("11.csv")
turer = pandas.read_csv("11.csv")
turer.info()
turer = pandas.read_csv(
    "11.csv",
    parse_dates=["started_at", "ended_at"],
)
turer.info()  # parse_dates= gjør ingenting for disse dataene fordi datoformatet er inkonsistent
pandas.to_datetime(turer["started_at"])  # Feil: Må angi format manuelt
pandas.to_datetime(turer["started_at"], format="ISO8601")
turer.assign(
    started_at=pandas.to_datetime(turer["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(turer["ended_at"], format="ISO8601"),
)

turer = pandas.read_csv(
    "11.csv",
    parse_dates=["started_at", "ended_at"],
)
turer = turer.assign(
    started_at=pandas.to_datetime(turer["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(turer["ended_at"], format="ISO8601"),
)
turer.info()
turer.loc[0]

# PAUSE TIL 11:53

#
# Aggreger data i grupper
#
turer.groupby("start_station_name")
turer.groupby("start_station_name").agg(lengste_tur=("duration", "max"))

(
    turer
    .groupby("start_station_name")
    .agg(
        antall_turer=("start_station_name", "size"),
        lengste_tur=("duration", "max"),
    )
)

(
    turer
    .groupby("start_station_name")
    .agg(
        antall_turer=("start_station_name", "size"),
        lengste_tur=("duration", "max"),
    )
    .sort_values(by="antall_turer")
)

(
    turer
    .groupby("end_station_name")
    .agg(
        antall_turer=("start_station_name", "size"),
        lengste_tur=("duration", "max"),
    )
    .sort_values(by="antall_turer")
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        antall_turer=("start_station_name", "size"),
        lengste_tur=("duration", "max"),
    )
    .sort_values(by="antall_turer")
)

#
# Pivot-tabell som viser hvilke strekninger som er mest populære
#

turer.groupby("start_station_name").agg(antall_turer=("start_station_name", "size"))
turer.groupby(["start_station_name", "end_station_name"]).agg(antall_turer=("start_station_name", "size"))
turer.groupby(["start_station_name", "end_station_name"], as_index=False).agg(antall_turer=("start_station_name", "size"))
aggregert = (
    turer
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(antall_turer=("start_station_name", "size"))
)

aggregert.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="antall_turer",
)

tabell = aggregert.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="antall_turer",
)

tabell = aggregert.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="antall_turer",
    fill_value=0,
)

#
# Sorter på gitte kolonner, stigende eller synkende
#
aggregert.sort_values(by="antall_turer")
aggregert.sort_values(by="antall_turer", ascending=False)
aggregert.sort_values(by=["antall_turer", "start_station_name"], ascending=False)
aggregert.sort_values(by=["antall_turer", "start_station_name"], ascending=[False, True])

#
# Legg data på kart
#
import folium

kart = folium.Map()
kart.save("bysykler.html")

turer.loc[0]  # Sjekk koordinatene til en stasjon

kart = folium.Map(location=[59.9, 10.7], zoom_start=10)
kart.save("bysykler.html")

kart = folium.Map(location=[59.9, 10.7], zoom_start=12)
kart.save("bysykler.html")

kart = folium.Map(location=[59.9, 10.7], zoom_start=12)
folium.Marker(
    location=[59.922422, 10.727239],
    tooltip="Oscars gate",
    popup="ved Hegdehaugsveien",
).add_to(kart)
kart.save("bysykler.html")

#
# Les inn stasjonskoordinater
#
import pandas

turer = pandas.read_csv("11.csv")
stasjoner = (
    turer[[
            "start_station_name",
            "start_station_latitude",
            "start_station_longitude"
        ]]
)
stasjoner = (
    turer[[
            "start_station_name",
            "start_station_latitude",
            "start_station_longitude"
        ]]
    .drop_duplicates()
)

#
# Bruk en løkke for å lage en markør for hver stasjon
#
for tall in [1, 4, 19]:
    print("Tallet er ", tall)

for stasjon in stasjoner.itertuples():
    print(stasjon)

stasjon
stasjon.start_station_name

kart = folium.Map(location=[59.9, 10.7], zoom_start=12)
for stasjon in stasjoner.itertuples():
    folium.Marker(
        location=[
            stasjon.start_station_latitude,
            stasjon.start_station_longitude,
        ],
        tooltip=stasjon.start_station_name,
    ).add_to(kart)
kart.save("bysykler.html")

kart = folium.Map(location=[59.9, 10.7], zoom_start=12)
for stasjon in stasjoner.itertuples():
    folium.CircleMarker(
        location=[
            stasjon.start_station_latitude,
            stasjon.start_station_longitude,
        ],
        tooltip=stasjon.start_station_name,
    ).add_to(kart)
kart.save("bysykler.html")
