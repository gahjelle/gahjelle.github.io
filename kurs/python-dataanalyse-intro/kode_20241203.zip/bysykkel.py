import pandas

# Les CSV-fil og konverter datokolonner
turer = pandas.read_csv(
    "11.csv",
    # parse_dates=["started_at", "ended_at"],
)
turer = turer.assign(
    started_at=pandas.to_datetime(turer["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(turer["ended_at"], format="ISO8601"),
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        antall_turer=("start_station_name", "size"),
        lengste_tur=("duration", "max"),
    )
    .sort_values(by="antall_turer")
)

aggregert = (
    turer
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(antall_turer=("start_station_name", "size"))
)
tabell = aggregert.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="antall_turer",
    fill_value=0,
)

aggregert.sort_values(
    by=["antall_turer", "start_station_name"],
    ascending=[False, True],
)