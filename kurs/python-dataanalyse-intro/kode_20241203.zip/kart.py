import folium
import pandas

turer = pandas.read_csv("11.csv")
stasjoner = (
    turer[[
            "start_station_name",
            "start_station_latitude",
            "start_station_longitude"
        ]]
    .drop_duplicates()
)


kart = folium.Map(location=[59.9, 10.7], zoom_start=12)
for stasjon in stasjoner.itertuples():
    folium.CircleMarker(
        location=[
            stasjon.start_station_latitude,
            stasjon.start_station_longitude,
        ],
        tooltip=stasjon.start_station_name,
    ).add_to(kart)
kart.save("bysykler.html")
