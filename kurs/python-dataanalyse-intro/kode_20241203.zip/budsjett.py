import matplotlib.pyplot as plt
import pandas

budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
).fillna(0)

analysert = budsjett.assign(
    total=budsjett["tiltak"] + budsjett["lån"],
    tallet_en=1,
)

analysert.to_excel("budsjett.xlsx")
analysert.plot.barh(
    x="land",
    y=["tiltak", "lån"],
    stacked=True,
)
plt.savefig("budsjett.png")
# plt.show()
