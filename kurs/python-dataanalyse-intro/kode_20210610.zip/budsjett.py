import pandas as pd

norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]

budsjett = (
    pd.read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        usecols=[0, 1, 2],
        index_col=0,
        na_values="-",
    )
    .rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
    .fillna(0)
)


data = budsjett.assign(
    total=budsjett.tiltak + budsjett.lån, i_norden=budsjett.index.isin(norden),
).sort_values(by="total")

(data.rename(columns={"tiltak": "Budsjettiltak"}).to_excel("budsjett.xlsx"))

data.query("i_norden").to_excel("norden.xlsx")
