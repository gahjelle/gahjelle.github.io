import pandas as pd

data = pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"]).set_index(
    "started_at"
)

antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

tabell = antall_turer.pivot_table(
    values="num_trips",
    index="start_station_name",
    columns="end_station_name",
    fill_value=0,
)

tabell.to_excel("bysykkelturer.xlsx")
