#
# Introduksjon
#
1 + 2
navn = "Geir Arne"
navn
print(navn)
print(f"Hei {navn}")
navn = input("Hva heter du? ")
navn
print(f"Hei {navn}")

#
# Innlesing av Excelfiler
#
import pandas as pd
pd.read_excel("kap1.xlsx")
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2")
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols=[0, 1, 2])
budsjett = pd.read_excel("kap1.xlsx", sheet_name=2, header=4, usecols=[0, 1, 2])
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:C")
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols=[0, 1, 2], index_col=0)
budsjett
budsjett.loc["Norge"]
budsjett.Budsjettiltak
budsjett.Lån og garantier  # Virker ikke
budsjett.loc[:, "Lån og garantier"]
budsjett.lån
budsjett.info()

#
# Manipulering av data
#
budsjett.tiltak
budsjett.tiltak * 2
budsjett.lån
budsjett.lån * 2
budsjett.lån * 2
budsjett.tiltak + budsjett.lån
budsjett.assign(
    total = budsjett.tiltak + budsjett.lån
)
data = budsjett.assign(
    total = budsjett.tiltak + budsjett.lån
)
data = budsjett.assign(
    total = budsjett.tiltak + budsjett.lån
).sort_values(by="total")
budsjett

#
# Håndter manglende data (NaN)
#
budsjett.dropna()
data
data.dropna()
budsjett.fillna()
budsjett.fillna(0)
data = (
        budsjett
        .assign(total = budsjett.tiltak + budsjett.lån)
        .sort_values(by="total")
        .fillna(0)
    )
data = (
        budsjett
        .fillna(0)
        .assign(total = budsjett.tiltak + budsjett.lån)
        .sort_values(by="total")
    )
data = data.sort_values(by="tiltak")

# Pause til 10:25

#
# Pandas GUI verktøy
# https://pypi.org/project/pandasgui/
#
import pandasgui
pandasgui.gui(data)
pandasgui.show(data)
data = data.sort_values(by="total")
pandasgui.show(data)

#
# Koble sammen data
#
norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
budsjett.index
budsjett.index.isin(norden)
data = (
        budsjett
        .assign(
            total = budsjett.tiltak + budsjett.lån,
            i_norden = budsjett.index.isin(norden),
        )
        .sort_values(by="total")
    )

#
# Spørringer og utvalg
#
data.query("lån > 10")
data.query("lån > 10 and tiltak < 4")
data.query("lån > 10 or tiltak < 4")
data.query("i_norden")
data.query("i_norden and total > 8")

#
# Skriv til Excel
#
data.to_excel("budsjett.xlsx")
(
     data
     .rename(columns={"tiltak": "Budsjettiltak"})
     .to_excel("budsjett.xlsx")
)
(
     data
     .rename(columns={"tiltak": "Budsjettiltak"})
     .to_excel("budsjett.xlsx")
)
data.query("i_norden").to_excel("norden.xlsx")
data

#
# Plott og figurer
#
data.plot()
data.plot.bar()
data.plot.bar(stacked=True)
data.loc[:, "tiltak"]
data.loc[:, ["tiltak", "lån"]]
data.loc[:, ["tiltak", "lån"]].plot.bar(stacked=True)
data.plot.scatter()
data.plot.scatter(x="tiltak", y="lån")
import matplotlib.pyplot as plt
plt.savefig("figur.png")
plt.title
figur = data.plot()
figur

#
# Bysykler, større datasett
#
data = pd.read_csv("05.csv")
data.info()
data = pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
data.info()
data = pd.read_csv(r"C:\Users\giron\kurs\05.csv", parse_dates=["started_at", "ended_at"])
data.describe()
describe = data.describe()
data
data.ended_at - data.started_at
(data.ended_at - data.started_at).plot()
data.set_index
data.set_index("started_at")
data.set_index("started_at").duration.plot()
data = (
        pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
        .set_index("started_at")
)
data.loc["2021-05-01"]
data.loc["2021-05-17"]
data.loc["2021-05-17"].plot()

#
# Gruppering av data
#
data.groupby("start_station_name")
data.groupby("start_station_name").count
data.groupby("start_station_name").count()
data.groupby("start_station_name").size()
data.groupby("start_station_name").count()
data.groupby("start_station_name").mean()
data.groupby("start_station_name").size().sort_values()
data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"]).size().sort_values()
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
)
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .rename(columns={0: "num_trips"})
)
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)
antall_turer.pivot_table(values="num_trips", index="start_station_name", columns="end_station_name")
tabell = antall_turer.pivot_table(values="num_trips", index="start_station_name", columns="end_station_name")
tabell = (
    antall_turer
    .pivot_table(
        values="num_trips",
        index="start_station_name",
        columns="end_station_name",
        fill_value=0,
    )
)
tabell.to_excel("bysykkelturer.xlsx")

#
# Koble sammen to eller flere CSV-filer
data_april = (
        pd.read_csv("04.csv", parse_dates=["started_at", "ended_at"])
        .set_index("started_at")
)
data_mai = (
        pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
        .set_index("started_at")
)
# Muligheter for å slå sammen dataframes: pd.merge / pd.join / pd.concat
pd.concat([data_april, data_mai])
filer = ["04.csv", "05.csv"]

fil_data = []
for fil in filer:
    fil_data.append(
        pd
        .read_csv(fil, parse_dates=["started_at", "ended_at"])
        .set_index("started_at")
     )

for fil in filer:
    print(fil)
for fil in filer:
    print(fil)
    print(filer)
for fil in filer:
    print(fil)
print(filer)

# Pause til 12:05

#
# Bruk pathlib for håndtering av filer
# https://realpython.com/python-pathlib/
#
import pathlib
pathlib.Path()
pathlib.Path().resolve()
pathlib.Path().glob("*")
for fil in pathlib.Path().glob("*"):
    print(fil)
for fil in pathlib.Path().glob("*.csv"):
    print(fil)

#
# Plott data på kart
#
import folium
kart = folium.Map(location=[59.9, 10.8])
kart.save("bysykkel.html")

data = pd.read_csv("05.csv")
stasjoner = (
    data.loc[:,
        ["start_station_name",
         "start_station_latitude",
         "start_station_longitude"]]
    )

stasjoner = (
    data.loc[:,
        ["start_station_name",
         "start_station_latitude",
         "start_station_longitude"]]
    .drop_duplicates()
    )
stasjoner

for stasjon in stasjoner:
    print(stasjon)
for stasjon in stasjoner.iterrows():
    print(stasjon)
for index, stasjon in stasjoner.iterrows():
    print(stasjon)
for index, stasjon in stasjoner.iterrows():
    print(stasjon.start_station_name)

antall_turer = data.groupby("start_station_name").size()
antall_turer.loc["Huk"]
antall_turer.loc["Norsk Folkemuseum"]
