import folium
import pandas as pd

data = pd.read_csv("05.csv")

stasjoner = (
    data.loc[
        :, ["start_station_name", "start_station_latitude", "start_station_longitude"]
    ]
    .drop_duplicates()
    .rename(
        columns={
            "start_station_name": "name",
            "start_station_latitude": "lat",
            "start_station_longitude": "lon",
        }
    )
)

antall_turer = data.groupby("start_station_name").size()

kart = folium.Map(location=[59.9, 10.8], zoom_start=12)
for index, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        [stasjon.loc["lat"], stasjon.loc["lon"]],
        popup=stasjon.loc["name"],
        fill=True,
        radius=antall_turer.loc[stasjon.loc["name"]] / 50,
    ).add_to(kart)

kart.save("bysykkel.html")
