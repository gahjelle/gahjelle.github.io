import pandas as pd


filer = ["04.csv", "05.csv"]

fil_data = []
for fil in filer:
    fil_data.append(
        pd.read_csv(fil, parse_dates=["started_at", "ended_at"]).set_index("started_at")
    )
data = pd.concat(fil_data)


antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

tabell = antall_turer.pivot_table(
    values="num_trips",
    index="start_station_name",
    columns="end_station_name",
    fill_value=0,
)

tabell.to_excel("bysykkelturer.xlsx")
