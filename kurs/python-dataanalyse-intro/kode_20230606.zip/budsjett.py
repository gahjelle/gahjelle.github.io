import pandas as pd

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    # index_col=0,
    na_values="-",
).rename(
    columns={
        " ": "land",
        "Lån og garantier": "lån",
        "Budsjettiltak": "tiltak"
    }
).fillna(value=0)
    
budsjett = (
    data.assign(total=data.tiltak + data.lån)
    .query("lån > 0")
    .sort_values(by="total")
)

(
    budsjett
    .set_index("land")
    .loc[:, ["tiltak", "lån"]]
    .plot.barh(stacked=True)
)