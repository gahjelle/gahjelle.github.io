#
# Introduksjon
#
1 + 2
"Geir Arne"

en = 1
to = 2
en + to
navn = "Geir Arne"

en + navn

#
# Bruk pandas til å lese Excelfiler
import pandas
pandas

en
print
print(navn)
navn

pandas.read_excel
import pandas as pd
pd

pd.read_excel
pd.read_excel("kap1.xlsx")
pd.read_excel("kap1.xlsx", sheet_name="1.2")
pd.read_excel("kap1.xlsx", sheet_name=2)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:C")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="B:C")
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
)

data
data.info()
data.loc[5]
data.Budsjettiltak
data.Lån og garantier  # Feil, kan ikke bruke .-notasjon for kolonnenavn med mellomrom
data.loc[5]
data.loc[:]
data.loc[:, "Budsjettiltak"]
data.loc[:, "Lån og garantier"]
data.loc[:, ["Budsjettiltak", "Lån og garantier"]]
data.loc[:, ["Lån og garantier", "Budsjettiltak"]]

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    index_col=0,
)
data.loc[5]  # Feil, index er nå landnavn, ikke radnummer
data.loc["Korea"]
data.loc["Norge"]
data.info()

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    index_col=0,
    na_values="-",
)
data.info()

# Pause til 10:35
data.loc[:, ["Lån og garantier", "Budsjettiltak"]]
data.loc[:, 1]  # Feil, kan ikke bruke kolonneindex sammen med .loc
data.iloc[:, 1]
data.iloc[:, [1, 0]]
data.iloc[5:, [1, 0]]
data.iloc[5:9, [1, 0]]
data.iloc[5:9, :]
data.iloc[5:9, 0:2]
data.iloc[5:9, 0:1]
data.loc[:, ["Lån og garantier", "Budsjettiltak"]]

data.rename(columns={"Lån og garantier": "lån"})
data.rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})
data
data = data.rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    index_col=0,
    na_values="-",
).rename(
    columns={
        "Lån og garantier": "lån",
        "Budsjettiltak": "tiltak"
    }
)

data.loc["Norge"]
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    # index_col=0,
    na_values="-",
).rename(
    columns={
        "Lån og garantier": "lån",
        "Budsjettiltak": "tiltak"
    }
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    # index_col=0,
    na_values="-",
).rename(
    columns={
        " ": "land",
        "Lån og garantier": "lån",
        "Budsjettiltak": "tiltak"
    }
)

data.query("land == 'Norge'")
data.query("lån > 5")
data.query("lån > 5 and tiltak < 5")
data.query("lån > 5 or tiltak < 5")

data
data.describe()
data.dropna()
data.dropna(axis="columns")
data.fillna(0)
data.lån
data.loc[:, "lån"]
data.loc[:, "lån"].mean()
data.fillna(data.loc[:, "lån"].mean())
data.fillna(method="ffill")
data.fillna(method="bfill")

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    # index_col=0,
    na_values="-",
).rename(
    columns={
        " ": "land",
        "Lån og garantier": "lån",
        "Budsjettiltak": "tiltak"
    }
).fillna(value=0)

data
data.tiltak * 2
data.lån + 1
data.tiltak + data.lån
data.assign(total=data.tiltak + data.lån)
budsjett = data.assign(total=data.tiltak + data.lån)

budsjett.query("lån > 0")
budsjett.sort_values(by="total")
budsjett = (
    data.assign(total=data.tiltak + data.lån)
    .query("lån > 0")
    .sort_values(by="total")
)

budsjett.to_excel("budsjett.xlsx")
budsjett.plot()
budsjett.plot.scatter("tiltak", "lån")
budsjett.plot.bar()
budsjett.set_index("land")
budsjett.set_index("land").plot.bar()
budsjett.set_index("land").plot.barh()
budsjett.set_index("land").plot.barh(stacked=True)
budsjett.set_index("land").loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)

(
    budsjett
    .set_index("land")
    .loc[:, ["tiltak", "lån"]]
    .plot.barh(stacked=True)
)

#
# Bysykler - analyse og aggregering av større datasett
#

data = pd.read_csv("05.csv")
data.info()
data = pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
data.info()

data.ended_at - data.started_at

data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("end_station_name").size().sort_values()
start_stasjon = data.groupby("start_station_name").size().sort_values()
slutt_stasjon = data.groupby("end_station_name").size().sort_values()
slutt_stasjon - start_stasjon
(slutt_stasjon - start_stasjon).sort_values()

data.groupby("end_station_name").mean()
data.groupby("end_station_name").agg(median_duration=("duration", "median"))
(
    data
    .groupby("end_station_name")
    .agg(
        median_duration=("duration", "median"),
        mean_duration=("duration", "mean"),
    )
)

(
    data
    .groupby("end_station_name")
    .agg(
        median_duration=("duration", "median"),
        mean_duration=("duration", "mean"),
        start_station=("start_station_name", "first"),
    )
)

# Pause til 12:10

start_stasjon = data.groupby("start_station_name").size().sort_values()
antall_turer = data.groupby("start_station_name").size()
antall_turer = (
    data.groupby("start_station_name", as_index=False).size()
)
antall_turer

pd.cut(antall_turer.loc[:, "size"], [0, 1000, 2000, 3000])
antall_turer.max()
pd.cut(antall_turer.loc[:, "size"], [0, 1000, 1500, 3000])
pd.cut(antall_turer.loc[:, "size"], [0, 1000, 1500, 3000], labels=["A", "B", "C"])
antall_turer = (
    antall_turer
    .assign(
        kategori=pd.cut(
            antall_turer.loc[:, "size"],
            [0, 1000, 1500, 3000],
            labels=["A", "B", "C"])
    )
)
antall_turer.info()

data_april = pd.read_csv("04.csv", parse_dates=["started_at", "ended_at"])
data_mai = pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
data_april.info()
pd.concat([data_april, data_mai])
data = pd.concat([data_april, data_mai])

data.loc[123]
data.reset_index()
data.reset_index(drop=True)

data_april = pd.read_csv("04.csv", parse_dates=["started_at", "ended_at"])
data_mai = pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
data = pd.concat([data_april, data_mai]).reset_index(drop=True)
(
    data
    .groupby("end_station_name")
    .agg(
        median_duration=("duration", "median"),
        mean_duration=("duration", "mean"),
        start_station=("start_station_name", "first"),
    )
)
antall_turer = (
    data.groupby("start_station_name", as_index=False).size()
)
antall_turer = (
    antall_turer
    .assign(
        kategori=pd.cut(
            antall_turer.loc[:, "size"],
            [0, 1000, 1500, 3000],
            labels=["A", "B", "C"])
    )
)

data_april.assign(filnavn="04.csv")

data_april = (
    pd.read_csv("04.csv", parse_dates=["started_at", "ended_at"])
    .assign(filnavn="04.csv")
)
data_mai = (
    pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
    .assign(filnavn="05.csv")
)
data = pd.concat([data_april, data_mai]).reset_index(drop=True)
data

varighet = (
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        mean_duration=("duration", "mean"),
        start_station=("start_station_name", "first"),
    )
)

varighet.merge(antall_turer)  # Feil, ingen felles kolonnenavn å slå sammen på
varighet.columns
antall_turer.columns
varighet.merge(antall_turer, left_on="end_station_name", right_on="start_station_name")
sammenslått = varighet.merge(antall_turer, left_on="end_station_name", right_on="start_station_name")

import folium
kart = folium.Map()
kart.save("bysykler.html")

import pandas as pd
data = (
    pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
    .assign(filnavn="05.csv")
)
data.loc[0]

kart = folium.Map((59.92, 10.68))
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.68), zoom_start=1)
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.68), zoom_start=13)
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.68), zoom_start=13)
folium.Marker(
    (59.922269, 10.67958), popup="Skøyen"
).add_to(kart)
kart.save("bysykler.html")

data.loc[1]
kart = folium.Map((59.92, 10.68), zoom_start=13)
folium.Marker(
    (59.922269, 10.67958), popup="Skøyen"
).add_to(kart)
folium.CircleMarker(
    (59.917835, 10.766374), popup="Botanisk Hage"
).add_to(kart)
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.68), zoom_start=13)
folium.Marker(
    (59.922269, 10.67958), popup="Skøyen"
).add_to(kart)
folium.CircleMarker(
    (59.917835, 10.766374), popup="Botanisk Hage", radius=30
).add_to(kart)
kart.save("bysykler.html")

stasjoner = data.loc[:, ["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
for _, stasjon in stasjoner.iterrows():
    print(stasjon)

kart = folium.Map((59.92, 10.68), zoom_start=13)
for _, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
    (stasjon.start_station_latitude, stasjon.start_station_longitude), popup=stasjon.start_station_name, radius=30
).add_to(kart)
kart.save("bysykler.html")
