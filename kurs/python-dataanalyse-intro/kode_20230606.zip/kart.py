import folium
import pandas as pd

data = (
    pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
    .assign(filnavn="05.csv")
)


stasjoner = data.loc[:, ["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates()

kart = folium.Map((59.92, 10.68), zoom_start=13)
folium.Marker(
    (59.922269, 10.67958), popup="Skøyen"
).add_to(kart)
folium.CircleMarker(
    (59.917835, 10.766374), popup="Botanisk Hage", radius=30
).add_to(kart)

for _, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        (stasjon.start_station_latitude, stasjon.start_station_longitude), popup=stasjon.start_station_name, radius=30
    ).add_to(kart)

kart.save("bysykler.html")
