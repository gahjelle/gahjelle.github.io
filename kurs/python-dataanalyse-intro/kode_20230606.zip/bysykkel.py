import pandas as pd

data_april = (
    pd.read_csv("04.csv", parse_dates=["started_at", "ended_at"])
    .assign(filnavn="04.csv")
)
data_mai = (
    pd.read_csv("05.csv", parse_dates=["started_at", "ended_at"])
    .assign(filnavn="05.csv")
)
data = pd.concat([data_april, data_mai]).reset_index(drop=True)

varighet = (
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        mean_duration=("duration", "mean"),
        start_station=("start_station_name", "first"),
    )
)

antall_turer = (
    data.groupby("start_station_name", as_index=False).size()
)
antall_turer = (
    antall_turer
    .assign(
        kategori=pd.cut(
            antall_turer.loc[:, "size"],
            [0, 1000, 1500, 3000],
            labels=["A", "B", "C"])
    )
)
