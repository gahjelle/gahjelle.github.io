import folium
import pandas as pd

data = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
# posisjon = (
#     data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
#     .drop_duplicates()
#     .reset_index(drop=True)
# )

antall_turer = data.groupby("start_station_name", as_index=False).agg(
    name=("start_station_name", "first"),
    latitude=("start_station_latitude", "first"),
    longitude=("start_station_longitude", "first"),
    num_trips=("start_station_name", "count"),
)


kart = folium.Map((59.92, 10.74), zoom_start=12)  # tiles="Stamen Watercolor")
for stasjon in antall_turer.itertuples():
    folium.CircleMarker(
        (stasjon.latitude, stasjon.longitude),
        popup=stasjon.name,
        radius=stasjon.num_trips / 10,
        fill=True,
    ).add_to(kart)

kart.save("bysykler.html")
