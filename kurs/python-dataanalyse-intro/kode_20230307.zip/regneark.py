import pandas as pd

# Les inn Excelfila kap1.xlsx
data = (
    pd.read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        index_col=0,
        na_values="-",
        usecols="A:C",
    )
    .rename(
        columns={
            "Budsjettiltak": "tiltak",
            "Lån og garantier": "lån",
        }
    )
    .fillna(value=0)
)

budsjett = data.assign(total=data.tiltak + data.lån)

budsjett.query("tiltak < 5 and lån > 3").to_excel("mye_laan.xlsx")
