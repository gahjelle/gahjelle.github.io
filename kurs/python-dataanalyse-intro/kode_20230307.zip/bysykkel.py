import pandas as pd

# data_jan = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
# data_feb = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
# data = pd.concat([data_jan, data_feb]).reset_index(drop=True)

# filnavn = ["01.csv", "02.csv"]
import pathlib

filnavn = pathlib.Path.cwd().glob("*.csv")
data_ark = []
for navn in filnavn:
    print(navn)
    data_måned = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    data_ark.append(data_måned)
data = pd.concat(data_ark).reset_index(drop=True)


def most_popular(group):
    return group.mode()


turlengde = data.groupby("start_station_name", as_index=False).agg(
    mean_duration=("duration", "mean"),
    median_duration=("duration", "median"),
    description=("start_station_description", "first"),
    popular_end_station=("end_station_name", most_popular),
)

antall_turer = data.groupby(
    ["start_station_name", "end_station_name"], as_index=False
).size()

turmatrise = antall_turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="size",
    fill_value=0,
)

posisjon = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
    .reset_index(drop=True)
)

turlengde_m_pos = turlengde.merge(
    posisjon,
    left_on="start_station_name",
    right_on="start_station_name",
)
