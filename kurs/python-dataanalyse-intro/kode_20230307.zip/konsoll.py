#
# Datatyper og variabler 
#
1 + 2
tall = 42
tall
tall + 3
tall * tall
pi = 3.14
1 + 2j
navn = "Geir Arne"
navn
Geir Arne  # Feil, kan ikke ha navn med mellomrom
Siren  # Feil, Python kjenner ikke navnet Siren
navn
"Jeg heter {navn}"
f"Jeg heter {navn}"
f"Jeg heter {navn} og to pi er {2 * pi}"
navn = "Grei Ane"
navn = "Geir Arne"
blåbærsyltetøy = 3

#
# Innlesing av biblioteker
#
import pandas
pandas
pandas.DataFrame

import polars  # Feil, biblioteket polars er ikke installert
import pandas as pd

#
# Les en Excelfil
pd.read_excel
pd.read_excel()  # Feil, read_excel() trenger minst ett argument
pd.read_excel("kap1.xlsx")
pd.read_excel("kap2.xlsx")  # Feil, filen kap2.xlsx eksisterer ikke
pd.read_excel("kap1.xlsx")
pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
navn
navn[1]
navn[0]
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
navn                    = "Geir Arne"
navn="Geir Arne"
navn =
 "Geir Arne"
navn = (
                    "Geir Arne"
                    
    )

pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
)
data

data.Budsjettiltak
data.Budsjettiltak * 3
data.Lån og garantier  # Feil, kan ikke ha mellomrom i Pythonnavn
data["Budsjettiltak"]
data["Lån og garantier"]

# Pause til 10:27

data.loc[11]
data.loc[14]

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    index_col=0,
)

data["Budsjettiltak"]
data.loc["Norge"]
data.info()

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    index_col=0,
    na_values="-",
)
data.info()

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    index_col=0,
    na_values="-",
    usecols="A:C",
)

data["Budsjettiltak"]
data["Lån og garantier"]
data.loc["Sverige"]
data.loc[["Sverige", "Norge"]]

flere_tall = [1, 2, 4]
norden = ["Sverige", "Norge", "Danmark", "Finland", "Island"]
data.loc[norden]  # Feil, Island er ikke i datasettet
data

norden = ["Sverige", "Norge", "Danmark", "Finland"]
data.loc[norden]

data.loc[["Sverige", "Norge"], "Budsjettiltak"]
data.loc[["Sverige", "Norge"], ["Budsjettiltak", "Lån og garantier"]]

data.index
data.loc["Finland":"Tyskland"]
data.iloc[14]
data.iloc[[14, 11]]
data.iloc[11:14]
data["budsjettiltak"]

Data  # Feil, stor forbokstav i Data: data og Data er forskjellig

data.rename
data.rename?
data.rename(columns={"A": "a", "B": "c"})
data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
data
data = data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    index_col=0,
    na_values="-",
    usecols="A:C",
).rename(
    columns={
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån",
    }
)

data.tiltak
data.lån
data["tiltak"]  # eller data.tiltak
data.tiltak * 3
data.tiltak + data.lån

data.assign(total=1)
data.assign(total=1, to=2)
data.assign(total=data.tiltak + data.lån)
budsjett = data.assign(total=data.tiltak + data.lån)
data.describe()
budsjett.describe()

#
# Behandling av manglende verdier (NA/nan)
budsjett
budsjett.dropna()
budsjett.dropna?
budsjett.dropna(axis="columns")
budsjett.fillna?
budsjett.fillna(0)
budsjett.fillna(method="ffill")
budsjett.fillna(method="bfill")

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    index_col=0,
    na_values="-",
    usecols="A:C",
).rename(
    columns={
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån",
    }
).fillna(value=0)

budsjett = data.assign(total=data.tiltak + data.lån)
budsjett

()   # kalle kommandoer, tupler
[]   # oppslag, lister
{}   # dictionary, key/value pair

#
# Formler og spørringer
#
budsjett + 1
budsjett > 5
budsjett.tiltak > 5
budsjett.loc[budsjett.tiltak > 5]
budsjett.query("tiltak > 5")
budsjett.query("tiltak < 5 and lån > 3")
budsjett.loc[(budsjett.tiltak < 5) & (budsjett.lån > 3)]
budsjett.query("tiltak < 5 and lån > 3")[["tiltak", "lån"]]

#
# Plott av figurer
#
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(stacked=True)
budsjett[["tiltak", "lån"]].plot.barh(stacked=True)
budsjett[["tiltak", "lån"]]
budsjett.sort_values(by="total")
budsjett.sort_values(by="total")[["tiltak", "lån"]].plot.barh(stacked=True)

#
# Skriv til Excel
#
budsjett.to_excel("budsjett.xlsx")
budsjett.query("tiltak < 5 and lån > 3").to_excel("mye_laan.xlsx")

#
# Bysykkeldata
#
import pandas as pd
pd.read_csv("02.csv")
data = pd.read_csv("02.csv")
data.info()
pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
data = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
data.info()

data.ended_at
data.ended_at - data.started_at
(data.ended_at - data.started_at).max()

pd.Timestamp.max
pd.Timestamp.min

pd.read_csv("01.csv", sep=";")  # Feil, dataene er ikke semikolonseparert

data = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])

# Pause til 13:40

data.duration.plot()
data.set_index("started_at")
data.set_index("started_at").duration.plot()

data.loc[1]
data.set_index("started_at").loc["2023-02-02"]

#
# Gruppering og aggregering
#
data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("end_station_name").size().sort_values()
data.groupby("start_station_name").mean()

turlengde = data.groupby("start_station_name").mean()
turlengde = data.groupby("start_station_name").agg(mean_duration=("duration", "mean"))
turlengde = data.groupby("start_station_name").agg(
    mean_duration=("duration", "mean"),
    median_duration=("duration", "median"),
)
turlengde = data.groupby("start_station_name").agg(
    mean_duration=("duration", "mean"),
    median_duration=("duration", "median"),
    description=("start_station_description", "first"),
)
turlengde = data.groupby("start_station_name").agg(
    mean_duration=("duration", "mean"),
    median_duration=("duration", "median"),
    description=("start_station_description", "first"),
    popular_end_station=("end_station_name", "max"),  # Gir siste stasjon i alfabetet
)

#
# Definer egen funksjon
#
def si_hei(navn):
    return f"Hei {navn}"
si_hei("Geir Arne")
si_hei("pannekake")

dir()

def most_popular(arg):
    print(arg)
    return arg
turlengde = data.groupby("start_station_name").agg(
    mean_duration=("duration", "mean"),
    median_duration=("duration", "median"),
    description=("start_station_description", "first"),
    popular_end_station=("end_station_name", most_popular),
)

data.end_station_name
data.end_station_name.mode()
data.end_station_name.mode?

def most_popular(group):
    return group.mode()
turlengde = data.groupby("start_station_name").agg(
    mean_duration=("duration", "mean"),
    median_duration=("duration", "median"),
    description=("start_station_description", "first"),
    popular_end_station=("end_station_name", most_popular),
)

turlengde = data.groupby("start_station_name", as_index=False).agg(
    mean_duration=("duration", "mean"),
    median_duration=("duration", "median"),
    description=("start_station_description", "first"),
    popular_end_station=("end_station_name", most_popular),
)

data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"]).size().sort_values()
antall_turer = data.groupby(["start_station_name", "end_station_name"]).size()
antall_turer.loc["AHO"]
antall_turer.loc["AHO", "BI Nydalen"]
antall_turer = data.groupby(["start_station_name", "end_station_name"], as_index=False).size()

antall_turer.pivot_table?
antall_turer.pivot_table(index="start_station_name", columns="end_station_name")
antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="size")
antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="size").fillna(0)
antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="size", fill_value=0)
turmatrise = antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="size", fill_value=0)

#
# Slå sammen data "sidelengs"
#
data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
data[["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
data[["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates().reset_index()
data[["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates().reset_index(drop=True)
posisjon = data[["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates().reset_index(drop=True)

turlengde.merge
turlengde.merge(posisjon)
turlengde_m_pos = turlengde.merge(posisjon)
turlengde.merge?
turlengde.merge(posisjon, left_on="start_station_name", right_on="start_station_name")

#
# Legg data etterhverandre
#
data_feb = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
data_jan = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
pd.concat([data_jan, data_feb])
pd.concat([data_jan, data_feb]).loc[0]
pd.concat([data_jan, data_feb]).reset_index(drop=True)

# Lag en løkke som kan utvides med flere filer
filnavn = ["01.csv", "02.csv"]
for navn in filnavn:
    print(navn)
    
for navn in filnavn:
    print(navn)
    data_måned = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])

data_ark = []
for navn in filnavn:
    print(navn)
    data_måned = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    data_ark.append(data_måned)

filnavn = ["01.csv", "02.csv"]
data_ark = []
for navn in filnavn:
    print(navn)
    data_måned = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    data_ark.append(data_måned)
data = pd.concat(data_ark).reset_index(drop=True)

import pathlib
list(pathlib.Path.glob("*.csv"))

filnavn = pathlib.Path.cwd().glob("*.csv")
data_ark = []
for navn in filnavn:
    print(navn)
    data_måned = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    data_ark.append(data_måned)
data = pd.concat(data_ark).reset_index(drop=True)

#
# Data på kart
#
import folium
kart = folium.Map()
kart.save("bysykler.html")

kart = folium.Map(tiles="Stamen Watercolor")
kart.save("bysykler.html")

kart = folium.Map()   # tiles="Stamen Watercolor")
kart.save("bysykler.html")

import pandas as pd
data = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
data.loc[0]

kart = folium.Map((59.919927, 10.735428))   # tiles="Stamen Watercolor")
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.74))   # tiles="Stamen Watercolor")
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.74), zoom_start=12)   # tiles="Stamen Watercolor")
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.74), zoom_start=12)   # tiles="Stamen Watercolor")
folium.Marker((59.919927, 10.735428), popup="OsloMet").add_to(kart)
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.74), zoom_start=12)   # tiles="Stamen Watercolor")
folium.CircleMarker((59.919927, 10.735428), popup="OsloMet").add_to(kart)
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.74), zoom_start=12)   # tiles="Stamen Watercolor")
folium.CircleMarker((59.919927, 10.735428), popup="OsloMet", fill=True).add_to(kart)
kart.save("bysykler.html")

posisjon = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
    .reset_index(drop=True)
)
posisjon

for stasjon in posisjon.itertuples():
    print(stasjon)

for stasjon in posisjon.itertuples():
    print(stasjon.start_station_name)

kart = folium.Map((59.92, 10.74), zoom_start=12)   # tiles="Stamen Watercolor")
for stasjon in posisjon.itertuples():
    folium.CircleMarker(
        (stasjon.start_station_latitude, stasjon.start_station_longitude),
        popup=stasjon.start_station_name,
        fill=True
    ).add_to(kart)
kart.save("bysykler.html")

antall_turer =  data.groupby("start_station_name", as_index=False).agg(
    name=("start_station_name", "first"),
    latitude=("start_station_latitude", "first"),
    longitude=("start_station_longitude", "first"),
)

antall_turer =  data.groupby("start_station_name", as_index=False).agg(
    name=("start_station_name", "first"),
    latitude=("start_station_latitude", "first"),
    longitude=("start_station_longitude", "first"),
    num_trips=("start_station_name", "count"),
)

kart = folium.Map((59.92, 10.74), zoom_start=12)   # tiles="Stamen Watercolor")
for stasjon in antall_turer.itertuples():
    folium.CircleMarker(
        (stasjon.latitude, stasjon.longitude),
        popup=stasjon.name,
        fill=True
    ).add_to(kart)
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.74), zoom_start=12)   # tiles="Stamen Watercolor")
for stasjon in antall_turer.itertuples():
    folium.CircleMarker(
        (stasjon.latitude, stasjon.longitude),
        popup=stasjon.name,
        radius=stasjon.num_trips,
        fill=True
    ).add_to(kart)
kart.save("bysykler.html")

kart = folium.Map((59.92, 10.74), zoom_start=12)   # tiles="Stamen Watercolor")
for stasjon in antall_turer.itertuples():
    folium.CircleMarker(
        (stasjon.latitude, stasjon.longitude),
        popup=stasjon.name,
        radius=stasjon.num_trips / 10,
        fill=True
    ).add_to(kart)
kart.save("bysykler.html")
