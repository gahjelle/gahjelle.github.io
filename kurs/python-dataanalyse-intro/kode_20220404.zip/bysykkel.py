import pathlib
import pandas as pd

# data_feb = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
# data_mar = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
# data = pd.concat([data_feb, data_mar]).reset_index(drop=True)

filer_som_skal_leses = pathlib.Path.cwd().glob("*.csv")  # ["02.csv", "03.csv"]
data_filer = []
for filnavn in filer_som_skal_leses:
    print(f"Leser {filnavn}")
    data_fil = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_filer.append(data_fil)
data = pd.concat(data_filer).reset_index(drop=True)


antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .to_frame()
    .rename(columns={0: "num_trips"})
    .reset_index()
)

turer = antall_turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="num_trips",
    fill_value=0,
)
