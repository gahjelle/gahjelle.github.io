import folium
import pandas as pd

data = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
stasjoner = data.loc[
    :, ["start_station_name", "start_station_latitude", "start_station_longitude"]
].drop_duplicates()

kart = folium.Map([59.93, 10.75], zoom_start=12)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        [stasjon.start_station_latitude, stasjon.start_station_longitude],
        popup=stasjon.start_station_name,
    ).add_to(kart)

kart.save("bysykkel.html")
