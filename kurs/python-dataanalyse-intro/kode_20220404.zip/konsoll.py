#
# Rask intro til Python
#
1 + 1
navn = "Geir Arne"
navn
Geir Arne   # FEIL: tekst trenger fnutter for å ikke bli tolket av Python
f"Hei {navn}"
tall = 44
tall + 1
tall
tall = tall + 1
tall

#
# Intro til pandas
#
pandas  # FEIL: pandas er ikke definert, pakken må importeres  
import pandas
pandas
import finnes_ikke   # FEIL: pakker må installeres på datamaskinen før de kan importeres
import pandas as pd
pd
pd.read_excel("kap1.xlsx")
data = pd.read_excel("kap1.xlsx")
data = pd.read_excel("kap1.xlsx", sheet_name=2)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
)

[1, 2, 3]

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],  # Alternativt "A:C",
)

data.Budsjettiltak
data.Budsjettiltak * 2
data.Lån og garantier  # FEIL: kan ikke .-referere til kolonner med mellomrom i navnet
data.loc[0]
data.loc[2]
data.loc[:, "Budsjettiltak"]
data.loc[:, "Lån og garantier"]
data.loc[5, "Lån og garantier"]
data.loc["Norge", "Lån og garantier"]  # FEIL: "Norge" er ikke et kolonnenavn (enda)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],  # Alternativt "A:C",
    index_col=0,
)

data.loc["Norge", "Lån og garantier"]
data.loc["Norge"]

data.rename(columns={"Budsjettiltak", "tiltak"})
data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],  # Alternativt "A:C",
    index_col=0,
).rename(columns={
    "Budsjettiltak": "tiltak",
    "Lån og garantier": "lån",
    }
)

data.tiltak
data.lån
data.tiltak + data.lån  # FEIL: data.lån er ikke tall (enda)
daata = data

data.info()
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],  # Alternativt "A:C",
    index_col=0,
    na_values="-",
).rename(columns={
    "Budsjettiltak": "tiltak",
    "Lån og garantier": "lån",
    }
)
data.info()

data.tiltak + data.lån
data.mean()

data.assign(total=data.tiltak + data.lån)
budsjett = data.assign(total=data.tiltak + data.lån)
budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)

data.dropna()
data.fillna(0)
budsjett.fillna(0)
budsjett = (
    data
    .fillna(0)
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],  # Alternativt "A:C",
    index_col=0,
    na_values="-",
).rename(columns={
    "Budsjettiltak": "tiltak",
    "Lån og garantier": "lån",
    }
).fillna(0)

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)

# PAUSE TIL 10:40

budsjett.describe()
budsjett.query("tiltak > 5")
budsjett.query("tiltak > 5").describe()
budsjett.query("tiltak > lån")
budsjett.query("tiltak >= lån")
budsjett.query("tiltak >= 5.2")
budsjett.query("tiltak > 5.2")
budsjett.query("tiltak == 5.2")
1 == 2
1 != 2
budsjett.query("tiltak != 5.2")
norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
budsjett.index
budsjett.index.isin(norden)
budsjett = (
    data
    .assign(
        total=data.tiltak + data.lån,
        i_norden=data.index.isin(norden)
    )
    .sort_values(by="total")
)

budsjett.query("i_norden == True")
budsjett.query("i_norden")
budsjett.query("i_norden and tiltak > 5")
budsjett.query("i_norden or tiltak > 5")
budsjett.query("tiltak > tiltak.median()")

grenseverdi = 8
budsjett.query("total < grenseverdi")   # FEIL: grenseverdi er ikke et kolonnenavn
budsjett.query("total < @grenseverdi")

budsjett.to_excel("budsjett.xlsx")
budsjett.rename(columns={
    "tiltak": "Budsjettiltak",
    }
).to_excel("budsjett.xlsx")

budsjett.plot()
budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(stacked=True)
budsjett.loc[:, "lån"]
budsjett.loc[:, ["tiltak", "lån"]]
budsjett.loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)

#
# Bysykkeldata
#
import pandas as pd

data = pd.read_csv("03.csv")
data.info()
data.loc[0]
data.ended_at - data.started_at  # FEIL: started_at og ended_at er tekstkolonner (foreløbig)

data = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
data.info()
data.ended_at - data.started_at

data.groupby("start_station_name")
data.groupby("start_station_name").median()
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("end_station_name").size().sort_values()

data
antall_turer = (
    data
    .groupby("start_station_name")
    .size()
    .sort_values()
)

antall_turer.to_frame()
antall_turer = (
    data
    .groupby("start_station_name")
    .size()
    .sort_values()
    .to_frame()
    .rename(columns={0: "num_trips"})
)

data.groupby(["start_station_name", "end_station_name"])
data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"]).size().sort_values()
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .to_frame()
    .rename(columns={0: "num_trips"})
)

antall_turer.reset_index()
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .to_frame()
    .rename(columns={0: "num_trips"})
    .reset_index()
)

antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")
turer = antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")
turer = antall_turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="num_trips",
).fillna(0)

turer = antall_turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="num_trips",
    fill_value=0,
)

# PAUSE TIL 11:55
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .to_frame()
    .rename(columns={"0": "num_trips"})  # FEIL: kolonnenavnet er tallet 0
    .reset_index()
)

antall_turer.columns
data.groupby("start_station_name").size().to_frame().columns

data.info()
data_feb = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
data_mar = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
data_feb.info()
pd.concat([data_feb, data_mar])
data = pd.concat([data_feb, data_mar])

antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .to_frame()
    .rename(columns={0: "num_trips"})
    .reset_index()
)

turer = antall_turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="num_trips",
    fill_value=0,
)

pd.concat([data_feb, data_mar])
pd.concat([data_feb, data_mar]).loc[100]
pd.concat([data_feb, data_mar]).reset_index()
pd.concat([data_feb, data_mar]).reset_index().loc[100]
pd.concat([data_feb, data_mar]).reset_index(drop=True)

for land in ["Norge", "Sverige", "Danmark"]:
    print(land)
for land in ["Norge", "Sverige", "Danmark"]:
    print(land, len(land))
for land in ["Norge", "Sverige", "Danmark", "Finland"]:
    print(land, len(land))

filer_som_skal_leses = ["02.csv", "03.csv"]
for filnavn in filer_som_skal_leses:
    data_fil = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])

filer_som_skal_leses = ["02.csv", "03.csv"]
for filnavn in filer_som_skal_leses:
    data_fil = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])

filer_som_skal_leses = ["02.csv", "03.csv"]
for filnavn in filer_som_skal_leses:
    print(f"Leser {filnavn}")
    data_fil = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])

filer_som_skal_leses = ["02.csv", "03.csv"]
data_filer = []
for filnavn in filer_som_skal_leses:
    print(f"Leser {filnavn}")
    data_fil = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_filer.append(data_fil)
data_filer

filer_som_skal_leses = ["02.csv", "03.csv"]
data_filer = []
for filnavn in filer_som_skal_leses:
    print(f"Leser {filnavn}")
    data_fil = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_filer.append(data_fil)
data = pd.concat(data_filer).reset_index(drop=True)

antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .to_frame()
    .rename(columns={0: "num_trips"})
    .reset_index()
)

turer = antall_turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="num_trips",
    fill_value=0,
)

for filnavn in filer_som_skal_leses:
print(f"Leser {filnavn}")  # FEIL: Trenger innrykk i løkker

for filnavn in filer_som_skal_leses:
    print(f"Leser {filnavn}")
    data_fil = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_filer.append(data_fil)
    print("Heisann")

for filnavn in filer_som_skal_leses:
    print(f"Leser {filnavn}")
    data_fil = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_filer.append(data_fil)
print("Heisann")

import pathlib
pathlib.Path.cwd()
pathlib.Path.cwd().glob("*.csv")
list(pathlib.Path.cwd().glob("*.csv"))

filer_som_skal_leses = pathlib.Path.cwd().glob("*.csv")  # ["02.csv", "03.csv"]
data_filer = []
for filnavn in filer_som_skal_leses:
    print(f"Leser {filnavn}")
    data_fil = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_filer.append(data_fil)
data = pd.concat(data_filer).reset_index(drop=True)

#
# Kartvisualiseringer
#
import folium
folium.Map()
kart = folium.Map()
kart.save("bysykkel.html")

import pandas as pd
data = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
data.loc[0]

kart = folium.Map([59.9, 10.75])
kart.save("bysykkel.html")

kart = folium.Map([59.9, 10.75], zoom_start=13)
kart.save("bysykkel.html")

kart = folium.Map([59.93, 10.75], zoom_start=12)
kart.save("bysykkel.html")

kart = folium.Map([59.93, 10.75], zoom_start=12)
folium.Marker([59.922777, 10.738655], popup="Hallings gate").add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map([59.93, 10.75], zoom_start=12)
folium.CircleMarker([59.922777, 10.738655], popup="Hallings gate").add_to(kart)
kart.save("bysykkel.html")

data
data.columns
data.loc[:, ["start_station_name", "start_station_latitude", "start_station_longitude"]]
data.loc[:, ["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
stasjoner = (
    data
    .loc[:, [
        "start_station_name",
        "start_station_latitude",
        "start_station_longitude"
    ]]
    .drop_duplicates()
)

for stasjon in stasjoner:
    print(stasjon)

for stasjon in stasjoner.iterrows():
    print(stasjon)

for idx, stasjon in stasjoner.iterrows():
    print(stasjon)

kart = folium.Map([59.93, 10.75], zoom_start=12)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        [stasjon.start_station_latitude, stasjon.start_station_longitude],
        popup=stasjon.start_station_name
    ).add_to(kart)
kart.save("bysykkel.html")
