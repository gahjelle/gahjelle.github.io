import pandas

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
).fillna(0)

budsjett = data.assign(total=data["tiltak"] + data["lån"]).sort_values(by="total")
