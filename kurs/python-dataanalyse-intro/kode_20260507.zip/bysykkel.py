import pandas

data = pandas.read_csv("02.csv")

# For norske CSV-filer med semikolon som skilletegn
# pandas.read_csv("norsk.csv", delimiter=";", decimal=",")

data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)

trips = data.groupby("start_station_name", as_index=False).agg(
    num_trips=("start_station_name", "count"),
    median_duration=("duration", "median"),
    first_trip=("started_at", "min"),
    sample_end_station=("end_station_name", "first")
)

# Andre kommandoer: sum, mean, max, std, last, ...
# Kan også bruke egendefinerte funksjoner (se heftet)

journeys = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(num_trips=("start_station_name", "count"))
    .sort_values(by="num_trips")
)

locations = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",
        "start_station_longitude": "lon",
    })
    .reset_index(drop=True)
)

# Slå sammen data horisontalt
merged = locations.merge(trips, left_on="name", right_on="start_station_name")

# Slå sammen data vertikalt
data_februar = pandas.read_csv("02.csv")
data_mars = pandas.read_csv("03.csv")
pandas.concat([data_februar, data_mars]).reset_index(drop=True)
