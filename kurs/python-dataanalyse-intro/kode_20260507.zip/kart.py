import pandas
import folium

data = pandas.read_csv("02.csv")
locations = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",
        "start_station_longitude": "lon",
    })
    .reset_index(drop=True)
)

m = folium.Map((59.9, 10.7), zoom_start=13)
for station in locations.itertuples():
    folium.CircleMarker(
        (station.lat, station.lon), popup=station.name, fill=True, radius=15
    ).add_to(m)
m.save("bysykler.html")



trips = data.groupby("start_station_name", as_index=False).agg(
    num_trips=("start_station_name", "count"),
    median_duration=("duration", "median"),
    first_trip=("started_at", "min"),
    sample_end_station=("end_station_name", "first")
)
merged = locations.merge(trips, left_on="name", right_on="start_station_name")

m = folium.Map((59.9, 10.7), zoom_start=13)
for station in merged.itertuples():
    folium.CircleMarker(
        (station.lat, station.lon), popup=station.name, fill=True, radius=station.num_trips//4
    ).add_to(m)
m.save("bysykkelbruk.html")
