#
# Intro: variabler
#
1 + 2
tall = 3
tall
tall + 4
tall = 5
tall = "sju"
tall + 4
tall = 3.14
tall + 4
navn = "Geir Arne"
# Geir Arne  # Feil: syntaksfeil, kan ikke ha mellomrom her
# Geir       # Feil: ukjent navn
"Hei navn"
f"Hei {navn}"

#
# Les Excel med pandas
#
import pandas
pandas
pandas.read_excel
pandas.read_excel()  # Feil, trenger et filnavn
pandas.read_excel("kap1.xlsx")
data = pandas.read_excel("kap1.xlsx")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
navn
navn[1]  # Teller fra 0 så henter ut andre element
navn[0]
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data
data.info()
data["Budsjettiltak"]
data["Budsjettiltak"] * 2 + 10
data["Lån og garantier"]
data["Lån og garantier"] * 2 + 10  # Feil: lån og garantier er tekst så kan ikke regnes med
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, na_values="-")
data.info()
data["Lån og garantier"] * 2 + 10
data["lån og garantier"] * 2 + 10  # Feil: liten forbokstav - store og små bokstaver er forskjellige
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, na_values="-", names=["land", "tiltak", "lån"])
data
data["tiltak"] + data["lån"]
fib = [1, 1, 2, 3, 5, 8, 13]
fib[5]

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
)

data

#
# Håndter manglende verdier
#
data.dropna()
data  # Kommandoer lager kopier, de endrer ikke de originale dataene
data.dropna(axis="columns")
data.fillna(0)
data.ffill()
data.bfill()
data.interpolate()

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
).fillna(0)

# Pause til 10:31

#
# Transformering og filtrering av data
#
data["tiltak"] + data["lån"]
data.assign(total=data["tiltak"] + data["lån"])
data.assign(total=data["tiltak"] + data["lån"], en=1)
data
budsjett = data.assign(total=data["tiltak"] + data["lån"])

budsjett.query("tiltak > 5")
tiltak > 5  # Feil: tiltak er et kolonnenavn i budsjett, men det er ikke et navn Python kjenner
budsjett.query("tiltak > 5 or lån > 10")
budsjett.query("lån != 0")  # ulik
budsjett.query("lån == 0")  # erlik

budsjett.query("lån != 0").sort_values(by="total")
budsjett = data.assign(total=data["tiltak"] + data["lån"]).sort_values(by="total")

#
# Grafer og figurer
#
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.bar(x="land")
budsjett.plot.barh(x="land")
budsjett.plot.barh(x="land", stacked=True)
budsjett.plot.barh(x="land", y=["tiltak", "lån"], stacked=True)
budsjett.plot.barh(x="land", y=["tiltak", "lån"], stacked=True, title="Pandemirespons")
budsjett.to_excel("budsjett.xlsx")

#
# Les bysykkeldata fra https://oslobysykkel.no/apne-data
#
import pandas
data = pandas.read_csv("03.csv")
data = pandas.read_csv("02.csv")
# pandas.read_csv("norsk.csv", delimiter=";", decimal=",")
data.info()

#
# Håndter dato og tid
#
pandas.to_datetime(data["started_at"])  # Feil: filen bruker inkonsekvente datoformater
pandas.to_datetime(data["started_at"], format="ISO8601")
data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
)
data.info()
data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)
data.info()
data["ended_at"] - data["started_at"]

#
# Gruppering og aggregering
#
data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("end_station_name").size().sort_values()

data.groupby("start_station_name").agg(median_duration=("duration", "median"))
data.groupby("start_station_name").agg(num_trips=("start_station_name", "count"), median_duration=("duration", "median"))

data.groupby("start_station_name", as_index=False).agg(
    num_trips=("start_station_name", "count"),
    median_duration=("duration", "median"),
)

data.groupby("start_station_name", as_index=False).agg(
    num_trips=("start_station_name", "count"),
    median_duration=("duration", "median"),
    first_trip=("started_at", "min"),
)

data.groupby("start_station_name", as_index=False).agg(
    num_trips=("start_station_name", "count"),
    median_duration=("duration", "median"),
    first_trip=("started_at", "min"),
    sample_end_station=("end_station_name", "first")
)

trips = data.groupby("start_station_name", as_index=False).agg(
    num_trips=("start_station_name", "count"),
    median_duration=("duration", "median"),
    first_trip=("started_at", "min"),
    sample_end_station=("end_station_name", "first")
)

#
# Python løkker og pandas grupper
#
["Norge", "Sverige", "Danmark"]
for land in ["Norge", "Sverige", "Danmark"]:
    print(land)

for land in ["Norge", "Sverige", "Danmark"]:
    print(land)
    print(f"{land} har {len(land)} bokstaver")

for land in ["Norge", "Sverige", "Danmark"]:
    print(land)
print(f"{land} har {len(land)} bokstaver")

for group in data.groupby("start_station_name"):
    print(group)

for name, group_data in data.groupby("start_station_name"):
    print(name, len(group_data))

#
# Grupper på flere kolonner
#
data.groupby("start_station_name")
data.groupby(["start_station_name", "end_station_name"], as_index=False).agg(num_trips=("start_station_name", "count"))
data.groupby(["start_station_name", "end_station_name"], as_index=False).agg(num_trips=("start_station_name", "count")).sort_values(by="num_trips")
j
ourneys = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(num_trips=("start_station_name", "count"))
    .sort_values(by="num_trips")
)
journeys
journeys.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")
overview = journeys.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")
overview = journeys.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips", fill_value=0)

# Pause til 12:03

# 
# Hent ut unike stasjonsdata
#
trips
data["start_station_name"]  # Hent en kolonne
data[["start_station_name"]]  # Hent en dataframe med en kolonne
data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
data[["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
data[["start_station_name", "end_station_name"]].drop_duplicates()
data[["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
data[["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates().rename(columns={"start_station_name": "name"})

locations = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
    .rename(columns={"start_station_name": "name", "start_station_latitude": "lat"})
)
locations

locations = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",
        "start_station_longitude": "lon",
    })
)
locations

locations = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",
        "start_station_longitude": "lon",
    })
    .reset_index()
)
locations

locations = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",
        "start_station_longitude": "lon",
    })
    .reset_index(drop=True)
)
locations

#
# Slå sammen data horisontalt
#
location.merge(trips)
locations.merge(trips)
locations.merge(trips, left_on="name", right_on="start_station_name")
merged = locations.merge(trips, left_on="name", right_on="start_station_name")
merged = locations.merge(trips, left_on="name", right_on="start_station_name", how="inner")

#
# Slå sammen data vertikalt
#
data_februar = pandas.read_csv("02.csv")
data_mars = pandas.read_csv("03.csv")
data_februar
data_mars
pandas.concat([data_februar, data_mars])
pandas.concat([data_februar, data_mars]).reset_index(drop=True)

#
# Legg data på et interaktivt kart
#
import pandas
import folium

data = pandas.read_csv("02.csv")
locations = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",
        "start_station_longitude": "lon",
    })
    .reset_index(drop=True)
)
locations

m = folium.Map()
m.save("bysykler.html")

m = folium.Map((59.9, 10.7))
m.save("bysykler.html")

m = folium.Map((59.9, 10.7), zoom_start=10)
m.save("bysykler.html")

m = folium.Map((59.9, 10.7), zoom_start=13)
m.save("bysykler.html")

m = folium.Map((59.9, 10.7), zoom_start=13)
folium.Marker((59.917281, 10.708376), popup="Gimle Kino").add_to(m)
m.save("bysykler.html")

m = folium.Map((59.9, 10.7), zoom_start=13)
folium.CircleMarker((59.917281, 10.708376), popup="Gimle Kino").add_to(m)
m.save("bysykler.html")

m = folium.Map((59.9, 10.7), zoom_start=13)
folium.CircleMarker((59.917281, 10.708376), popup="Gimle Kino", fill=True).add_to(m)
m.save("bysykler.html")

m = folium.Map((59.9, 10.7), zoom_start=13)
folium.CircleMarker((59.917281, 10.708376), popup="Gimle Kino", fill=True, radius=30).add_to(m)
m.save("bysykler.html")

m = folium.Map((59.9, 10.7), zoom_start=13)
folium.Circle((59.917281, 10.708376), popup="Gimle Kino", fill=True, radius=30).add_to(m)
m.save("bysykler.html")

m = folium.Map((59.9, 10.7), zoom_start=13)
folium.CircleMarker((59.917281, 10.708376), popup="Gimle Kino", fill=True, radius=30).add_to(m)
m.save("bysykler.html")

for station in locations:
    print(station)

for station in locations.itertuples():
    print(station)

station
station.name
station.lat
station.lon

m = folium.Map((59.9, 10.7), zoom_start=13)
for station in locations.itertuples():
    folium.CircleMarker(
        (station.lat, station.lon), popup=station.name, fill=True, radius=15
    ).add_to(m)
m.save("bysykler.html")

#
# Inkluder turhistorikk i kartet
#
trips = data.groupby("start_station_name", as_index=False).agg(
    num_trips=("start_station_name", "count"),
    median_duration=("duration", "median"),
    first_trip=("started_at", "min"),
    sample_end_station=("end_station_name", "first")
)
merged = locations.merge(trips, left_on="name", right_on="start_station_name")

m = folium.Map((59.9, 10.7), zoom_start=13)
for station in merged.itertuples():
    folium.CircleMarker(
        (station.lat, station.lon), popup=station.name, fill=True, radius=station.num_trips
    ).add_to(m)
m.save("bysykkelbruk.html")

m = folium.Map((59.9, 10.7), zoom_start=13)
for station in merged.itertuples():
    folium.CircleMarker(
        (station.lat, station.lon), popup=station.name, fill=True, radius=station.num_trips//4
    ).add_to(m)
m.save("bysykkelbruk.html")
