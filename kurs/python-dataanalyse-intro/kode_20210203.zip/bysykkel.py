# Data fra https://oslobysykkel.no/apne-data/historisk

import pandas as pd

filer = ["12.csv", "01.csv"]

data_ark = []
for filnavn in filer:
    ark = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_ark.append(ark)

data = pd.concat(data_ark)


data.groupby("start_station_name").size().sort_values(ascending=False)

antall_turer = (
 data.groupby(["start_station_name", "end_station_name"])
 .size()
 .sort_values(ascending=False)
 .reset_index()
 .rename(columns={0: "num_trips"})
)

t = antall_turer.pivot_table(
    values="num_trips",
    index="start_station_name",
    columns="end_station_name",
    fill_value=0,
    aggfunc=sum,
)

# data_desember = pd.read_csv(
#     r"C:\Users\giron\kurs\12.csv",
#     sep=",",
#     parse_dates=["started_at", "ended_at"]
# )

# data_januar = pd.read_csv(
#     r"C:\Users\giron\kurs\01.csv",
#     sep=",",
#     parse_dates=["started_at", "ended_at"]
# )
