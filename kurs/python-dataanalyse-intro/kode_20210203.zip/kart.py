import folium
import pandas as pd

filer = ["12.csv", "01.csv"]

data_ark = []
for filnavn in filer:
    ark = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_ark.append(ark)

data = pd.concat(data_ark)

kart = folium.Map([59.95, 10.75], zoom_start=12)
folium.Marker([59.9255, 10.7312], popup="Bislett Stadion").add_to(kart)
kart.save("bysykkel.html")
