import pandas as pd

norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    usecols=[0, 1, 2],
    header=4,
    index_col=0,
    na_values="-",
).rename(
    columns={
        "Budsjettiltak": "budsjett",
        "Lån og garantier": "lån"
    }
)

data_uten_na = data.fillna(value=0)
    
totalt = (
    data_uten_na
    .assign(
        total=data_uten_na.lån + data_uten_na.budsjett,
        i_norden=data_uten_na.index.isin(norden),
    )
    .sort_values(by="total", ascending=False)
)


(
    totalt
    .query("i_norden")
    .loc[:, ["budsjett", "lån", "total"]]
    .rename(
        columns={
            "budsjett": "Budsjettiltak",
            "lån": "Lån og garantier",
            "total": "Total",     
            }
        )
    .to_excel("budsjett.xlsx", na_rep="-")
)
