#
# Introduksjon
#
print("Hei Python")
1 + 2
print("Hei Python!")
navn = "Geir Arne"
Geir Arne
navn
antall = 30
pi = 3.14
antall + 3
antall + pi
antall + navn  # Gir feilmelding, tall og tekst kan ikke plusses sammen
navn * antall
navn = input("Hva heter du? ")
navn * antall
"Hei {navn}"
f"Hei {navn}"
f"Hei {navn}, tallet er {antall}"
f"Hei {navn}, tallet er {antall + pi}"
1 + 2

#
# Revidert statsbudsjett
#
import pandas as pd
pd

# Les data fra Excel
pd.read_excel
pd.read_excel?  # Få hjelp om en kommando
pd.read_excel("kap1.xlsx")
pd.read_excel("kap1.xlsx", sheet_name="1.2")
pd.read_excel("kap1.xlsx", sheet_name=2)
runfile('C:/Users/giron/kurs/budsjett.py', wdir='C:/Users/giron/kurs')

# Hent ut rader, kolonner og celler
data
data.loc["Norge"]
data.loc["Budsjettiltak"]
data.loc["Norge", "Budsjettiltak"]
data.loc[:, "Budsjettiltak"]
data.Budsjettiltak
data.Lån og garantier  # Gir feilmelding, ikke gyldig navn
data.loc[:, "Budsjettiltak"]
data.loc[:, "budsjettiltak"]  # Gir feilmelding, viktig med store og små bokstaver
data
data.rename(columns={"Budsjettiltak": "budsjett"})
data.rename(columns={"Budsjettiltak": "budsjett", "Lån og garantier": "lån"})

# Få oversikt over dataene
data.head()
data.head(7)
data.info()
data.loc["Norge", "lån"]

# Pause til 10:30
#
# Gå til https://oslobysykkel.no/apne-data/historisk
# Last ned CSV filer for desember og januar

# Operasjoner på kolonner
data.lån
data.lån + 1
data.lån + data.budsjett
data
data.assign(total=data.lån + data.budsjett)
data
totalt = data.assign(total=data.lån + data.budsjett)
totalt
data
totalt.dropna()
data
data_uten_na = data.fillna(value=0)
data.fillna?

# Koble til andre data
norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
totalt
totalt.assign(i_norden=totalt.index.isin(norden))

# Spørringer
totalt.query("total > 10")
totalt.query("budsjett > lån")
totalt.query("i_norden")
totalt.query("i_norden == True")
1 == 1
1 == 2
totalt.query("not i_norden")
grense = 5
totalt.query("budsjett > grense")
totalt.query("budsjett > @grense")
totalt.query("budsjett > @grense and i_norden")
totalt.head()

# Sammenligninger i Python
grense
grense == 5
grense == 6
grense > 4
grense < 4
grense >= 4
grense >= 5
grense > 5
grense <= 5
totalt.query("lån >= 10")
grense != 5
grense != 6

# Skriv tilbake til Excel
totalt.to_excel?
totalt.to_excel("budsjett.xlsx")

# Tegn figurer
totalt
totalt.plot()
totalt.plot.line()
totalt.plot.bar()
totalt.plot.bar(y="total")
totalt.plot.bar(stacked=True)
totalt.plot.bar(y=["lån", "total"], stacked=True)
totalt.plot.bar(y=["lån", "budsjett"], stacked=True)

#
# Bysykler
#

runfile('C:/Users/giron/kurs/bysykkel.py', wdir='C:/Users/giron/kurs')
data.head()
data.columns
data.info()

# Operasjoner på datoer og klokkeslett
data.ended_at
data.ended_at - data.started_at
data.duration
17*60 + 4
data.duration.plot()
data.duration.plot.line(style=".")
data.duration.plot.line(style=".", alpha=0.2)
data.head()

# Bruk datokolonner som indeks
data.set_index("started_at")
data.set_index("started_at").duration
data.set_index("started_at").duration.plot.line(style=".", alpha=0.2)
data.set_index("started_at")
data.set_index("started_at").loc["2021-01-28"]
data.set_index("started_at").loc["2021-01-28"].plot.line(style=".")
data.set_index("started_at").loc["2021-01-28"].duration.plot.line(style=".")
data.set_index("started_at").loc["2021-01-28"].duration.plot.line(style=".", alpha=0.2)

# Pause til 12:00

# Slå sammen flere datasett
runfile('C:/Users/giron/kurs/bysykkel.py', wdir='C:/Users/giron/kurs')
pd.concat([data_desember, data_januar])
filer = ["12.csv", "01.csv"]
data_ark = []
for filnavn in filer:
    ark = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])

filer = ["12.csv", "01.csv"]
data_ark = []
for filnavn in filer:
    ark = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_ark.append(ark)
data_ark
pd.concat(data_ark)

filer = ["12.csv", "01.csv", "12.csv"]
data_ark = []
for filnavn in filer:
    ark = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_ark.append(ark)
data = pd.concat(data_ark)
data

# Grupper data
data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("start_station_name").size().sort_values(ascending=False)
data.groupby("start_station_name").median()
data.info()
data.groupby("start_station_name").median()
data.groupby("start_station_name").median().duration
data.groupby("start_station_name").median().duration.sort_values()
data.groupby(["start_station_name", "end_station_name"]).size()
(
 data.groupby(["start_station_name", "end_station_name"])
 .size()
 .sort_values(ascending=False)
)
antall_turer = (
 data.groupby(["start_station_name", "end_station_name"])
 .size()
 .sort_values(ascending=False)
)
antall_turer = (
 data.groupby(["start_station_name", "end_station_name"])
 .size()
 .sort_values(ascending=False)
 .reset_index()
 .rename(columns={0: "num_trips"})
)
antall_turer.query("start_station_name == 'AHO'")
antall_turer.query("start_station_name == "AHO"")

# Pivot-tabell
antall_turer.pivot_table?
antall_turer
antall_turer.pivot_table(values="num_trips", index="start_station_name", columns="end_station_name")
t = antall_turer.pivot_table(
    values="num_trips",
    index="start_station_name",
    columns="end_station_name"
)

antall_turer.pivot_table?
t = antall_turer.pivot_table(
    values="num_trips",
    index="start_station_name",
    columns="end_station_name",
    fill_value=0,
)

t = antall_turer.pivot_table(
    values="num_trips",
    index="start_station_name",
    columns="end_station_name",
    fill_value=0  # Gir feilmelding pga manglende komma
    aggfunc=sum
)

t = antall_turer.pivot_table(
    values="num_trips",
    index="start_station_name",
    columns="end_station_name",
    fill_value=0,
    aggfunc=sum,
)

# Standardbiblioteket
import math
math.pi
math.cos(maph.pi)
math.cos(math.pi)

#
# Kart
#
runfile('C:/Users/giron/kurs/kart.py', wdir='C:/Users/giron/kurs')

# Folium bruker JavaScriptbiblioteket LeafletJS
# Se https://python-visualization.github.io/folium/
# og https://leafletjs.com/ for informasjon om pakkene

data
data.loc[0]
data.loc[0].T

kart = folium.Map([59.95, 10.75], zoom_start=12)
folium.CircleMarker([59.9255, 10.7312], popup="Bislett Stadion").add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map([59.95, 10.75], zoom_start=12)
folium.CircleMarker([59.9255, 10.7312], popup="Bislett Stadion", fill=True).add_to(kart)
kart.save("bysykkel.html")

data
data.loc[:, ["start_station_name", "start_station_latitude", "start_station_longitude"]]
data.loc[:,
         [
             "start_station_name",
             "start_station_latitude",
             "start_station_longitude"
         ]
    ].drop_duplicates()

data = pd.concat(data_ark)
stasjoner = data.loc[:,
         [
             "start_station_name",
             "start_station_latitude",
             "start_station_longitude"
         ]
    ].drop_duplicates()
kart = folium.Map([59.95, 10.75], zoom_start=12)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        [stasjon.start_station_latitude, stasjon.start_station_longitude],
        popup=stasjon.start_station_name,
        fill=True
    ).add_to(kart)
kart.save("bysykkel.html")

# Du kan hente historikken i konsollet i Spyder ved hjelp av history
history?
history -f konsoll.py
