import pandas as pd

filnavn = pathlib.Path().glob("*.csv")  # Alternativt ["11.csv", "12.csv"]
månedsdata = []
for navn in filnavn:
    print(f"Leser inn {navn}")
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    månedsdata.append(enkeltdata)

data = pd.concat(månedsdata)

# data_nov = pd.read_csv(
#     "11.csv",
#     sep=",",
#     parse_dates=["started_at", "ended_at"]
# )
# data_des = pd.read_csv(
#     "12.csv",
#     sep=",",
#     parse_dates=["started_at", "ended_at"]
# )
# data = pd.concat([data_nov, data_des])


data.groupby("start_station_name").size()

(
    data
    .query("start_station_name == 'Helga Helgesens plass'")
    .groupby("end_station_name")
    .size()
    .sort_values()
)

turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values(ascending=False)
    .reset_index()
    .rename(columns={0: "antall_turer"})
)

tur_matrise = turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="antall_turer",
    fill_value=0,
)





