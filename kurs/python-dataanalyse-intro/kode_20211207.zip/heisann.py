"""Et lite eksempelprogram"""

def si_hei(navn):
    """Her er dokumentasjonen til si_hei()"""
    print(f"Heisann {navn}")

navn = input("Hva heter du? ")
si_hei(navn)
