#
# Introduksjon
#

1 + 2
tall = 3
tall
navn = "Geir Arne"
navn = Geir Arne   # Feil: Geir og Arne er ikke pythonkommandoer
print
print("Hei")
print(f"Hei {navn}")
navn = "Tekna"
print(f"Hei {navn}")
def si_hei(navn):
    print(f"Heisann {navn}")
si_hei
si_hei("Geir Arne")

#
# Les Excelark med pandas
#
import pandas   # Vanligvis ikke gjort, pleier å bruke pd som alias
import panda  # Feil: panda er feilstavet
pandas.read_excel  # Kan stave ut pandas, men vanligvis ikke gjort

import pandas as pd
pd.read_excel
pd.read_excel("kap1.xlsx")
data = pd.read_excel("kap1.xlsx")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:C")
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
)

# Eksempler på lister
[1, 4, 9]
len([1, 4, 9])
[1, "Geir Arne", 3.14]

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
)

def si_hei(navn):
    """Her er dokumentasjonen til si_hei()"""
    print(f"Heisann {navn}")
help(si_hei)
help(pd.read_excel)
pd.read_excel?  # Spørsmåltegn kan også brukes for å få hjelp

data
data.loc[14]
data.Budsjettiltak
data.lån og garantier  # Feil
data.loc[14, "Lån og garantier"]
data.loc[:, "Lån og garantier"]

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
).rename(columns={"Lån og garantier": "lån"})
data.lån

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
).rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
    index_col=0,
).rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})

data.loc["Norge"]
data.tiltak
data.loc["Sverige", "tiltak"]
data.tiltak * 2
data.tiltak + data.lån

# Rask oversikt over grunnleggende datatyper i Python
# str: tekst (string)
# float: desimaltall (floating point number)
# int: heltall (integer)
# bool: sann/usann (boolean value)
#
# Se f.eks. https://realpython.com/python-data-types/ for mer info
# eller søk på "Data types i Python"

data.tiltak * 3
data.tiltak = data.tiltak * 3
data.info()

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
    index_col=0,
    na_values="-",
).rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})
data.info()

# Pause til 10:42

data.assign(total=data.tiltak + data.lån)
budsjett = data.assign(total=data.tiltak + data.lån)
data.dropna()
data.dropna?
data.dropna(axis="columns")
data.fillna(0)
budsjett = data.assign(total=data.tiltak + data.lån).fillna(0)
budsjett = (data.assign(total=data.tiltak + data.lån).fillna(0))

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .fillna(0)
)

budsjett = (
    data
    .fillna(0)
    .assign(total=data.tiltak + data.lån)
)

budsjett = (
    data
    .fillna(0)
    .assign(total=data.tiltak + data.fillna(0).lån)
)

data = (
    pd.read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        usecols=[0, 1, 2],   # Alternativt "A:C",
        index_col=0,
        na_values="-",
    )
    .rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})
    .fillna(0)
)

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
)

budsjett.sort_index()
budsjett.sort_values?
budsjett.sort_values(by="total")

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)

norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
data.index
data.index.isin(norden)

budsjett = (
    data
    .assign(
        total=data.tiltak + data.lån,
        i_norden=data.index.isin(norden),
    )
    .sort_values(by="total")
)

# Spørringer
budsjett.query("total > 10")
budsjett.query("total > 11")
budsjett.query("total >= 11")
total >= 11
budsjett.query("i_norden")
budsjett.query("i_norden and total > 10")
budsjett.query("i_norden or total > 10")

# Skriving tilbake til Excel
budsjett.to_excel?
budsjett.to_excel("budsjett.xlsx")
(
     budsjett
     .rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})
     .to_excel("budsjett.xlsx")
)

(
     budsjett
     .rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})
     .to_excel("budsjett.xlsx")
)

(
   budsjett
   .rename(columns={"lån": "Lån og garantier", "tiltak": "Budsjettiltak"})
   .to_excel("budsjett.xlsx")
)

(
   budsjett
   .query("i_norden")
   .rename(columns={"lån": "Lån og garantier", "tiltak": "Budsjettiltak"})
   .to_excel("norden.xlsx")
)

(
    budsjett
   .query("i_norden")
   .drop(columns="i_norden")
   .rename(columns={"lån": "Lån og garantier", "tiltak": "Budsjettiltak"})
   .to_excel("norden.xlsx")
)

(
   budsjett
   .query("i_norden")
   .drop(columns="i_norden")
   .rename(columns={"lån": "Lån og garantier", "tiltak": "Budsjettiltak"})
   .to_excel("norden.xlsx")
)

# Figurer
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(stacked=True)
budsjett.drop(columns="total").plot.barh(stacked=True)
budsjett.loc[:, "tiltak"]
budsjett.loc[:, ["tiltak", "lån"]]
budsjett.loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)

#
# Bysykkeldata
#
import pandas as pd
data = pd.read_csv("11.csv")
data = pd.read_csv("11.csv", sep=";")  # Feil, men kan brukes om ; er skilletegn
data = pd.read_csv("11.csv", sep=",")
data.info()

data = pd.read_csv("11.csv", sep=",", parse_dates=["started_at", "ended_at"])
data.info()
data.ended_at - data.started_at

data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.query("start_station_name == 'Helga Helgesens plass'")
data.query("start_station_name == 'Helga Helgesens plass'").groupby("end_station_name").size()
data.query("start_station_name == 'Helga Helgesens plass'").groupby("end_station_name").size().sort_values()
"start_station_name == 'Helga Helgesens plass'"

data.groupby("start_station_name")
data.groupby("start_station_name").mean()
data.groupby("start_station_name").mean().loc["duration"]
data.groupby("start_station_name").mean().loc[:, "duration"]
data.groupby("start_station_name").mean().loc[:, "duration"].sort_values()

data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"]).size().sort_values()
turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
)

turer.reset_index()
turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "antall_turer"})
)

turer.pivot_table(index="start_station_name", columns="end_station_name", values="antall_turer")
tur_matrise = turer.pivot_table(index="start_station_name", columns="end_station_name", values="antall_turer")

tur_matrise = turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="antall_turer",
    fill_value=0,
)

# Pause til 12:20

data_nov = pd.read_csv(
    "11.csv",
    sep=",",
    parse_dates=["started_at", "ended_at"]
)
data_des = pd.read_csv(
    "12.csv",
    sep=",",
    parse_dates=["started_at", "ended_at"]
)
pd.concat([data_nov, data_des])
data = pd.concat([data_nov, data_des])

turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values(ascending=False)
    .reset_index()
    .rename(columns={0: "antall_turer"})
)
tur_matrise = turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="antall_turer",
    fill_value=0,
)

filnavn = ["11.csv", "12.csv"]
for navn in filnavn:
    print(navn)

filnavn = ["11.csv", "12.csv"]
for navn in filnavn:
    print(f"Leser inn {navn}")
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])

månedsdata = []
for navn in filnavn:
    print(f"Leser inn {navn}")
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    månedsdata.append(enkeltdata)

data = pd.concat(månedsdata)


import pathlib
pathlib.Path().glob("*.csv")
list(pathlib.Path().glob("*.csv"))

filnavn = pathlib.Path().glob("*.csv")  # Alternativt ["11.csv", "12.csv"]
månedsdata = []
for navn in filnavn:
    print(f"Leser inn {navn}")
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    månedsdata.append(enkeltdata)

data = pd.concat(månedsdata)

månedsdata
månedsdata.query
månedsdata[0]
månedsdata[0].query

#
# Vis informasjon på kart
#
import folium

kart = folium.Map()
kart.save("bysykkel.html")

data_des.loc[0]
kart = folium.Map(location=[59.9, 10.7], zoom_start=13)
kart.save("bysykkel.html")

kart = folium.Map(location=[59.93, 10.7], zoom_start=12)
kart.save("bysykkel.html")

kart = folium.Map(location=[59.93, 10.7], zoom_start=12)
folium.CircleMarker(
    location=[59.925265, 10.750462],
    popup="AHO"
).add_to(kart)
kart.save("bysykkel.html")

stasjoner = data.loc[:, ["start_station_name", "start_station_longitude", "start_station_latitude"]]
stasjoner = data.loc[:, ["start_station_name", "start_station_longitude", "start_station_latitude"]].drop_duplicates()
for stasjon in stasjoner.iterrows():
    print(stasjon)

for idx, stasjon in stasjoner.iterrows():
    print(stasjon)

stasjoner = data.loc[:, 
   ["start_station_name"
    , "start_station_longitude"
    , "start_station_latitude"]].drop_duplicates()

kart = folium.Map(location=[59.93, 10.7], zoom_start=12)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=[stasjon.start_station_latitude,
                  stasjon.start_station_longitude],       
        popup=stasjon.start_station_name
    ).add_to(kart)
kart.save("bysykkel.html")
