import folium

stasjoner = data.loc[:, 
   ["start_station_name"
    , "start_station_longitude"
    , "start_station_latitude"]].drop_duplicates()

kart = folium.Map(location=[59.93, 10.7], zoom_start=12)

for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=[stasjon.start_station_latitude,
                  stasjon.start_station_longitude],       
        popup=stasjon.start_station_name
    ).add_to(kart)

kart.save("bysykkel.html")
