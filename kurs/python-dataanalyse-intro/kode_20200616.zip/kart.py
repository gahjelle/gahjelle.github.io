import folium
import pandas as pd

data = pd.read_csv("05.csv", sep=",",
                   parse_dates=["started_at", "ended_at"])
stasjoner = (
    data.loc[:, [
            "start_station_id",
            "start_station_name",
            "start_station_latitude",
            "start_station_longitude",
        ]]
    .drop_duplicates()
    .rename(columns={
            "start_station_id": "id",
            "start_station_name": "name",
            "start_station_latitude": "lat",
            "start_station_longitude": "lon",        
        })
    .set_index("id")
    )
antall_turer = data.groupby("start_station_id").size()

kart = folium.Map(location=[59.9, 10.75], zoom_start=11)

for id in stasjoner.index:
    posisjon = [stasjoner.loc[id, "lat"], stasjoner.loc[id, "lon"]]
    folium.Circle(posisjon,
          popup=f"{stasjoner.loc[id, 'name']}: {antall_turer.loc[id]}",
          radius=antall_turer.loc[id] / 100,
          fill=True).add_to(kart)

kart.save("bysykkel_kart.html")



# folium.CircleMarker(
#     location=[45.5215, -122.6261],
#     radius=50,
#     popup='Laurelhurst Park',
#     color='#3186cc',
#     fill=True,
#     fill_color='#3186cc'
# ).add_to(m)