import pandas as pd

norden = {"Norge", "Sverige", "Danmark",
          "Finland", "Island"}


data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],
    na_values="-",
    index_col=0,
    ).rename(
        columns={
            "Budsjettiltak": "tiltak",
            "Lån og garantier": "lån"
            }
        )

budsjett = (
    data.fillna(value=0)
    .assign(
        total=lambda nå: nå.tiltak + nå.lån,
        i_norden=lambda nå: nå.index.isin(norden))
    .sort_values(by="total")
)

(
    budsjett.query("i_norden")
    .rename(
        columns={
            "tiltak": "Budsjettiltak",
            "lån": "Lån og garantier",
            "i_norden": "Norden?",
        })
    .to_excel("totalt.xlsx")
)

# Skrive data til Excel
budsjett_norden = budsjett.query("i_norden")
budsjett_norden_navn = budsjett_norden.rename(
        columns={
            "tiltak": "Budsjettiltak",
            "lån": "Lån og garantier",
            "i_norden": "Norden?",
        })
budsjett_norden_navn.to_excel("totalt.xlsx", sheet_name="1.2")

# Plotte en figur
(
    budsjett.loc[:, ["tiltak", "lån"]]
    .plot(kind="bar", stacked=True)
)

# pd.read_excel?