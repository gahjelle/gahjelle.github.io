import pandas as pd

data = pd.read_csv("05.csv", sep=",",
                   parse_dates=["started_at", "ended_at"])


data.duration.plot()


data.plot(x="started_at", y="duration")

turer = data.set_index("started_at").loc["2020-05-17"]

turer.groupby("start_station_name").size()

lengde = (
    turer.groupby("start_station_name")
    .mean()
    .sort_values(by="duration")
)

antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .count()
    .sort_values(by="duration")
)