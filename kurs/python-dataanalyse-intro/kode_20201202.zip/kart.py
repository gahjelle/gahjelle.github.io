import folium
import pandas as pd

# Les inn bysykkel data (tilsvarende bysykler.py)
data = pd.read_csv("11.csv", parse_dates=["started_at", "ended_at"])

# Antall turer som starter fra en gitt stasjon
antall_turer = (
    data.
    groupby(["start_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

# Stasjonsinfomasjon: navn, koordinater, antall turer
stasjoner = (
    data.loc[:, [
        "start_station_id",
        "start_station_name",
        "start_station_latitude",
        "start_station_longitude"
        ]]
    .drop_duplicates()
    .merge(antall_turer, on="start_station_name")
)

# Lag et kart
kart = folium.Map(location=[59.93, 10.8], zoom_start=12)

# Legg til hver stasjon som en markør på kartet
for radnummer, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        [stasjon.start_station_latitude, stasjon.start_station_longitude],
        popup=stasjon.start_station_name,
        radius=stasjon.num_trips / 30,
        fill=True
    ).add_to(kart)

# Lagre kartet som en HTML-fil
kart.save("kart.html")


# Andre typer markører
folium.Marker(
    [59.9267, 10.7162],
    popup="Majorstuveien").add_to(kart)

folium.CircleMarker(
    [59.9328, 10.7345],
    popup="Adamstuen", fill=True).add_to(kart)

folium.Circle(
    [59.9232, 10.7662],
    radius=100,
    popup="Sofienbergparken nord").add_to(kart)

