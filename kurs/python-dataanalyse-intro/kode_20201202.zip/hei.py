# input() spør brukeren
# = tilordner til variabelen navn
navn = input("Hva heter du? ")

# Formatert tekst med f foran fnutten gir mulighet
# for å bruke variabler i krøllparantes
print(f"Hei {navn}")
