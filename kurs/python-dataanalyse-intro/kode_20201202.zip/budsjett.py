import pandas as pd

norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]

# Les inn Excelark og gi kolonnene enklere navn
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],
    index_col=0,
    na_values=["-", "ingenting"],
).rename(
    columns={"Budsjettiltak": "tiltak",
             "Lån og garantier": "lån"}
)

# Sett manglende verdi for Nederland til 0
data_uten_na = data.fillna(value=0)

# Legg til nye kolonner og sorter dataene
budsjett = (
    data_uten_na
    # .fillna(value=0)
    .assign(total = data_uten_na.tiltak + data_uten_na.lån,
            i_norden = data_uten_na.index.isin(norden))
    .sort_values(by="total")
)

# Skriv data til Excel med mer utfyllende kolonnenavn
budsjett.rename(
    columns={"tiltak": "Budsjettiltak",
             "lån": "Lån og garantier"}
    ).to_excel("budsjett.xlsx")
