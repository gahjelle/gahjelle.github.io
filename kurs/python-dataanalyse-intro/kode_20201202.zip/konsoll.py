# Introduksjon

1 + 1
1 + 1
print
prit  # Feilmelding
print()
print("Hei alle sammen")
input("Hva heter du?")
input("Hva heter du? ")
navn = input("Hva heter du? ")
navn
print("Hei navn")
print(navn)
print("Hei", navn)
print(f"Hei", navn)
print(f"Hei {navn}")
navn = input("Hva heter du? ")
print(f"Hei {navn}")
print(f"Hei {navn}")
print("Hei", navn)

#
# Revidert statsbudsjett
#
import pandas as pd
pd.read_excel?

data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols=[0, 1, 2])

data.info()
data.info()
data

# Hent rader og kolonner
data.loc["Norge"]
data.Budsjettiltak
data.Lån og garantier
data.loc["Lån og garantier"]
data.loc[:, "Lån og garantier"]
data.rename(columns={"Lån og garantier": "lån"})
ny = data.rename(columns={"Lån og garantier": "lån"})
data.tiltak
data.lån

# Gjør operasjoner
data.tiltak + data.lån
data.loc["Norge"]
data.loc["Norge"] + data.loc["Sverige"]
data.loc["Norge", "tiltak"] + data.loc["Sverige", "lån"]
data.tiltak + data.lån
data.tiltak + data.lån

# Pause 1
#
# Gå til https://oslobysykkel.no/apne-data/historisk
# Last ned November 2020, CSV
# Vi starter opp igjen 10:30

# Lag figurer
budsjett.plot()
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.bar(stacked=True)
budsjett.loc[:, "tiltak"].plot.bar(stacked=True)
budsjett.loc[:, ["tiltak", "lån"]].plot.bar(stacked=True)
budsjett.loc[["Norge", "Sverige", "Finland"], ["tiltak", "lån"]].plot.bar(stacked=True)
budsjett.plot.scatter()
budsjett.plot.scatter(x="tiltak", y="lån")

# Lagre til Excel
budsjett.rename(
    columns={"tiltak": "Budsjettiltak",
             "lån": "Lån og garantier"}
    ).to_excel("budsjett.xlsx")

# Gjør spørringer
norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
budsjett.index
budsjett.query("lån > 10")
budsjett.query("lån > 5 and i_norden")
budsjett.query("lån > 5 or i_norden")
budsjett.query("index == 'Norge'")
navn = "Geir Arne"
1 = 2
1 == 2
1 != 2
budsjett.query("index == 'Norge'")
budsjett.query("i_norden").plot.bar()
budsjett.query("index == @norden")


#
# Bysykler
#

# Få oversikt over dataene dine
data.info()
data.info()
data.describe()
data.describe()
statistikk = data.describe()

# Jobb med datoer og klokkeslett
data.started_at
data.ended_at - data.started_at
data.duration
data
data.set_index("started_at")
data.set_index("started_at").loc["2020-11-22"]
data.set_index("started_at").loc["2020-11-22":"2020-11-25"]
data.set_index("started_at").loc["2020-11-22":"2020-11-25"]
turer = data.set_index("started_at").loc["2020-11-22"]

# Gruppering av data
turer.groupby("start_station_name")
turer.groupby("start_station_name").size()
turer.groupby("start_station_name").size().sort_values()
turer.groupby("start_station_name").size().sort_values(ascending=False)
turer.groupby("start_station_name").size().sort_values(ascending=False, 2)
turer.groupby("start_station_name").size().sort_values(ascending=False)
turer.groupby("start_station_name").median()
turer.groupby("start_station_name").mean()
turer.groupby("start_station_name").sum()
turer.groupby("start_station_name").max()
turer.groupby("start_station_name").median()
turer.groupby("start_station_name").median().sort_values(by="duration")
data.groupby("start_station_name").median().sort_values(by="duration")
data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"]).size().sort_values()
fra_til = data.groupby(["start_station_name", "end_station_name"]).size().sort_values()
fra_til = (
    data.
    groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
)
fra_til = (
    data.
    groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

# Pivottabell
fra_til.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")
fra_til.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips", fill_value=0)

# Slå sammen data
tidsbruk = data.groupby(["start_station_name", "end_station_name"]).median()
tidsbruk = data.groupby(["start_station_name", "end_station_name"]).median().loc[:, "duration"]
tidsbruk = data.groupby(["start_station_name", "end_station_name"]).median().loc[:, "duration"].reset_index()
fra_til.merge(tidsbruk)
fra_til.merge(tidsbruk, on=["start_station_name", "end_station_name"])
fra_til.merge(tidsbruk, on=["start_station_name", "end_station_name"]).sort_values("duration")

# Pause 2
#
# Se på https://pypi.org/project/pandasgui/
# Prøv å installer i konsollet:
#
# In [1]: !pip install pandasgui
#
# Kan brukes med:
#
# In [2]: import pandasgui
# In [3]: pandasgui.show(data)
#
#
# Vi starter igjen 12:05

#
# Kart
#
# Andre nyttige biblioteker kan være geopandas, pyproj
#
import folium
folium.Map?  # Få hjelp i konsollet
pd.read_excel?
data.loc[0]
data.loc[1]

# Løkker
norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
for land in norden:
    print(land)
for stasjon in stasjoner:
    print(stasjon)
for stasjon in stasjoner.iterrows():
    print(stasjon)
for radnummer, stasjon in stasjoner.iterrows():
    print(stasjon)
stasjoner
stasjoner.columns
for radnummer, stasjon in stasjoner.iterrows():
    print(stasjon)
for radnummer, stasjon in stasjoner.iterrows():
    print(radnummer)
for radnummer, stasjon in stasjoner.iterrows():
    print(radnummer)
for radnummer in stasjoner.index:
    print(radnummer)
for radnummer in stasjoner.index:
    stasjon = stasjoner.loc[radnummer]
    print(stasjon)
for radnummer in stasjoner.index:
    stasjon = stasjoner.loc[radnummer]
    print(stasjon)
for radnummer in stasjoner.index:
    stasjon = stasjoner.loc[radnummer]
    print(stasjon)
for radnummer in stasjoner.index:
    stasjon = stasjoner.loc[radnummer]
    print(stasjon)

# Hent ut historikken din
history
