import pandas as pd

# Les inn bysykkeldata, pass på at datoer og klokkeslett tolkes riktig
data = pd.read_csv("11.csv", parse_dates=["started_at", "ended_at"])

# Lag et mindre datasett for utforsking
#
# Ved å bruke datoer som index kan .loc[] gjøre enkle utvalg
turer = data.set_index("started_at").loc["2020-11-22"]

# Startstasjoner sortert på median tidsbruk
vanlig_tidsbruk = (
    turer
    .groupby("start_station_name")
    .median()
    .sort_values(by="duration")
)

# Turer (fra-til) sortert på antall turer
fra_til = (
    data.
    groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

# Pivotert tabell med fra-stasjoner som rader og til-stasjoner som kolonner
tabell = (
    fra_til
    .pivot_table(
        index="start_station_name",
        columns="end_station_name",
        values="num_trips",
        fill_value=0
    )
)

# Median tidsbruk for turer (fra-til)
tidsbruk = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .median()
    .loc[:, "duration"]
    .reset_index()
)

# Slå sammen antall turer med median tidsbruk
sammenslått = (
    fra_til
    .merge(
        tidsbruk,
        on=["start_station_name", "end_station_name"]
    )
    .sort_values("duration")
)
