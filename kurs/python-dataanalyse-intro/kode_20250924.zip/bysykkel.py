import pandas

data = pandas.read_csv("09.csv", parse_dates=["started_at", "ended_at"])

# For norske filer:
#     pandas.read_csv("filnavn.csv", sep=";", decimal=",")

turer = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)

# Forskjellige paranteser i Python
#
# - []: Lage lister eller hente ut elementer/kolonner
# - (): Gruppere kode, kalle funksjoner, lage tupler (par, tripler, osv)
# - {}: Lage dictionary: nøkkel-verdi par

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        max_duration=("duration", "max"),
        count=("start_station_id", "count"),
        latitude=("start_station_latitude", "first")
    )
    .sort_values(by="count")
    .reset_index(drop=True)  # Sett radnavn til å være 0 - N
)

trips = (
    turer
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(count=("duration", "count"), median_duration=("duration", "median"))
    .sort_values(by=["count", "median_duration"], ascending=False)
)

table = trips.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="count",
    fill_value=0,
    aggfunc="first",
)

stations = (
    turer
    .groupby("start_station_id", as_index=False)
    .agg(
        name=("start_station_name", "first"),
        lat=("start_station_latitude", "first"),
        lon=("start_station_longitude", "first")
    )
)
