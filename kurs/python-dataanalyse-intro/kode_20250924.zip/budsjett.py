import pandas

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    # names=["land", "tiltak", "lån"],
).rename(
    columns={
        " ": "land",
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån",
    }
)

ryddige_data = data.fillna(0)
# budsjett = data.fillna(0).assign(total = data["tiltak"] + data["lån"])
budsjett = ryddige_data.assign(total=ryddige_data["tiltak"] + ryddige_data["lån"])

budsjett.to_excel("budsjett.xlsx")

# To forskjellige måter å gjøre spørringer på
budsjett.query("land == 'Norge'")
budsjett.loc[budsjett["land"] == "Norge"]