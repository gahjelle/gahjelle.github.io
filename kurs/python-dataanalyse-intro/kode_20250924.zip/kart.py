import folium
import pandas

data = pandas.read_csv("09.csv")

stations = (
    data  # OBS! Byttet navn fra turer til data!
    .groupby("start_station_id", as_index=False)
    .agg(
        name=("start_station_name", "first"),
        lat=("start_station_latitude", "first"),
        lon=("start_station_longitude", "first")
    )
)

map = folium.Map((59.91, 10.78), zoom_start=12)
for station in stations.itertuples():
    folium.CircleMarker(
        (station.lat, station.lon),
        tooltip=station.name,
        popup="Heisann",
        fill=True,
        radius=30,
    ).add_to(map)
map.save("kart.html")

# folium.Circle(
#    (59.93923, 10.75917),
#    tooltip="Bentsebrugata",
#    popup="Vår andre markør",
#    fill=True,
#    radius=20,
#).add_to(map)
