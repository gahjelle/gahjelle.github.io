#
# Introduksjon til variabler
#
1 + 2
tall = 3.14
tall
tall * 2
tall = 42
tall * 2
tall = "Geir Arne"
Geir Arne  # Feil: Syntaksfeil - kan ikke ha mellomrom i Pythonnavn
Geir       # Feil: Geir tolkes som en variabel, men den er ikke definert

#
# Les inn en Excelfil med pandas
#
import pandas
pandas
pandas.read_excel()
pandas.read_excel("kap1.xlsx")

data = pandas.read_excel("kap1.xlsx")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=5)  # Feil, off-by-one
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data.info()
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, na_values="-")
data.info()

# PAUSE til 10:13

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-"
)

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",  # Kan bruke komma etter siste verdi
)

data
data["Budsjettiltak"]
data["Budsjettiltak"] + data["Lån og garantier"]
data["Budsjettiltak"] + data["lån og garantier"]  # Feil: liten l i lån

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],  # Angi kolonnenavn ved innlesing
)

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
)

data.columns
data.rename(columns={"Budsjettiltak": "tiltak"})

budsjett = data.rename(columns={"Budsjettiltak": "tiltak"})

budsjett = data.rename(
    columns={
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån",
    }
)
data.columns

budsjett = data.rename(
    columns={
        " ": "land",
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån",
    }
)
budsjett
budsjett["tiltak"] + budsjett["lån"]

blåbærsyltetøy = "godt"  # Kan bruke norske tegn i variabelnavn

data = data.rename(  # Overskriver data, oftest bra å unngå fordi du gjør koden avhengig av tilstand
    columns={
        " ": "land",
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån",
    }
)

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
)
data["tiltak"]  # Feil, kolonnen tiltak eksisterer ikke fordi vi ikke har omnavnet den

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
).rename(
    columns={
        " ": "land",
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån",
    }
)

#
# Manglende verdier
#
data
data.dropna()  # Slett rader som inneholder manglende verdier (nan)
data.dropna(axis="columns")  # Slett kolonner som inneholder nan
data.fillna(0)  # Bytt nan-verdier med 0 (kan bruke andre tall)
data["lån"].mean()
data.fillna(data["lån"].mean())
data.ffill()  # Fyll nan-verdier med forrige verdi
data.bfill()  # Fyll nan-verdier med neste verdi

data["lån"]
data["lån"].mean()
data["lån"].sum()

# Finn differanse med forrige rad
data["lån"].diff()
data["lån"].diff(2)

# Ikke vist i kurset: Fyll nan med snittet av verdiene før og etter
#
# Bruk .shift() for å flytte rader opp og ned, bruk {"lån": ...} for å angi at
# verdiene brukes i lån-kolonnen
data.fillna({"lån": (data["lån"].shift(1) + data["lån"].shift(-1)) / 2})

#
# Bruk "formler" / legg til kolonner
#
data["tiltak"] + data["lån"]
data.assign(total = data["tiltak"] + data["lån"])
budsjett = data.assign(total = data["tiltak"] + data["lån"])
budsjett = data.assign(total = data["tiltak"] + data["lån"], en=1)

fillna(0)

budsjett = data.fillna(0).assign(total = data["tiltak"] + data["lån"])
ryddige_data = data.fillna(0)
budsjett = ryddige_data.assign(total=ryddige_data["tiltak"] + ryddige_data["lån"])
data.info()

#
# Et lite sidespor om representasjon av tall :)
#
bin(2025)
2**63  # Størrelsesorden på største heltall som kan representeres med int64
0.1
0.1 + 0.1 + 0.1 == 0.3  # Flyttall er muligens ikke representert helt nøyaktig

from decimal import Decimal
Decimal(0.1)
Decimal(0.3)

# Lunsjpause

import time
time.time()  # Antall sekunder siden 1. januar 1970
time.time()  # https://en.wikipedia.org/wiki/Year_2038_problem
time.time() / 86400 / 365

#
# Lagre data til Excel
#
budsjett.to_excel("budsjett.xlsx")

#
# Kolonnenavn
#
data.assign(begge tilsammen=data["tiltak"] + data["lån"])  # Feil, kan ikke ha mellomrom i Pythonnavn
data.assign("begge tilsammen"=data["tiltak"] + data["lån"])  # Feil, kan ikke bruke "" for å spesifisere argumentnavn i funksjonskall
data.assign({"begge tilsammen": data["tiltak"] + data["lån"]})  # Feil, kan ikke bruke en dictionary for å sette nye kolonner
data.assign(**{"begge tilsammen": data["tiltak"] + data["lån"]})  # Virker: bruker "dictionary unpacking" for å konvertere til argumenter

#
# Hent ut data fra en DataFrame
#
[1, 2, 3]  # [] definerer en liste av flere elementer
flere_tall = [1, 2, 3]

budsjett[["tiltak", "lån"]]  # Hent ut flere kolonner
budsjett.loc[5]  # Hent en rad basert på radnavn
budsjett.query("land == 'Norge'")  # Filtrer basert på en spørring
budsjett["land"] == "Norge"
budsjett.loc[budsjett["land"] == "Norge"]
budsjett.query("total < 10")
budsjett.query("total < 10 and lån >= 5")

#
# Tegn en figur
#
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(x="land")
budsjett.plot.barh(x="land", stacked=True)
budsjett.plot.barh(x="land", stacked=True, y=["tiltak", "lån"])

#
# Importering av pakker
#
import pandas as pd  # Omnavner pandas slik at du refererer til pakken med pd
pd                   # Dette er en vanlig konvensjon du vil se mange steder
pandas               # Feil: pandas er ikke tilgjengelig (bortsett fra vi allerede importerte den)
import pandas

# 
# Les CSV filer (bysykkeldata)
#
data = pandas.read_csv("09.csv")
data.info()  # Se på kolonner og datatyper
data.loc[0]  # Se på første rad for å se eksempelverdier
data

#
# Håndter datokolonner
#
data = pandas.read_csv("09.csv", parse_dates=["started_at", "ended_at"])  # Virker ikke fordi datoene er inkonsistent formatert

pandas.to_datetime(data["started_at"])
pandas.to_datetime(data["started_at"], format="ISO8601")

turer = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)
turer.info()
turer["ended_at"] - turer["started_at"]
(turer["ended_at"] - turer["started_at"]).max()

# PAUSE til 13:45

#
# Gruppering og aggregering
#
turer.groupby("start_station_name")
turer.groupby("start_station_name").count()
turer.groupby("start_station_name").agg(count=("start_station_id", "count"))
turer.groupby("start_station_name").agg(count=("start_station_id", "count")).sort_values(by="count")

(
    turer
    .groupby("start_station_name")
    .agg(
        max_duration=("duration", "max"),
        count=("start_station_id", "count"),
    )
    .sort_values(by="count")
)

(
    turer
    .groupby("start_station_name")
    .agg(
        max_duration=("duration", "max"),
        count=("start_station_id", "count"),
        latitude=("start_station_latitude", "first")
    )
    .sort_values(by="count")
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        max_duration=("duration", "max"),
        count=("start_station_id", "count"),
        latitude=("start_station_latitude", "first")
    )
    .sort_values(by="count")
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        max_duration=("duration", "max"),
        count=("start_station_id", "count"),
        latitude=("start_station_latitude", "first")
    )
    .sort_values(by="count")
    .reset_index()
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        max_duration=("duration", "max"),
        count=("start_station_id", "count"),
        latitude=("start_station_latitude", "first")
    )
    .sort_values(by="count")
    .reset_index(drop=True)
)

turer.groupby(["start_station_name", "end_station_name"]).size()
turer.groupby(["start_station_name", "end_station_name"], as_index=False).size()
turer.groupby(["start_station_name", "end_station_name"], as_index=False).agg(count=("duration", "count"), median_duration=("duration", "median"))
trips = (
    turer
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(count=("duration", "count"), median_duration=("duration", "median"))
    .sort_values(by="count")
)

trips = (
    turer
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(count=("duration", "count"), median_duration=("duration", "median"))
    .sort_values(by="count", ascending=False)
)

trips = (
    turer
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(count=("duration", "count"), median_duration=("duration", "median"))
    .sort_values(by=["count", "median_duration"], ascending=False)
)

trips.pivot_table(index="start_station_name", columns="end_station_name", values="count")
trips.pivot_table(index="start_station_name", columns="end_station_name", values="count", fill_value=0 )
trips.pivot_table(index="start_station_name", columns="end_station_name", values="count", fill_value=0 , aggfunc="first")

table = trips.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="count",
    fill_value=0,
    aggfunc="first",
)
# table.melt() gjør det "motsatte" av pivot_table()

#
# Slå sammen data "sidelengs"
#
stations = turer.groupby("start_station_id", as_index=False).agg(name=("start_station_name", "first"), lat=("start_station_latitude", "first"), lon=("start_station_longitude", "first"))
trips.merge(stations)  # Feil, må angi hvilke kolonner som skal matches
trips.merge(stations, left_on="start_station_name", right_on="name")
with_coords = trips.merge(stations, left_on="start_station_name", right_on="name")

north = stations.query("lat > 59.93")
north

with_coords = trips.merge(north, left_on="start_station_name", right_on="name")
with_coords = trips.merge(north, how="inner", left_on="start_station_name", right_on="name")
with_coords = trips.merge(north, how="outer", left_on="start_station_name", right_on="name")

#
# Slå sammen data vertikalt
#
pandas.concat([data, data])
pandas.concat([data, north])

# PAUSE til 15:20

#
# Kart over bysykkelstasjoner
#
import pandas

data = pandas.read_csv("09.csv")

stations = (
    data  # OBS! Byttet navn fra turer til data!
    .groupby("start_station_id", as_index=False)
    .agg(
        name=("start_station_name", "first"),
        lat=("start_station_latitude", "first"),
        lon=("start_station_longitude", "first")
    )
)

import folium
folium.Map().save("kart.html")

stations.loc[0]
folium.Map((59.91, 10.78), zoom_start=10).save("kart.html")
folium.Map((59.91, 10.78), zoom_start=12).save("kart.html")

map = folium.Map((59.91, 10.78), zoom_start=12)

map.save("kart.html")

map = folium.Map((59.91, 10.78), zoom_start=12)
folium.Marker((59.915667, 10.777567), tooltip="Tøyenparken", popup="Vår første markør").add_to(map)
map.save("kart.html")

map = folium.Map((59.91, 10.78), zoom_start=12)
folium.CircleMarker(
    (59.915667, 10.777567),
    tooltip="Tøyenparken",
    popup="Vår første markør",
).add_to(map)
map.save("kart.html")

map = folium.Map((59.91, 10.78), zoom_start=12)
folium.CircleMarker(
    (59.915667, 10.777567),
    tooltip="Tøyenparken",
    popup="Vår første markør",
    fill=True
).add_to(map)
map.save("kart.html")

stations.loc[1]
map = folium.Map((59.91, 10.78), zoom_start=12)
folium.CircleMarker(
    (59.915667, 10.777567),
    tooltip="Tøyenparken",
    popup="Vår første markør",
    fill=True,
    radius=30,
).add_to(map)
folium.CircleMarker(
    (59.93923, 10.75917),
    tooltip="Bentsebrugata",
    popup="Vår andre markør",
    fill=True,
    radius=20,
).add_to(map)
map.save("kart.html")

map = folium.Map((59.91, 10.78), zoom_start=12)
folium.Circle(
    (59.915667, 10.777567),
    tooltip="Tøyenparken",
    popup="Vår første markør",
    fill=True,
    radius=30,
).add_to(map)
folium.CircleMarker(
    (59.93923, 10.75917),
    tooltip="Bentsebrugata",
    popup="Vår andre markør",
    fill=True,
    radius=20,
).add_to(map)
map.save("kart.html")

for tall in [1, 2, 4]:
    print(tall, tall*3)

for station in stations.itertuples():
    print(station)

map = folium.Map((59.91, 10.78), zoom_start=12)
for station in stations.itertuples():
    folium.CircleMarker(
        (59.915667, 10.777567),
        tooltip="Tøyenparken",
        popup="Vår første markør",
        fill=True,
        radius=30,
    ).add_to(map)
map.save("kart.html")

map = folium.Map((59.91, 10.78), zoom_start=12)
for station in stations.itertuples():
    folium.CircleMarker(
        (station.lat, station.lon),
        tooltip=station.name,
        popup="Heisann",
        fill=True,
        radius=30,
    ).add_to(map)
map.save("kart.html")
