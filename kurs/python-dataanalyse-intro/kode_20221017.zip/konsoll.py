#
# Intro
#
print
print()
print("Hei alle sammen")
Hei alle sammen  # Feil, Python prøver å tolke alt some ikke har fnutter rundt seg
"Hei alle sammen"
1 + 2
"Han sa: "Heisann""  # Feil, fnutter kommer i par
'Han sa: "Heisann"'
navn = "Geir Arne"
f"Hei, {navn}"

def heisann(navn):
    return f"Hei, {navn}"

heisann("alle sammen")

#
# Intro til pandas
#
pandas  # Feil, pandas må importeres selv om det er installert
import pandas
pandas
import pandas as pd
pd
pd.read_excel
pd.read_excel()  # Feil, vi må angi et filnavn
pd.read_excel("kap1.xlsx")
pd.read_excel("C:\Users\gahjelle\kap1.xlsx")  # Feil, bruk r"" for å angi full filsti på Windows
pd.read_excel(r"C:\Users\gahjelle\kap1.xlsx")

pd.read_excel("kap1.xlsx", sheet_name="1.2")
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2")
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, index_col=0)
budsjett.info()
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, index_col=0, na_values="-")
budsjett = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, index_col=0, na_values=["-", "GA"])
budsjett.info()
budsjett.describe()

# OPPGAVE: Les inn ark 1.1 fra regnearket kap1.xlsx
# PAUSE til 10:25

#
# Rydd innleste data
#
budsjett.Budsjettiltak
budsjett.Lån og garantier  # Feil, kan ikke bruke . for kolonnenavn med mellomrom
budsjett["Budsjettiltak"]
budsjett["Lån og garantier"]
budsjett.rename(columns={"Budsjettiltak": "tiltak"})
budsjett.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
budsjett = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    index_col=0,
    na_values=["-", "GA"]
).rename(
    columns={
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån"
    }
)
budsjett

budsjett.tiltak
budsjett.lån
budsjett.tiltak * 2
budsjett.tiltak + budsjett.lån

budsjett.dropna()
budsjett.dropna?  # Les dokumentasjon for .dropna()
budsjett.dropna(axis="columns")
budsjett
budsjett.fillna?
budsjett.fillna(0)
budsjett.lån.mean()
budsjett.lån.median()
budsjett.fillna(budsjett.lån.median())

#
# Hent ut data fra en DataFrame
#
budsjett
budsjett.loc["Norge"]
budsjett.loc["Brasil"]
budsjett.loc["Brasil":"Norge"]
budsjett.loc[["Norge", "Sverige", "Danmark"]]
norden = ["Norge", "Sverige", "Danmark", "Finland"]
budsjett.loc[norden]
budsjett.loc["Norge", "tiltak"]
budsjett.loc[["Norge", "Sverige", "Danmark"]]
budsjett.loc[["Norge", "Sverige", "Danmark"], "lån"]
budsjett.loc[norden, "lån"]
budsjett.iloc[0]
budsjett.iloc[3:8]
budsjett.loc[norden, "lån"]
budsjett.loc[norden, "lån"] = 0
budsjett
budsjett = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    index_col=0,
    na_values=["-", "GA"]
).rename(
    columns={
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån"
    }
).fillna(0)
budsjett.query("lån > 5")
budsjett.query("lån > 5 and tiltak < 4")
budsjett.assign()
budsjett.assign(total=42)
budsjett.assign(total=budsjett.tiltak + budsett.lån)
budsjett.assign(total=budsjett.tiltak + budsjett.lån)
budsjett.assign(total=budsjett.tiltak + budsjett.lån).query("total > 20")

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    index_col=0,
    na_values=["-", "GA"]
).rename(
    columns={
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån"
    }
).fillna(0)
budsjett = data.assign(total=data.tiltak + data.lån)
budsjett

budsjett.sort_values(by="total")
budsjett.sort_values?
budsjett.sort_values(by="total", ascending=False)
budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total", ascending=False)
)

budsjett.sort_values()

budsjett.to_excel("budsjett.xlsx")
budsjett.rename(columns={"tiltak": "Budsjettiltak"}).to_excel("budsjett.xlsx")

# PAUSE til 12:15
# Last ned CSV med september og oktober fra https://oslobysykkel.no/apne-data/historisk

#
# Visualisering
#
budsjett
budsjett.plot()

budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(stacked=True)
budsjett.loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)
budsjett.loc[:, ["tiltak", "lån"]].plot.barh(stacked=True, title="Tiltak og lån")

#
# Bysykkeldata
#
import pandas as pd
pd.read_csv("10.csv")
data = pd.read_csv("10.csv")
data.info()
data.loc[0]
data.loc[0, "started_at"]
pd.to_datetime(data.loc[0, "started_at"])
pd.to_datetime(data.loc[0, "started_at"]) + pd.Timedelta(1, "day")
pd.to_datetime(data.loc[0, "started_at"]) - pd.Timedelta(1, "day")

data = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
data.info()

data.ended_at
data.ended_at - data.started_at

#
# Gruppering og aggregering
#
data.groupby("start_station_name")
data.groupby("start_station_name").sum()
gruppe = data.groupby("start_station_name").sum()
gruppe = data.groupby("start_station_name").median()
gruppe = data.groupby("start_station_name").agg() # Feil, må angi hvordan grupper skal aggregeres
gruppe = data.groupby("start_station_name").agg({"duration": "median", "start_station_latitude": "first"})
gruppe = data.groupby("start_station_name").agg({"duration": "median", "start_station_latitude": "first", "end_station_name": "first"})

def most_common():
    ...
gruppe = data.groupby("start_station_name").agg({"duration": "median", "start_station_latitude": "first", "end_station_name": most_common})

def most_common(noe):
    print(noe)
gruppe = data.groupby("start_station_name").agg({"duration": "median", "start_station_latitude": "first", "end_station_name": most_common})

def most_common(end_station):
    print(end_station)
data.end_station_name.mode()
data.end_station_name.mode().iloc[0]
def most_common(end_station):
    return end_station.mode().iloc[0]
gruppe = data.groupby("start_station_name").agg({"duration": "median", "start_station_latitude": "first", "end_station_name": most_common})

data.query("start_station_name == 'Adamstuen'")
data.query("start_station_name == 'Adamstuen'").end_station_name
data.query("start_station_name == 'Adamstuen'").end_station_name.value_counts()
gruppe = data.groupby("start_station_name").agg({"duration": "median", "start_station_latitude": "first", "end_station_name": most_common})

data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("end_station_name").size().sort_values()

# PAUSE til 13:40

#
# Grupper på flere kolonner
#
data.groupby(["start_station_name", "end_station_name"])
data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"]).size().reset_index()
data.groupby(["start_station_name", "end_station_name"]).size().reset_index().rename(columns={0: "num_trips"})
data.groupby(["start_station_name", "end_station_name"]).size().reset_index().rename(columns={0: "num_trips"}).sort_values()
data.groupby(["start_station_name", "end_station_name"]).size().reset_index().rename(columns={0: "num_trips"}).sort_values(by="num_trips")
turer = (
    data
    .groupby(["start_station_name", "end_station_name"]).size()
    .reset_index()
    .rename(columns={0: "num_trips"})
    .sort_values(by="num_trips")
)
turer
turer.pivot_table?
turer.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")
turer.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips", fill_value=0)
stasjoner = turer.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips", fill_value=0)
turer

#
# Slå sammen datasett
#
data = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
data_sep = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
data_okt = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
pd.concat?
pd.concat([data_sep, data_okt])
pd.concat([data_sep, data_okt]).loc[0]
pd.concat([data_sep, data_okt]).reset_index()
pd.concat([data_sep, data_okt]).reset_index(drop=True)

data_sep = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
data_okt = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
data = pd.concat([data_sep, data_okt]).reset_index(drop=True)

for filnavn in ["09.csv", "10.csv"]:
    print(filnavn)

for filnavn in ["09.csv", "10.csv"]:
    print(filnavn)
    pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])

data_liste = []
for filnavn in ["09.csv", "10.csv"]:
    print(filnavn)
    data_måned = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_liste.append(data_måned)

data_liste = []
for filnavn in ["09.csv", "10.csv"]:
    print(filnavn)
    data_måned = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_liste.append(data_måned)
data = pd.concat(data_liste).reset_index(drop=True)

import pathlib
data_liste = []
# for filnavn in ["09.csv", "10.csv"]:
for filnavn in pathlib.Path.cwd().glob("*.csv"):
    print(filnavn)
    data_måned = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_liste.append(data_måned)
data = pd.concat(data_liste).reset_index(drop=True)


data_liste = []
# for filnavn in ["09.csv", "10.csv"]:
for filnavn in sorted(pathlib.Path.cwd().glob("*.csv")):
    print(filnavn)
    data_måned = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_liste.append(data_måned)
data = pd.concat(data_liste).reset_index(drop=True)

# OPPGAVE: Lag turlengde med start_station_name, end_station_name, duration hvor duration er median-varighet av turer fra start til end

turer
data
data.groupby(["start_station_name", "end_station_name"]).agg({"duration": "median"})
data.groupby(["start_station_name", "end_station_name"]).agg({"duration": "median"}).reset_index()
data.groupby(["start_station_name", "end_station_name"]).agg({"duration": "median"}).reset_index().sort_values(by="duration")
turer = (
    data
    .groupby(["start_station_name", "end_station_name"]).size()
    .reset_index()
    .rename(columns={0: "num_trips"})
    .sort_values(by="num_trips")
)


turlengde = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .agg({"duration": "median"})
    .reset_index()
    .sort_values(by="duration")
)
turlengde
turlengde.merge(turer)
turlengde.merge(turer, on=["start_station_name", "end_station_name"])
turlengde.merge(turer, on=["start_station_name", "end_station_name"]).plot.scatter(x="duration", y="num_trips")
turlengde.merge(turer, on=["start_station_name", "end_station_name"]).plot.scatter(x="duration", y="num_trips", alpha=0.1)
turlengde.merge(turer, on=["start_station_name", "end_station_name"]).query("num_trips >= 3").plot.scatter(x="duration", y="num_trips", alpha=0.1)
turlengde.merge(turer, on=["start_station_name", "end_station_name"]).query("num_trips >= 5").plot.scatter(x="duration", y="num_trips", alpha=0.1)

# PAUSE til 15:00

#
# Visualisering på kart
#
import folium
kart = folium.Map()
kart.save("bysykler.html")

kart = folium.Map((60, 10.8), zoom_start=10)
kart.save("bysykler.html")

kart = folium.Map((60, 10.8), zoom_start=12)
kart.save("bysykler.html")

kart = folium.Map((59.9, 10.8), zoom_start=12)
kart.save("bysykler.html")

import bysykkel
bysykkel.data
bysykkel.data.iloc[0]
kart = folium.Map((59.9, 10.8), zoom_start=12)
folium.CircleMarker(location=(59.915468, 10.751141)).add_to(kart)
kart.save("bysykler.html")

kart = folium.Map((59.9, 10.8), zoom_start=12)
folium.CircleMarker(
    location=(59.915468, 10.751141),
    popup="Sentrum Scene",
    radius=20,
    fill=True,
).add_to(kart)
kart.save("bysykler.html")

bysykkel.data
bysykkel.data.loc[:, ["start_station_name", "start_station_latitude", "start_station_longitude"]]
bysykkel.data.loc[:, ["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
stasjoner = bysykkel.data.loc[:, ["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
stasjoner = (
    bysykkel.data
    .loc[:, [
        "start_station_name",
        "start_station_latitude",
        "start_station_longitude"
    ]]
    .drop_duplicates()
)

for stasjon in stasjoner:
    print(stasjon)

for stasjon in stasjoner.iterrows():
    print(stasjon)

for idx, stasjon in stasjoner.iterrows():
    print(stasjon)

kart = folium.Map((59.9, 10.8), zoom_start=12)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=(stasjon.start_station_latitude, stasjon.start_station_longitude),
        popup=stasjon.start_station_name,
        radius=20,
        fill=True,
    ).add_to(kart)
kart.save("bysykler.html")

bysykkel.data.groupby("start_station_name")
bysykkel.data.groupby("start_station_name").agg({"num_trips": "size"})
bysykkel.data.groupby("start_station_name").agg({"duration": "size"})
bysykkel.data.groupby("start_station_name").agg({"duration": "size", "start_station_latitude": "first", "start_station_longitude": "first"})
bysykkel.data.groupby("start_station_name").agg({"duration": "size", "start_station_latitude": "first", "start_station_longitude": "first"}).rename(columns={"duration": "num_trips"})
bysykkel.data.groupby("start_station_name").agg({"duration": "size", "start_station_latitude": "first", "start_station_longitude": "first"}).rename(columns={"duration": "num_trips"}).reset_index()

stasjoner = (
    bysykkel.data
    .groupby("start_station_name")
    .agg({
        "duration": "size",
        "start_station_latitude": "first",
        "start_station_longitude": "first"
    })
    .rename(columns={"duration": "num_trips"})
    .reset_index()
)
kart = folium.Map((59.9, 10.8), zoom_start=12)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=(stasjon.start_station_latitude, stasjon.start_station_longitude),
        popup=stasjon.start_station_name,
        radius=20,
        fill=True,
    ).add_to(kart)
kart.save("bysykler.html")

kart = folium.Map((59.9, 10.8), zoom_start=12)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=(stasjon.start_station_latitude, stasjon.start_station_longitude),
        popup=stasjon.start_station_name,
        radius=stasjon.num_trips,
        fill=True,
    ).add_to(kart)
kart.save("bysykler.html")

stasjoner.sort_values("num_trips")
stasjoner.sort_values("num_trips").num_trips

kart = folium.Map((59.9, 10.8), zoom_start=12)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=(stasjon.start_station_latitude, stasjon.start_station_longitude),
        popup=stasjon.start_station_name,
        radius=stasjon.num_trips/50,
        fill=True,
    ).add_to(kart)
kart.save("bysykler.html")
