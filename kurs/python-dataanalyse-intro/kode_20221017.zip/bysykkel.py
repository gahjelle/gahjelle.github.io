import pathlib
import pandas as pd


# data_sep = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
# data_okt = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
# data = pd.concat([data_sep, data_okt]).reset_index(drop=True)

data_liste = []
# for filnavn in ["09.csv", "10.csv"]:
for filnavn in sorted(pathlib.Path.cwd().glob("*.csv")):
    print(filnavn)
    data_måned = pd.read_csv(filnavn, parse_dates=["started_at", "ended_at"])
    data_liste.append(data_måned)
data = pd.concat(data_liste).reset_index(drop=True)


turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .reset_index()
    .rename(columns={0: "num_trips"})
    .sort_values(by="num_trips")
)


turlengde = (
    data.groupby(["start_station_name", "end_station_name"])
    .agg({"duration": "median"})
    .reset_index()
    .sort_values(by="duration")
)
