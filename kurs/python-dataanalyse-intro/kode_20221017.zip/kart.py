import folium
import bysykkel

# stasjoner = bysykkel.data.loc[:,
#     [
#         "start_station_name",
#         "start_station_latitude",
#         "start_station_longitude",
#     ],
# ].drop_duplicates()

stasjoner = (
    bysykkel.data.groupby("start_station_name")
    .agg({
        "duration": "size",
        "start_station_latitude": "first",
        "start_station_longitude": "first",
    })
    .rename(columns={"duration": "num_trips"})
    .reset_index()
)

kart = folium.Map((59.9, 10.8), zoom_start=12)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude,
            stasjon.start_station_longitude,
        ),
        popup=stasjon.start_station_name,
        radius=stasjon.num_trips / 50,
        fill=True,
    ).add_to(kart)

kart.save("bysykler.html")
