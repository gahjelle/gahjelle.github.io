import pandas as pd

data = (
    pd.read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        index_col=0,
        na_values=["-", "GA"],
    )
    .rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
    .fillna(0)
)

budsjett = data.assign(total=data.tiltak + data.lån).sort_values(
    by="total", ascending=False
)
