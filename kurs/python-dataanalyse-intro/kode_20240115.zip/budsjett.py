import pandas as pd

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,  # Rad 5 i Excel, indekseres som 4 i pandas
    na_values="-",
    names=["land", "tiltak", "lån"],
).fillna(0)

budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .sort_values(by="total")
    .reset_index(drop=True)
)

(
    budsjett
    .set_index("land")[["tiltak", "lån"]]
    .plot.barh(stacked=True, title="Pandemirespons")
)
