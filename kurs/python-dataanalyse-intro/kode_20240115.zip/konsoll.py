#
# Introduksjon: variabler, funksjoner, biblioteker
#
1 + 2
tall = 42
tall
(tall + 1) * 3
navn = "Geir Arne"
print(navn)
min(1, 2, 4)

import pandas

#
# Les inn Excelfil
import pandas as pd
pd.read_excel("kap1.xlsx")
pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)

data.info()
data.describe()
data["Budsjettiltak"]
data["Budsjettiltak"] * 3
data["Lån og garantier"] * 2
data["Lån og garantier"]
data["Lån og garantier"] + data["Budsjettiltak"]  # Feil, kan ikke kombinere tekst og tall
0.7 + "-"  # Feil, kan ikke kombinere tekst og tall

data.info()
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, na_values="-")
data.info()
data["Lån og garantier"] + data["Budsjettiltak"]

importpandas  # Feil, trenger mellomrom mellom nøkkelord
import    pandas  # OK, kan bruke mange mellomrom

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,  # Rad 5 i Excel, indekseres som 4 i pandas
    na_values="-"
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,  # Rad 5 i Excel, indekseres som 4 i pandas
    na_values="-",
    names=["land", "tiltak", "lån"],
)

data.info()
data["tiltak"] + data["lån"]

# Pause til 10:30

#
# Aktiv arbeidskatalog (working directory)
#
pd.read_excel("kap1.xlsx")
pd.read_excel("kap1.xlsx")
pd.read_excel("/home/gahjelle/kurs/python-intro-dataanalyse/20240115/underveis/kap1.xlsx")
pd.read_excel("C:\Users\Geir Arne\kap1.xlsx")  # Feil, backslash blir mistolket
"\Users"   # Feil, backslash blir mistolket
r"\Users"  # r foran strengen skrur av tolking av backslash
pd.read_excel(r"C:\Users\Geir Arne\kap1.xlsx")

# 
# Legg til ny kolonne
#
data["tiltak"] + data["lån"]
data.assign(total=data["tiltak"] + data["lån"])
budsjett = data.assign(total=data["tiltak"] + data["lån"])
data.assign(total=data["tiltak"] + data["lån"]).sort_values(by="total")
budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .sort_values(by="total")
)
budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .sort_values(by="total")
    .reset_index()
)
budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .sort_values(by="total")
    .reset_index(drop=True)
)

#
# Håndter manglende verdier
#
data.dropna()
data.dropna(axis="columns")
data.dropna(thresh=2)  # Minimum ikke-null verdier for at en rad bevares
data.dropna(thresh=1)
data.dropna(thresh=0)
data.dropna(thresh=4)
data.dropna(thresh=3)
data.dropna(subset=["tiltak"])  # Hvilke kolonner skal vurderes
data.dropna(subset=["tiltak", "lån"])
data.ffill()
data.bfill()
data.fillna(0)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,  # Rad 5 i Excel, indekseres som 4 i pandas
    na_values="-",
    names=["land", "tiltak", "lån"],
).fillna(0)
data.info()

budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .sort_values(by="total")
    .reset_index(drop=True)
)

#
# Dataselektering
#
budsjett
budsjett.loc[9]  # .loc[] henter rader og kolonner basert på radnavn og kolonnenavn
budsjett.loc[9:13]
budsjett.loc[9, "tiltak"]
budsjett.loc[[9, 10, 7, 5]]
budsjett.loc[[9, 10, 7, 5], ["land", "total"]]

budsjett.query("land == 'Norge'")  # .query() henter rader basert på spørringer
navn = "Geir Arne"
1 == 2
1 == 1
budsjett.query("tiltak > 4")
"Geir Arne"
'Geir Arne'
'Geir Arne' == "Geir Arne"
"It's sunny outside"
'It's sunny outside'  # Feil, kan ikke bruke ' inne i en tekststreng definert med '
'It\'s sunny outside'
'land == "Norge"'
budsjett.query('land == "Norge"')
budsjett.query("tiltak > 4")
budsjett.query("tiltak > 4 and lån < 5")
budsjett.query("tiltak > 4 or lån < 5")
budsjett.query("tiltak > 4 or lån < 5").query("land in ['Norge']")
budsjett.query("tiltak > 4 or lån < 5").query("land in ['Norge', 'Sverige', 'Danmark', 'Finland']")
budsjett.query("tiltak > 4 or lån < 5").query("land in ['Norge', 'Sverige', 'Danmark', 'Finland']")[["land", "total"]]

#
# Plotte en figur basert på dataene
#
budsjett.plot()
budsjett.plot.bar()
budsjett.set_index("land")
budsjett.set_index("land").plot.bar()
budsjett.set_index("land").plot.barh()
budsjett.set_index("land").plot.barh(stacked=True)
budsjett.set_index("land")[["tiltak", "lån"]].plot.barh(stacked=True)
budsjett.set_index("land")[["tiltak", "lån"]].plot.barh(stacked=True, title="Pandemirespons")

#
# Skriv data tilbake til Excel
#
budsjett.to_excel("budsjett.xlsx")

# Sjekk at kodefilen din kjører uten feil før du avslutter
runfile('/home/gahjelle/kurs/python-intro-dataanalyse/20240115/underveis/budsjett.py', wdir='/home/gahjelle/kurs/python-intro-dataanalyse/20240115/underveis')

%history  # Bruk %history i det interaktive vinduet for å se hva du har skrevet tidligere

#
# Bysykkeldata
#
pd.read_csv("01.csv")
runfile('/home/gahjelle/kurs/python-intro-dataanalyse/20240115/underveis/bysykkel.py', wdir='/home/gahjelle/kurs/python-intro-dataanalyse/20240115/underveis')
pd.read_csv("01.csv")
data = pd.read_csv("01.csv")
data.info()
data.loc[0]

#Pause til 12:00

data.info()
data = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
data.info()
data = pd.read_csv("12.csv", parse_dates=["started_at", "ended_at"])
data.info()
data = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
data.info()

# Vi trøblet litt med konvertering av datoer fordi noen rader hadde formatert
# datoene annerledes. Vi løste dette ved å bruke pd.to_datetime() som er mer
# robust og fleksibel.

pd.to_datetime(data["started_at"])
pd.to_datetime(data["started_at"], format="ISO8601")
data = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
data = data.assign(
    started_at=pd.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pd.to_datetime(data["ended_at"], format="ISO8601")
)

data.info()
data["ended_at"] - data["started_at"]
(data["ended_at"] - data["started_at"]).describe()

oversikt = data.describe()

#
# Gruppering og aggregering av data
#
data
data.groupby("start_station_name")
data.groupby("start_station_name").agg(antall="size")
data.groupby("start_station_name").agg(antall=("duration", "size"))
data.groupby("start_station_name").agg(antall=("duration", "size")).sort_values(by="antall")
turer = (
    data
    .groupby("start_station_name")
    .agg(
        antall=("duration", "size")
    )
    .sort_values(by="antall")
)
turer = (
    data
    .groupby("start_station_name")
    .agg(
        antall=("duration", "size"),
        varighet=("duration", "median"),
    )
    .sort_values(by="antall")
)
turer = (
    data
    .groupby("start_station_name")
    .agg(
        antall=("duration", "size"),
        varighet=("duration", "median"),
        lengste_tur=("duration", "max"),
    )
    .sort_values(by="antall")
)
turer = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        antall=("duration", "size"),
        varighet=("duration", "median"),
        lengste_tur=("duration", "max"),
    )
    .sort_values(by="antall")
)

turer.query["start_station_name == 'Huk 2'"]

#
# Gruppering på to kolonner, med pivot-tabell
#
data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"]).size().sort_values()

start_slutt = data.groupby(["start_station_name", "end_station_name"]).size().sort_values()
start_slutt = data.groupby(["start_station_name", "end_station_name"], as_index=False).size().sort_values()
start_slutt = data.groupby(["start_station_name", "end_station_name"], as_index=False).size()
start_slutt = data.groupby(["start_station_name", "end_station_name"], as_index=False).size().sort_values(by="size")

start_slutt.pivot_table(index="start_station_name", columns="end_station_name", values="size")
start_slutt.pivot_table(index="start_station_name", columns="end_station_name", values="size", fill_value=0)

tabell = (
    start_slutt
    .pivot_table(
        index="start_station_name",
        columns="end_station_name",
        values="size",
        fill_value=0,
    )
)

turer = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        antall=("duration", "size"),
        varighet=("duration", "median"),
        lengste_tur=("duration", "max"),
        breddegrad=("start_station_latitude", "first"),
    )
    .sort_values(by="antall")
)

#
# Nettkart med bysykkelstasjoner
#
import pandas as pd
import folium

data = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
data = data.assign(
    started_at=pd.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pd.to_datetime(data["ended_at"], format="ISO8601")
)

kart = folium.Map()
kart.save("bysykkel.html")

data.loc[0]

kart = folium.Map((59.9, 10.7))
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.7), zoom_start=12)
kart.save("bysykkel.html")

# En stasjon, manuelt lagt inn
kart = folium.Map((59.9, 10.7), zoom_start=12)
folium.Marker(
    (59.911901, 10.749929),
    popup="Europarådets plass",
    tooltip="Jernbanetorget",
).add_to(kart)
kart.save("bysykkel.html")

stasjoner = data[["start_station_name", "start_station_description", "start_station_latitude", "start_station_longitude"]]
stasjoner = data[["start_station_name", "start_station_description", "start_station_latitude", "start_station_longitude"]].drop_duplicates()

for tall in [1, 2, 3]:
    print(tall)

kart = folium.Map((59.9, 10.7), zoom_start=12)
for _, stasjon in stasjoner.iterrows():
    folium.Marker(
        (stasjon["start_station_latitude"], 10.749929),
        popup="Europarådets plass",
        tooltip="Jernbanetorget",
    ).add_to(kart)
kart.save("bysykkel.html")

# Alle stasjoner, lagt inn ved hjelp av en for-løkke
kart = folium.Map((59.9, 10.7), zoom_start=12)
for _, stasjon in stasjoner.iterrows():
    folium.Marker(
        (stasjon["start_station_latitude"], stasjon["start_station_longitude"]),
        popup=stasjon["start_station_description"],
        tooltip=stasjon["start_station_name"],
    ).add_to(kart)
kart.save("bysykkel.html")
