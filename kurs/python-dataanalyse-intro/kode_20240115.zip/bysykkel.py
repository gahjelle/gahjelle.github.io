import pandas as pd

data = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
data = data.assign(
    started_at=pd.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pd.to_datetime(data["ended_at"], format="ISO8601")
)

turer = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        antall=("duration", "size"),
        varighet=("duration", "median"),
        lengste_tur=("duration", "max"),
        breddegrad=("start_station_latitude", "first"),
    )
    .sort_values(by="antall")
)

start_slutt = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .size()
    .sort_values(by="size")
)

tabell = (
    start_slutt
    .pivot_table(
        index="start_station_name",
        columns="end_station_name",
        values="size",
        fill_value=0,
    )
)
