import pandas as pd
import folium

data = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
data = data.assign(
    started_at=pd.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pd.to_datetime(data["ended_at"], format="ISO8601")
)
stasjoner = data[[
     "start_station_name",
     "start_station_description",
     "start_station_latitude",
     "start_station_longitude"
]].drop_duplicates()

kart = folium.Map((59.9, 10.7), zoom_start=12)
for _, stasjon in stasjoner.iterrows():
    folium.Marker(
        (stasjon["start_station_latitude"], stasjon["start_station_longitude"]),
        popup=stasjon["start_station_description"],
        tooltip=stasjon["start_station_name"],
    ).add_to(kart)
kart.save("bysykkel.html")
