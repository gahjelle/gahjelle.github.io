import pandas as pd

# Manuelt slå sammen flere datasett
data_mars = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
data_februar = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])

data = pd.concat([data_februar, data_mars]).reset_index(drop=True)

# Alternativt: slå sammen basert på liste
filnavn = ["02.csv", "03.csv"]
liste_over_data = []
for fil in filnavn:
    data_ark = pd.read_csv(fil, parse_dates=["started_at", "ended_at"])
    liste_over_data.append(data_ark)

data = pd.concat(liste_over_data).reset_index(drop=True)

antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

tabell = antall_turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="num_trips",
    fill_value=0
)
