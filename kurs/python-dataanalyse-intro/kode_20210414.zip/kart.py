import folium
import pandas as pd

# Les inn data
data = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
stasjoner = data.loc[:, [
    "start_station_name",
    "start_station_latitude",
    "start_station_longitude"
    ]].drop_duplicates().rename(
        columns={"start_station_name": "name",
                 "start_station_latitude": "latitude",
                 "start_station_longitude": "longitude"}
        )


# Folium er et overbygg til LeafletJS
kart = folium.Map(location=(59.92, 10.75), zoom_start=12)
folium.CircleMarker(
    (60.9274, 10.796),
    popup='<a href="https://tekna.no/">Tekna</a>', fill=True
).add_to(kart)

for id in stasjoner.index:
    stasjon = stasjoner.loc[id]
    folium.CircleMarker(
        (stasjon.latitude, stasjon.longitude),
        popup=stasjon.loc["name"],
        fill=True,
    ).add_to(kart)

kart.save("bysykkel.html")

