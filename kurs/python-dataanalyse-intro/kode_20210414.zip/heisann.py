navn = input("Hva heter du? ")
print(f"Hei {navn}")

