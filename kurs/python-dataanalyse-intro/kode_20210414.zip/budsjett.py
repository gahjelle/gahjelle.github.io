import pandas as pd

norden = ["Norge", "Sverige", "Finland", "Danmark", "Island"]

# Lese inn og "vaske" dataene
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5-1,
    usecols="A:C",
    index_col=0,
    na_values="-",
).rename(
    columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"}
)

# Prosessere data
data_uten_na = data.fillna(value=0)
budsjett = (
    data_uten_na
    .fillna(value=0)
    .assign(
        total=data_uten_na.tiltak + data_uten_na.lån,
        i_norden=data_uten_na.index.isin(norden),
    )
    .sort_values(by="total")
)

# Skrive data tilbake til Excel
budsjett.to_excel("budsjett.xlsx", sheet_name="Budsjett")

(
    budsjett
    .query("i_norden")
    .drop(columns="i_norden")
    .rename(
        columns={"tiltak": "Budsjettiltak", "lån": "Lån og garantier"}
    )
    .to_excel("norden.xlsx")
)






