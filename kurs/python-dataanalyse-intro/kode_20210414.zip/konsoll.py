# Read Evaluate Print Loop
1 + 1
print("Hei alle sammen")
tall = 42
tall
tall + 1
tall=42
pi = 3.14
navn = "Geir Arne"
print(navn)
print(f"Hei {navn}")
print(f"Hei {navn}, tallet er {tall}")
print(f"Hei {navn}, tallet er {tall + 1}")
navn = input("Hva heter du? ")
print(f"Hei {navn}, tallet er {tall + 1}")

import pandas
pandas
import pandas as pd
pd.read_excel
data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:C")
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5-1,
    usecols="A:C",
)
data.loc[14]
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5-1,
    usecols="A:C",
    index_col=0,
)
data.loc["Norge"]
data.iloc[14]
data.info()
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5-1,
    usecols="A:C",
    # index_col=0,
)
data.loc["Norge"]

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5-1,
    usecols="A:C",
    index_col=0,
    na_values="-",
)
data.info()
data.loc["Norge"]
data.Budsjettiltak
data.Budsjettiltak + 1
data.info()
data.Lån og garantier  # <- Virker ikke: kan ikke ha mellomrom i attributter
data.loc["Norge", "Lån og garantier"]
data.loc["Lån og garantier"]  # <- Virker ikke: Lån og garantier er ikke et radnavn
data.loc[:, "Lån og garantier"]
data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5-1,
    usecols="A:C",
    index_col=0,
    na_values="-",
).rename(
    columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"}
)
data.tiltak + data.lån
budsjett = data.assign(
    total=data.tiltak + data.lån    
)
budsjett = data.assign(
    total=data.tiltak + data.lån    
).sort_values(by="total")
1 + 1
(1 + 1)
budsjett = (
    data
    .dropna()
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)
data.dropna(axis="columns")
budsjett = (
    data
    .fillna(value=0)
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)
data_uten_na = data.fillna(value=0)
budsjett = (
    data_uten_na
#    .fillna(value=0)
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)
data_uten_na = data.fillna(value=0)
budsjett = (
    data_uten_na
#    .fillna(value=0)
    .assign(total=data_uten_na.tiltak + data_uten_na.lån)
    .sort_values(by="total")
)
budsjett = (
    data
    .fillna(value=0)
#    .assign(total=data_uten_na.tiltak + data_uten_na.lån)
    .assign(total=lambda data_nå: data_nå.tiltak + data_nå.lån)
    .sort_values(by="total")
)

#
# Pause frem til 10:40
#
norden = ["Norge", "Sverige", "Finland", "Danmark", "Island"]
norden[0]
data.index
data.index.isin(norden)
data_uten_na = data.fillna(value=0)
budsjett = (
    data_uten_na
    .fillna(value=0)
    .assign(
        total=data_uten_na.tiltak + data_uten_na.lån,
        i_norden=data_uten_na.index.isin(norden),
    )
    .sort_values(by="total")
)
budsjett.query("i_norden")
budsjett.query("total > 10")
budsjett.query("lån == 0")
budsjett.query("lån != 0")
budsjett.query("total > 10")
budsjett.query("total > 8")
budsjett.query("total > 8 and i_norden")
budsjett.query("total > 8 or i_norden")
grense = 10
budsjett.query
budsjett.query("lån > 10")
budsjett.query("lånn > 10")
grense = 10
budsjett.query("lån > 10")
budsjett.query("lån > grense")
budsjett.query("lån > @grense")
budsjett.to_excel("budsjett.xlsx")
budsjett.to_excel("budsjett.xlsx", sheet_name="Budsjett")
budsjett.to_excel("budsjett.xlsx", sheet_name="Budsjett")
budsjett.query("i_norden").to_excel("norden.xlsx")
(
    budsjett
    .query("i_norden")
    .drop(columns="i_norden")
    .to_excel("norden.xlsx")
)
(
    budsjett
    .query("i_norden")
    .drop(columns="i_norden")
    .rename(
        columns={"tiltak": "Budsjettiltak", "lån": "Lån og garantier"}
    )
    .to_excel("norden.xlsx")
)
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.bar()
budsjett.plot.bar(stacked=True)
budsjett.loc[:, "tiltak"]
budsjett.loc[:, ["tiltak", "lån"]]
budsjett.loc[:, ["tiltak", "lån"]].plot.bar(stacked=True)
budsjett.loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)

#
# Analyse av bysykkeldata
#
data = pd.read_csv("03.csv")
data.info()
data = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
data.info()
data.ended_at - data.started_at
data.duration
data.plot.scatter(x="started_at", y="duration")
data.plot.scatter(x="started_at", y="duration", alpha=0.2)
data.plot.scatter(x="started_at", y="duration", alpha=0.05)
data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
antall_turer = data.groupby("start_station_name").size().sort_values()
data.groupby("start_station_name").median()
median = data.groupby("start_station_name").median()
data.groupby("start_station_name").median().sort_values()
data.groupby("start_station_name").median().sort_values(by="duration")
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
)
antall_turer
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
)
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)
antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")
tabell = antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")
tabell = antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips", fill_value=0)

data.duration
data.duration / 60
data.duration // 60
data.assign(minutt=data.duration // 60)
data.ended_at - data.started_at
data_mars = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
data_februar = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
pd.concat([data_februar, data_mars])
data = pd.concat([data_februar, data_mars])
data = pd.concat([data_februar, data_mars]).reset_index(drop=True)
data
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)
antall_turer
filnavn = ["02.csv", "03.csv"]
liste_over_data = []
filnavn = ["02.csv", "03.csv"]
liste_over_data = []
for fil in filnavn:
    data_ark = pd.read_csv(fil, parse_dates=["started_at", "ended_at"])
    liste_over_data.append(data_ark)
filnavn = ["02.csv", "03.csv"]
liste_over_data = []
for fil in filnavn:
    data_ark = pd.read_csv(fil, parse_dates=["started_at", "ended_at"])
    liste_over_data.append(data_ark)

data = pd.concat(liste_over_data).reset_index(drop=True)

# PAUSE: Til 12:20

#
# Legg data på kart
#
import folium

kart = folium.Map()
kart.save("bysykkel.html")

kart = folium.Map(location=(59.9, 10.75))
kart.save("bysykkel.html")

kart = folium.Map(location=(59.9, 10.75), zoom_start=14)
kart.save("bysykkel.html")

kart = folium.Map(location=(59.9, 10.75), zoom_start=12)
kart.save("bysykkel.html")

kart = folium.Map(location=(59.92, 10.75), zoom_start=12)
kart.save("bysykkel.html")

data = pd.read_csv("03.csv", parse_dates=["started_at", "ended_at"])
data.loc[0]
kart = folium.Map(location=(59.92, 10.75), zoom_start=12)
folium.Marker((59.9274, 10.796)).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map(location=(59.92, 10.75), zoom_start=12)
folium.Marker((59.9274, 10.796), popup="Bøkkerveien").add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map(location=(59.92, 10.75), zoom_start=12)
folium.CircleMarker(
    (59.9274, 10.796), popup="Bøkkerveien"
).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map(location=(59.92, 10.75), zoom_start=12)
folium.CircleMarker(
    (59.9274, 10.796), popup="Bøkkerveien", fill=True
).add_to(kart)
kart.save("bysykkel.html")

stasjoner = data.loc[:, [
    "start_station_name",
    "start_station_latitude",
    "start_station_longitude"
    ]]
stasjoner.drop_duplicates()
stasjoner = data.loc[:, [
    "start_station_name",
    "start_station_latitude",
    "start_station_longitude"
    ]].drop_duplicates()

stasjoner.index
for id in stasjoner.index:
    stasjon = stasjoner.loc[id]
    print(stasjon)

kart = folium.Map(location=(59.92, 10.75), zoom_start=12)
folium.CircleMarker(
    (59.9274, 10.796), popup="Bøkkerveien", fill=True
).add_to(kart)
for id in stasjoner.index:
    stasjon = stasjoner.loc[id]
    folium.CircleMarker(
        (stasjon.latitude, stasjon.longitude),
        popup=stasjon.name,
        fill=True,
    ).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map(location=(59.92, 10.75), zoom_start=12)
folium.CircleMarker(
    (59.9274, 10.796), popup="Bøkkerveien", fill=True
).add_to(kart)
for id in stasjoner.index:
    stasjon = stasjoner.loc[id]
    folium.CircleMarker(
        (stasjon.latitude, stasjon.longitude),
        popup=stasjon.loc["name"],
        fill=True,
    ).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map(location=(59.92, 10.75), zoom_start=12)
folium.CircleMarker(
    (60.9274, 10.796),
    popup='<a href="https://tekna.no/">Tekna</a>', fill=True
).add_to(kart)
for id in stasjoner.index:
    stasjon = stasjoner.loc[id]
    folium.CircleMarker(
        (stasjon.latitude, stasjon.longitude),
        popup=stasjon.loc["name"],
        fill=True,
    ).add_to(kart)
kart.save("bysykkel.html")
