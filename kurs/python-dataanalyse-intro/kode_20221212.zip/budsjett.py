import pandas as pd

data = (
    pd
    .read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        usecols="A:C",
        index_col=0,
        na_values="-",
    )
    .rename(
        columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"}
    )
    .fillna(0)
)

budsjett = data.assign(total=data.tiltak + data.lån).sort_values(by="total")

budsjett.loc["Norge":, ["tiltak", "lån"]].plot.barh(
    stacked=True, color={"tiltak": "red", "lån": "green"}
)
budsjett.to_excel("budsjett.xlsx")
