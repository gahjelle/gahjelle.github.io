import folium
import pandas as pd

sykkel = pd.read_csv("11.csv", parse_dates=["started_at", "ended_at"])

map = folium.Map(location=(59.9, 10.7), zoom_start=6)
folium.CircleMarker(location=(59.922539, 10.704541), popup="Frogner plass").add_to(map)
map.save("kart.html")
