import pandas as pd

data = pd.read_csv("11.csv", parse_dates=["started_at", "ended_at"])

turer = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        first_trip=("started_at", "first"),
        num_trips=("start_station_id", "count")
    )
)

turer = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .size()
    .sort_values(by="size")
)

tabell = turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="size",
    fill_value=0
)

ukedager = (
    data
    .assign(weekday=data.started_at.dt.day_of_week)
    .groupby("weekday")
    .size()
)

from_station = data.groupby("start_station_name", as_index=False).size()
to_station = data.groupby("end_station_name", as_index=False).size()
pd.merge(
    from_station,
    to_station,
    left_on="start_station_name",
    right_on="end_station_name"
)
