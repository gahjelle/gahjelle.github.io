#
# Intro
#
1 + 1
pannekake  # Feil: pannekake er ikke Python

tall = 42
tall
tall + 3
desimaltall = 3.14
tall + desimaltall
navn = "Geir Arne"
Geir Arne
"Geir Arne"
"pannekake"
navn
"Hei navn"
f"Hei {navn}"
nytt_navn = None
None
none  # Feil, store og små bokstaver er viktige
navn
Navn  # Feil, store og små bokstaver er viktige
tall = 17
pi = 3.14

#
# Les Excelark med pandas
#
import pandas
pandas
import pandas as pd
pd.read_excel("kap1.xlsx")
data = pd.read_excel("kap1.xlsx")
data = pd.read_excel(r"C:\Users\kap1.xlsx")  # Kan bruke full path, skriv en r foran fnuttene når du kopierer Windows-filstier
data = pd.read_excel("kap1.xlsx")
data

data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data=pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name =         "1.2")  # Python er til en viss grad fleksibel med mellomrom

data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:C")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:B")

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
)

#
# Kolonner og rader
#
data.Budsjettiltak
data.Lån og garantier  # Feil: kan bare bruke . for å hente kolonner om kolonnenavnene er "enkle": uten mellomrom osv

# Les kolonner
data["Budsjettiltak"]
data["Lån og garantier"]

# .loc
data.loc[0]
data.loc[10]
data.loc["Norge"]  # Feil: Norge er ikke en rad-indeks

# Kan spesifisere indeks-kolonne
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:C", index_col=0)
data.loc["Norge"]
data.iloc[0]
data.iloc[10]

data.info()
data["Budsjettiltak"]
data["Budsjettiltak"] + 1
data["Budsjettiltak"] * 3 + 1
data["Lån og garantier"] * 3 + 1  # Feil: Lån og garantier er tekst, ikke tall
data["Lån og garantier"]

#
# Innlesing av manglende verdier: NA / nan
#
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    index_col=0,
    na_values="-",
)
data.info()
data["Lån og garantier"]
data["Lån og garantier"] * 3
data["Lån og garantier"] + data["Budsjettiltak"]

# Pause til 10:36

#
# Omnavning av kolonner
#
data.rename(columns={"Lån og garantier": "lån"})
data
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    index_col=0,
    na_values="-",
).rename(columns={"Lån og garantier": "lån"})

data.rename(columns={"Budsjettiltak": "tiltak"})
data = data.rename(columns={"Budsjettiltak": "tiltak"})

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
    index_col=0,
    na_values="-",
).rename(
    columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"}
)

data.tiltak
data.lån
data.lån + data.tiltak
data.assign(total=data.tiltak + data.lån)
budsjett = data.assign(total=data.tiltak + data.lån)

#
# Håndtering av manglende data
#
data.dropna()
data.dropna?  # Spørsmålstegn gir tilgang til dokumentasjon i konsollet
data.dropna(axis="columns")

data.fillna(0)
data = (
    pd
    .read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        usecols="A:C",
        index_col=0,
        na_values="-",
    )
    .rename(
        columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"}
    )
    .fillna(0)
)

#
# Filtrere rader
#
budsjett = data.assign(total=data.tiltak + data.lån)
budsjett.loc["Norge"]
budsjett.query("lån > 10")
budsjett.query("lån > 10 and tiltak < 4")
budsjett.query("lån <= tiltak")

#
# Visualisering og plott
#
# Se eksempler på: https://pandas.pydata.org/docs/user_guide/visualization.html
#
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(stacked=True)

# Endre dataene før du sender dem til .plot...()
budsjett.loc["India"]
budsjett.loc[:, "tiltak"]
budsjett.loc[:, ["tiltak"]]
[1, 4, 7]  # Liste
budsjett.loc[:, ["tiltak", "lån"]]
budsjett.loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)
budsjett.sort_values(by="total")
budsjett.sort_values(by="total").loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)
budsjett.sort_values(by="total").loc[:, ["tiltak", "lån"]]
budsjett.sort_values(by="total").loc[["Norge", "Sverige"], ["tiltak", "lån"]]
budsjett.sort_values(by="total").loc[:"Norge", ["tiltak", "lån"]]
budsjett.sort_values(by="total").loc["Norge":, ["tiltak", "lån"]]
budsjett.sort_values(by="total").loc["Norge":, ["tiltak", "lån"]].plot.barh(stacked=True)

budsjett = data.assign(total=data.tiltak + data.lån).sort_values(by="total")
budsjett.loc["Norge":, ["tiltak", "lån"]].plot.barh(stacked=True)

budsjett.loc["Norge":, ["tiltak", "lån"]].plot.barh(
    stacked=True, color={"tiltak": "red", "lån": "green"}
)

# Skriv til Excel
budsjett.to_excel("budsjett.xlsx")


#
# Bysykkeldata
#
pd.read_csv("11.csv")
data = pd.read_csv("11.csv")
data.info()
data = pd.read_csv("11.csv", parse_dates=["started_at", "ended_at"])
data.info()
data.ended_at - data.started_at

# Pause til 11:58

# Gruppering av data
data.groupby("start_station_name")
data.groupby("start_station_name").median()
turer = data.groupby("start_station_name").median()
turer.info()
data.info()

turer = data.groupby("start_station_name").agg({"duration": "median", "started_at": "first"})
turer = data.groupby("start_station_name").agg({"duration": "median", "started_at": "first", "start_station_id": "count"})
turer = data.groupby("end_station_name").agg({"duration": "median", "started_at": "first", "start_station_id": "count"})

# Kraftigste måten å spesifisere aggregeringer på
data.groupby("start_station_name").agg(num_trips=("start_station_id", "count"))

turer = (
    data
    .groupby("start_station_name")
    .agg(
        median_duration=("duration", "median"),
        first_trip=("started_at", "first"),
        num_trips=("start_station_id", "count")
    )
)
turer.loc["Aker Brygge"]

# Kan bruke as_index=False for å beholde grupperingskolonnen som en normal kolonne
turer = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        first_trip=("started_at", "first"),
        num_trips=("start_station_id", "count")
    )
)

# Gruppere på flere kolonner
data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"], as_index=False).size()
data.groupby(["start_station_name", "end_station_name"], as_index=False).size().sort_values(by="size")
data.groupby(["start_station_name", "end_station_name"], as_index=False).size().sort_values(by="size").query("size > 100")

# Pivottabell
fra_til = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .size()
    .sort_values(by="size")
)
fra_til.pivot_table(index="start_station_name", columns="end_station_name", values="size")
fra_til.pivot_table(index="start_station_name", columns="end_station_name", values="size", fill_value=0)
tabell = fra_til.pivot_table(index="start_station_name", columns="end_station_name", values="size", fill_value=0)

# Aggregering på datoegenskaper
data.started_at
data.started_at.dt.day_of_week
data.assign(weekday=data.started_at.dt.day_of_week)
data.assign(weekday=data.started_at.dt.day_of_week).groupby("weekday").size()

# Slå sammen observasjoner fra samme datasett
data_1 = data
data_2 = data
pd.concat([data_1, data_2])

# Slå sammen tabeller med en felles kolonne
from_station = data.groupby("start_station_name", as_index=False).size()
to_station = data.groupby("end_station_name", as_index=False).size()
pd.merge(from_station, to_station, left_on="start_station_name", right_on="end_station_name")

#
# Kart
#
import folium
map = folium.Map()
map.save("kart.html")

import pandas as pd
sykkel = pd.read_csv("11.csv", parse_dates=["started_at", "ended_at"])

map = folium.Map()
map.save("kart.html")

sykkel.loc[0]

map = folium.Map(location=(59.9, 10.7))
map.save("kart.html")

map = folium.Map(location=(59.9, 10.7), zoom_start=12)
map.save("kart.html")

map = folium.Map(location=(59.9, 10.7), zoom_start=6)
map.save("kart.html")

map = folium.Map(location=(59.9, 10.7), zoom_start=12)
folium.CircleMarker(location=(59.922539, 10.704541), popup="Frogner plass").add_to(map)
map.save("kart.html")
