#
# Introduksjon
#
tre = 3
tre + 1

#
# Importer pandas og les en Excelfil
#
import pandas as pd
pd
pd.read_excel
pd.read_excel()
pd.read_excel("kap1.xlsx")
pd.read_excel(r"C:\datafiler\kap1.xlsx")   # r betyr at \ er \, ikke spesialtegn

#
# Se alle .xlsx-filer
#
import pathlib
pathlib.Path.home()
pathlib.Path.home() / "kurs"
katalog = pathlib.Path.home() / "kurs"
katalog.rglob("*.xlsx")
list(katalog.rglob("*.xlsx"))
list(katalog.rglob("kap1.xlsx"))
katalog.rglob("kap1.xlsx")
next(katalog.rglob("kap1.xlsx"))

#
# Tilpass innlesing av Excelfil
#
data = pd.read_excel("kap1.xlsx")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data.info()

data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, na_values="-")
data.info()

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values=["-", 0.7],
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values=0.7,
)
[1, 2, 3]  # En liste med tre tall
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values=["-", -999],
)

#
# Jobb med kolonner
#
data.Budsjettiltak
data.Budsjettiltak * 2 + 1
data.Lån og garantier  # Feil, kan kun bruke . med kolonnenavn uten mellomrom
data["Lån og garantier"]
data["Lån og garantier"] + data["Budsjettiltak"]

#
# Bruk .loc for å plukke ut rader
#
data.loc
data.loc[0]
data.loc[10]
data.loc["Norge"]  # Feil, Norge er ikke et radnavn

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values=["-", -999],
    index_col=0,
)
data.loc["Norge"]

#
# Bruk .query() til å filtrere rader
#
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values=["-", -999],
    names=["land", "tiltak", "lån"],
)
data.query("land == 'Norge'")

data
"data"
'data'
"data'  # Feil, kan ikke blande fnutter
"It's not raining outside"

data.query("land == 'Norge'")

#
# Sammenligningsoperatorer
#
tre = 3
tre > 2
tre < 1
tre == 3
tre != 3
tre >= 3
tre <= 3
tre <= 2

#
# Mer .query()
#
data.query("tiltak > 5")
data.query(tiltak > 5)  # Feil, tiltak er ikke definert i Python

data.tiltak > 5
data.loc[data.tiltak > 5]
data.query("tiltak > 5")

data.query("lån < 10")
data.query("tiltak > 5 and lån < 10")
data.query("tiltak > 5 or lån < 10")
data.query("tiltak > 5")
data.query("tiltak > 5").query("lån < 10")

#
# Legg til nye kolonner med .assign()
data.tiltak + data.lån
data.assign(total=data.tiltak + data.lån)

#
# Mer selektering med .loc
data.loc[3]
data.loc[1:7]
data.loc[1:7:3]
data.loc[1::3]
data.loc[:]
data.loc[:, "tiltak"]
data.loc[:, ["tiltak", "land"]]
data.assign(total=data.tiltak + data.lån)
data.assign(total=data.tiltak + data.lån).loc[:, ["land", "total"]]

#
# Skriv tilbake til variabelen for å gjøre operasjonen "persistent"
data
data = data.assign(total=data.tiltak + data.lån)

#
# Skriv til en annen variabel for å beholde dataene
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values=["-", -999],
    # index_col=0,
    names=["land", "tiltak", "lån"],
)

budsjett = data.assign(total=data.tiltak + data.lån)
budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .loc[:, ["land", "total"]]
)

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
    .loc[:, ["land", "total"]]
)

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total", ascending=False)
    .loc[:, ["land", "total"]]
)

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by=["total", "land"], ascending=[False, True])
    .loc[:, ["land", "total"]]
)

#
# Desimaltall er vanskelige å sammenligne
#
0.1 + 0.1 + 0.1
0.1 + 0.1 + 0.1 == 0.3
round(0.1 + 0.1 + 0.1, 2)
round(0.1 + 0.1 + 0.1, 2) == 0.3

dir(pd)  # Alle tilgjengelig kommandoer i pandas (pd)
data
budsjett

#
# Håndter manglende verdier
#
data.dropna()
data.dropna(axis="columns")
data.fillna(0)
data.fillna(data.lån.mean())
data.fillna(method="ffill")
data.fillna(method="bfill")

data.bfill()
data.loc[8:10, "lån"] = None
data
data.bfill()

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values=["-", -999],
    names=["land", "tiltak", "lån"],
)

#
# Plott datasett
#
budsjett
budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by=["total", "land"], ascending=[False, True])
)
budsjett
budsjett.plot()
budsjett.plot.scatter("tiltak", "lån")
budsjett.plot.bar()

budsjett.set_index("land")
budsjett.set_index("land").plot.bar()
budsjett.set_index("land").plot.barh()
budsjett.set_index("land").plot.barh(stacked=True)

(
    budsjett
    .set_index("land")
    .loc[:, ["tiltak", "lån"]]
    .plot.barh(stacked=True)
)

(
    budsjett
    .set_index("land")
    .loc[:, ["tiltak", "lån"]]
    .plot.barh(stacked=True, title="Pandemirespons")
)

#
# Lagre data tilbake til Excel
#
budsjett.to_excel("budsjett.xlsx")
budsjett.rename(columns={"tiltak": "Budsjettiltak"})
budsjett.rename(columns={"tiltak": "Budsjettiltak", "lån": "Lån og garantier"})
budsjett.rename(
    columns={
        "tiltak": "Budsjettiltak",
        "lån": "Lån og garantier",
    }
).to_excel("budsjett.xlsx")

budsjett.rename(
    columns={
        "tiltak": "Budsjettiltak",
        "lån": "Lån og garantier",
    }
).to_csv("budsjett.csv")
pd.read_csv("budsjett.csv")

#
# BYSYKKELDATA
#
# Les data fra CSV-fil
#
import pandas as pd
data = pd.read_csv("10.csv")
data.info()
data.ended_at - data.started_at  # Feil, kan ikke trekke to tekststrenger fra hverandre
data = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
data.info()  # parse_dates virket dårlig fordi tiden på en rad var inkonsistent med resten
data.ended_at - data.started_at

data = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
pd.to_datetime(data.started_at, format="mixed")
data.assign(
    started_at=pd.to_datetime(data.started_at, format="mixed"),
    ended_at=pd.to_datetime(data.ended_at, format="mixed")
)

data = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
data = data.assign(
    started_at=pd.to_datetime(data.started_at, format="mixed"),
    ended_at=pd.to_datetime(data.ended_at, format="mixed")
)
data.info()
data.ended_at - data.started_at

#
# Pause til 13:45
#

#
# Løkker (trenger vi sjelden)
#
for number in range(10):
    print(number)
number

#
# Grupperinger og aggregeringer
data.groupby("start_station_name")
data.groupby("start_station_name").size()

data.query("start_station_id == 507")
data.groupby("start_station_name").size().loc["Jens Bjelkes Gate"]

data.groupby("start_station_name").size().sort_values()
data.groupby("end_station_name").size().sort_values()
data.groupby("start_station_name").agg(mean_duration=("duration", "mean"))

start_info = (
    data.groupby("start_station_name")
    .agg(
        mean_duration=("duration", "mean")
        )
    )

start_info = (
    data.groupby("start_station_name")
    .agg(
        mean_duration=("duration", "mean"),
        median_duration=("duration", "median"),
        )
    )
start_info

start_info = (
    data.groupby("start_station_name")
    .agg(
        mean_duration=("duration", "mean"),
        median_duration=("duration", "median"),
        num_trips=("duration", "count"),
        )
    )
start_info

start_info = (
    data.groupby("start_station_name")
    .agg(
        mean_duration=("duration", "mean"),
        median_duration=("duration", "median"),
        num_trips=("duration", "count"),
        )
    .sort_values(by="mean_duration")
    )
start_info

#
# Eksplisitt, enklere tabell
#
tabell = pd.DataFrame({"a": [1, 2, 3], "b": [2.1, None, 3.2], "c": ["a", "a", "b"]})
tabell
tabell.a.mean()
tabell.b.mean()
tabell.groupby("c").mean()
tabell.groupby("c").count()
tabell.assign(en=1)
tabell.assign(en=1).groupby("c").agg(num_trips=("en", "count"))

data.duration.min()
data.duration.max()
data.duration.median()
data.describe()
data.describe().T
data

#
# Unngå at grupperingskolonnene blir lagt på indeksen
#
start_info
start_info = (
    data.groupby("start_station_name", as_index=False)
    .agg(
        mean_duration=("duration", "mean"),
        median_duration=("duration", "median"),
        num_trips=("duration", "count"),
        )
    .sort_values(by="mean_duration")
    )
start_info

#
# Bruk to grupperingsvariabler
#
data.groupby(["start_station_name", "end_station_name"])
data.groupby(["start_station_name", "end_station_name"]).size()
trip_info = (
    data
    .groupby(
        ["start_station_name", "end_station_name"], as_index=False
    )
    .size()
)

trip_info
trip_info.sort_values(by="size")

trip_info = (
    data
    .groupby(
        ["start_station_name", "end_station_name"], as_index=False
    )
    .agg(
        mean_duration=("duration", "mean"),
        num_trips=("duration", "count"),
    )
)
trip_info.sort_values(by="num_trips")

#
# Pivoter dataene for en bedre presentasjon
#
trip_info
trip_info.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")
trip_info.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips", fill_value=0)
overview = trip_info.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="num_trips",
    fill_value=0,
)

#
# Slå sammen datasett
#
pd.merge?

data_sep = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
data_okt = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
data = pd.concat([data_sep, data_okt])
data = data.assign(
    started_at=pd.to_datetime(data.started_at, format="mixed"),
    ended_at=pd.to_datetime(data.ended_at, format="mixed"),
)

# Kjør analysen på begge månedene
start_info = (
    data.groupby("start_station_name", as_index=False)
    .agg(
        mean_duration=("duration", "mean"),
        median_duration=("duration", "median"),
        num_trips=("duration", "count"),
        )
    .sort_values(by="mean_duration")
    )

trip_info = (
    data
    .groupby(
        ["start_station_name", "end_station_name"], as_index=False
    )
    .agg(
        mean_duration=("duration", "mean"),
        num_trips=("duration", "count"),
    )
)

overview = trip_info.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="num_trips",
    fill_value=0,
)

# Bruk løkker for å lese flere datafiler
file_names = ["09.csv", "10.csv"]
for file_name in file_names:
    print(f"Leser {file_name}")
    month_data = pd.read_csv(file_name)
    
all_data = []
file_names = ["09.csv", "10.csv"]
for file_name in file_names:
    print(f"Leser {file_name}")
    month_data = pd.read_csv(file_name)
    all_data.append(month_data)

import pathlib
file_names = pathlib.Path.cwd().glob("*.csv")
all_data = []
for file_name in file_names:
    print(f"Leser {file_name}")
    month_data = pd.read_csv(file_name)
    all_data.append(month_data)
data = pd.concat(all_data)

# Pause til 15:05

#
# Nettkart
#
import folium

map = folium.Map()
map.save("bysykkel.html")

#
# Koblet med dataene fra forrige bolk
#
import pandas as pd

data = pd.read_csv("10.csv")
data.loc[0]

import folium
map = folium.Map(location=(59.9, 10.75))
map.save("bysykkel.html")

# Finn zoom-nivå med prøving og feiling
map = folium.Map(location=(59.9, 10.75), zoom_start=12)
map.save("bysykkel.html")
map = folium.Map(location=(59.9, 10.75), zoom_start=11)
map.save("bysykkel.html")

#
# Legg en sirkelmarkør på kartet
#
map = folium.Map(location=(59.9, 10.75), zoom_start=11)
folium.CircleMarker((59.919147, 10.76413), tooltip="Jens Bjelkes Gate").add_to(map)
map.save("bysykkel.html")

map = folium.Map(location=(59.9, 10.75), zoom_start=11)
folium.CircleMarker(
    (59.919147, 10.76413),
    tooltip="Jens Bjelkes Gate",
    radius=20,
).add_to(map)
map.save("bysykkel.html")

map = folium.Map(location=(59.9, 10.75), zoom_start=11)
folium.CircleMarker(
    (59.919147, 10.76413),
    tooltip="Jens Bjelkes Gate",
    radius=20,
    color="red",
    fill=True,
).add_to(map)
map.save("bysykkel.html")

data.loc[0]
map = folium.Map(location=(59.9, 10.75), zoom_start=11)
folium.CircleMarker(
    (59.919147, 10.76413),
    tooltip="Jens Bjelkes Gate",
    popup="ved Trondheimsveien",
    radius=20,
    color="red",
    fill=True,
).add_to(map)
map.save("bysykkel.html")

#
# Hent koordinater til alle stasjonen
#
data
data.loc[:, ["start_station_name", "start_station_description", "start_station_latitude", "start_station_longitude"]]
data.loc[:, ["start_station_name", "start_station_description", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
stations = data.loc[:, [
    "start_station_name",
    "start_station_description",
    "start_station_latitude",
    "start_station_longitude"
    ]].drop_duplicates()

#
# Løkke over rader
#
for station in stations.itertuples():
    print(station)

for station in stations.itertuples():
    print(station.start_station_name)

# Tegn alle stasjoner 
map = folium.Map(location=(59.9, 10.75), zoom_start=11)
folium.CircleMarker(
    (59.919147, 10.76413),
    tooltip="Jens Bjelkes Gate",
    popup="ved Trondheimsveien",
    radius=20,
    color="red",
    fill=True,
).add_to(map)
for station in stations.itertuples():
    folium.CircleMarker(
        (station.start_station_latitude, station.start_station_longitude),
        tooltip=station.start_station_name,
        popup=station.start_station_description,
        radius=20,
        color="red",
        fill=True,
    ).add_to(map)
map.save("bysykkel.html")

#
# Bruk kartunderlag fra Kartverket
map = folium.Map(location=(59.9, 10.75), zoom_start=11, tiles="https://opencache.statkart.no/gatekeeper/gk/gk.open_gmaps?layers=topo4&zoom={z}&x={x}&y={y}", attr="Kartverket")
for station in stations.itertuples():
    folium.CircleMarker(
        (station.start_station_latitude, station.start_station_longitude),
        tooltip=station.start_station_name,
        popup=station.start_station_description,
        radius=20,
        color="red",
        fill=True,
    ).add_to(map)
map.save("bysykkel.html")
