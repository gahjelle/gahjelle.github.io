import pandas as pd

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values=["-", -999],
    # index_col=0,
    names=["land", "tiltak", "lån"],
)

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by=["total", "land"], ascending=[False, True])
#    .loc[:, ["land", "total"]]
)

(
    budsjett
    .set_index("land")
    .loc[:, ["tiltak", "lån"]]
    .plot.barh(stacked=True, title="Pandemirespons")
)

budsjett.rename(
    columns={
        "tiltak": "Budsjettiltak",
        "lån": "Lån og garantier",
    }
).to_excel("budsjett.xlsx")