import folium
import pandas as pd

# Kan hente data fra forrige script
#
# import bysykkel
#
# bysykkel.trip_info


data = pd.read_csv("10.csv")
stations = data.loc[:, [
    "start_station_name",
    "start_station_description",
    "start_station_latitude",
    "start_station_longitude"
    ]].drop_duplicates()

map = folium.Map(
    location=(59.9, 10.75),
    zoom_start=11,
    # Søk: Kartverket Leaflet -> Kopier tileLayer-adresse
    tiles="https://opencache.statkart.no/gatekeeper/gk/gk.open_gmaps?layers=topo4&zoom={z}&x={x}&y={y}",
    attr="Kartverket"
)
folium.CircleMarker(
    (59.919147, 10.76413),
    tooltip="Jens Bjelkes Gate",
    popup="ved Trondheimsveien",
    radius=20,
    color="red",
    fill=True,
).add_to(map)
for station in stations.itertuples():
    folium.CircleMarker(
        (station.start_station_latitude, station.start_station_longitude),
        tooltip=station.start_station_name,
        popup=station.start_station_description,
        radius=20,
        color="red",
        fill=True,
    ).add_to(map)
map.save("bysykkel.html")
