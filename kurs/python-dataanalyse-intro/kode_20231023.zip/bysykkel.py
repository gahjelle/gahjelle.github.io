import pandas as pd

data_sep = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
data_okt = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
data = pd.concat([data_sep, data_okt])

# Bruk løkker for å lese mange datafiler
import pathlib
file_names = pathlib.Path.cwd().glob("*.csv")  # .rglob() går ned i undermapper
# file_names = pathlib.Path(r"C:\gahjelle\kurs").glob("*.csv")

all_data = []
# file_names = ["09.csv", "10.csv"]
for file_name in file_names:
    print(f"Leser {file_name}")
    month_data = pd.read_csv(file_name)
    all_data.append(month_data)
data = pd.concat(all_data)

data = data.assign(
    started_at=pd.to_datetime(data.started_at, format="mixed"),
    ended_at=pd.to_datetime(data.ended_at, format="mixed"),
)

start_info = (
    data.groupby("start_station_name", as_index=False)
    .agg(
        mean_duration=("duration", "mean"),
        median_duration=("duration", "median"),
        num_trips=("duration", "count"),
        )
    .sort_values(by="mean_duration")
    )

trip_info = (
    data
    .groupby(
        ["start_station_name", "end_station_name"], as_index=False
    )
    .agg(
        mean_duration=("duration", "mean"),
        num_trips=("duration", "count"),
    )
)

overview = trip_info.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="num_trips",
    fill_value=0,
)

# Eksplisitt egen tabell
tabell = pd.DataFrame(
    {"a": [1, 2, 3], "b": [2.1, None, 3.2], "c": ["a", "a", "b"]}
)
