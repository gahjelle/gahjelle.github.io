#
# Introduksjon
#
1 + 2
navn = "Geir Arne"
navn
Geir Arne  # FEIL: Geir Arne er ikke en Pythonkommando
print  # Referanse til en funksjon
print("Heisann")  # Bruk () for å kalle en funksjon
print(f"Hei {navn}")
print(f"Hei {navn}, 1 + 2 = {1 + 2}")

def si_hei(navn):
    return f"Hei {navn}"

si_hei
si_hei()  # FEIL: Mangler verdi for navn
si_hei("Geir Arne")

navn = input("Hva heter du? ")
si_hei(navn)

navn = input("Hva heter du? ")
print(si_hei(navn))

# Importer biblioteker for å få tilgang til funksjoner, strukturer og verdier
import math
math.pi

#
# Les Exceldata med pandas
#
import pandas as pd
pd.read_excel("kap1.xlsx")
pd.read_excel("kap1.xlsx", sheet_name="1.2")
pd.read_excel("kap1.xlsx", sheet_name="1.2tull")  # FEIL: arknavn er feil

data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)  # FEIL: Python teller rader fra 0
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:C")

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
)

[1, 4, 7]  # Eksempel på liste

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2] # Eller "A:C",
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2], # Eller "A:C",
    index_col=0,
)

data.Budsjettiltak
data.Lån og garantier  # FEIL: Kan ikke bruke dot (.) på kolonner med mellomrom i navnet

data.loc
data.loc["Norge"]
data.loc["Budsjettiltak"]
data.loc[:, "Budsjettiltak"]
data.loc[:, "Lån og garantier"]
data.loc[:, "Budsjettiltak"] * 2
data.loc[:, "Lån og garantier"] + 1  # FEIL: Lån og garantier er ikke tall (enda)

data.info()

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2], # Eller "A:C",
    index_col=0,
    na_values="-",
)

data.info()
data.loc[:, "Lån og garantier"] + 1
data.loc[:, "Lån og garantier"] + data.loc[:, "Budsjettiltak"]
data.rename(columns={"Lån og garantier": "lån"})
data.rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})
data = data.rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2], # Eller "A:C",
    index_col=0,
    na_values="-",
).rename(
    columns={
        "Lån og garantier": "lån",
        "Budsjettiltak": "tiltak"
    }
)

data.tiltak + data.lån

# PAUSE

data.loc[:, "tiltak"]
data.iloc[:, 0]  # .iloc[] kan adressere rader og kolonner på indekser

data.tiltak
data.Norge  # FEIL: radnavn kan ikke bruke dot (.) -aksess, bruk .loc[]
data.loc["Norge"]
data.loc["Norge", "tiltak"]
data.loc[["Norge", "Sverige"], "tiltak"]
data.tiltak + data.lån

data.assign(total=data.tiltak + data.lån)
budsjett = data.assign(total=data.tiltak + data.lån)

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)

budsjett.dropna()

budsjett.fillna
budsjett.fillna(0)
budsjett = (
    data
    .fillna(0)
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2], # Eller "A:C",
    index_col=0,
    na_values="-",
).rename(
    columns={
        "Lån og garantier": "lån",
        "Budsjettiltak": "tiltak"
    }
).fillna(0)

budsjett = (
    data
    .assign(total=data.tiltak + data.lån)
    .sort_values(by="total")
)

norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]

budsjett.index
budsjett.index.isin(norden)

budsjett = (
    data
    .assign(
        total=data.tiltak + data.lån,
        i_norden=budsjett.index.isin(norden)
    )
    .sort_values(by="total")
)

budsjett = (
    data
    .assign(
        total=data.tiltak + data.lån,
        i_norden=data.index.isin(norden)
    )
    .sort_values(by="total")
)

budsjett.query("tiltak > 5")
budsjett.query("tiltak < 5")
budsjett.query("tiltak < 5 and lån > 10")
budsjett.query("i_norden")
budsjett.query("not i_norden")

budsjett.to_excel("budsjett.xlsx")
budsjett.query("i_norden").to_excel("norden.xlsx")

budsjett.plot()
budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(stacked=True)
budsjett.loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)

import matplotlib.pyplot as plt

#
# Les bysykkeldata
#
data = pd.read_csv("01.csv")
data.columns
data.head()
data.head(1)
data.iloc[0]
data.info()

data = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
data.info()
data.ended_at - data.started_at
data.started_at.max()
data.started_at.max().year

data.groupby("start_station_name")
data.groupby("start_station_name").median()
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("start_station_name").size().sort_values().reset_index()
data.groupby("start_station_name").size().sort_values().reset_index().rename(columns={0: "num_trips"})

antall_turer = (
    data
    .groupby("start_station_name")
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

data.groupby("start_station_name").size()
data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"]).size().sort_values()

antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

antall_turer.pivot_table(values="num_trips", index="start_station_name", columns="end_station_name")
turer = (
    antall_turer
    .pivot_table(
        values="num_trips",
        index="start_station_name",
        columns="end_station_name"
    )
)

turer = (
    antall_turer
    .pivot_table(
        values="num_trips",
        index="start_station_name",
        columns="end_station_name"
    )
    .fillna(0)
)

turer = (
    antall_turer
    .pivot_table(
        values="num_trips",
        index="start_station_name",
        columns="end_station_name",
        fill_value=0,
    )
)


data = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

turer = (
    antall_turer
    .pivot_table(
        values="num_trips",
        index="start_station_name",
        columns="end_station_name",
        fill_value=0,
    )
)
antall_turer

data_jan = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
data_feb = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
pd.concat?  # ? gir hjelp i konsollvinduet
pd.concat([data_jan, data_feb])
pd.concat([data_jan, data_feb]).loc[0]
pd.concat([data_jan, data_feb]).reset_index()
pd.concat([data_jan, data_feb]).reset_index(drop=True)


data_jan = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
data_feb = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
data = pd.concat([data_jan, data_feb]).reset_index(drop=True)

antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

turer = (
    antall_turer
    .pivot_table(
        values="num_trips",
        index="start_station_name",
        columns="end_station_name",
        fill_value=0,
    )
)

antall_turer

# Løkker
norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
for land in norden:
    print(land)

norden = ["Norge", "Sverige", "Danmark"]
for land in norden:
    print(land)


data_måned = []
datasett = ["01.csv", "02.csv"]
for datanavn in datasett:
    print(f"Leser {datanavn}")
    en_måned = pd.read_csv(datanavn, parse_dates=["started_at", "ended_at"])

data_måned = []
datasett = ["01.csv", "02.csv"]
for datanavn in datasett:
    print(f"Leser {datanavn}")
    en_måned = pd.read_csv(datanavn, parse_dates=["started_at", "ended_at"])
    data_måned.append(en_måned)
data_måned

data_måned = []
datasett = ["01.csv", "02.csv"]
for datanavn in datasett:
    print(f"Leser {datanavn}")
    en_måned = pd.read_csv(datanavn, parse_dates=["started_at", "ended_at"])
    data_måned.append(en_måned)
data = pd.concat(data_måned).reset_index(drop=True)

import pathlib
list(pathlib.Path.cwd().glob("*.csv"))

data_måned = []
datasett = pathlib.Path.cwd().glob("*.csv")  # Alternativt ["01.csv", "02.csv"]
for datanavn in datasett:
    print(f"Leser {datanavn}")
    en_måned = pd.read_csv(datanavn, parse_dates=["started_at", "ended_at"])
    data_måned.append(en_måned)
data = pd.concat(data_måned).reset_index(drop=True)

data_måned = []
datasett = pathlib.Path.cwd().glob("*.csv")  # Alternativt ["01.csv", "02.csv"]
for datanavn in datasett:
    print(f"Leser {datanavn}")
    en_måned = pd.read_csv(datanavn, parse_dates=["started_at", "ended_at"])
    data_måned.append(en_måned)
data = pd.concat(data_måned).reset_index(drop=True)

pathlib.Path  # Noen strukturer navngis med stor forbokstav
pd.DataFrame

data_måned = []
datasett = pathlib.Path.cwd().glob("*.csv")  # Alternativt ["01.csv", "02.csv"]
for datanavn in datasett:
    print(f"Leser {datanavn}")
    en_måned = pd.read_csv(datanavn, parse_dates=["started_at", "ended_at"])
data_måned.append(en_måned)  # FEIL: .append() gjøres nå bare en gang til slutt, ikke en gang for hver fil
data = pd.concat(data_måned).reset_index(drop=True)

datanavn
norden = ["Norge", "Sverige", "Danmark"]
for i in range(len(norden)):
    print(i)

for i in range(len(norden)):
    print(i, norden[i])

for land in norden:
    print(land)

for i, land in enumerate(norden):
    print(i, land)


#
# Kart
#
import folium

kart = folium.Map()
kart.save("kart.html")

data.iloc[0]

kart = folium.Map(location=[59.92, 10.76])
kart.save("kart.html")

kart = folium.Map(location=[59.92, 10.76], zoom_start=12)
kart.save("kart.html")

kart = folium.Map(location=[59.92, 10.76], zoom_start=12)
folium.Marker(location=[59.919147, 10.76413], popup="Jens Bjelkes Gate").add_to(kart)
kart.save("kart.html")
