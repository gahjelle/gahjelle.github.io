def si_hei(navn):
    return f"Hei {navn}"


navn = input("Hva heter du? ")
print(si_hei(navn))
