import folium

kart = folium.Map(location=[59.92, 10.76], zoom_start=12)
folium.Marker(location=[59.919147, 10.76413], popup="Jens Bjelkes Gate").add_to(kart)
kart.save("kart.html")
