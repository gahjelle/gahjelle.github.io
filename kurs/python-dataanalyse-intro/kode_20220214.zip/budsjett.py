import pandas as pd

norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]

data = (
    pd.read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        usecols=[0, 1, 2],  # Eller "A:C",
        index_col=0,
        na_values="-",
    )
    .rename(columns={"Lån og garantier": "lån", "Budsjettiltak": "tiltak"})
    .fillna(0)
)


budsjett = data.assign(
    total=data.tiltak + data.lån, i_norden=data.index.isin(norden)
).sort_values(by="total")

budsjett.to_excel("budsjett.xlsx")

budsjett.query("i_norden").to_excel("norden.xlsx")
