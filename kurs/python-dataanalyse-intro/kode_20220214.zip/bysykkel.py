import pandas as pd
import pathlib

# data_jan = pd.read_csv("01.csv", parse_dates=["started_at", "ended_at"])
# data_feb = pd.read_csv("02.csv", parse_dates=["started_at", "ended_at"])
# data = pd.concat([data_jan, data_feb]).reset_index(drop=True)

data_måned = []
datasett = pathlib.Path.cwd().glob("*.csv")  # Alternativt ["01.csv", "02.csv"]
for datanavn in datasett:
    print(f"Leser {datanavn}")
    en_måned = pd.read_csv(datanavn, parse_dates=["started_at", "ended_at"])
    data_måned.append(en_måned)
data = pd.concat(data_måned).reset_index(drop=True)


antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

turer = antall_turer.pivot_table(
    values="num_trips",
    index="start_station_name",
    columns="end_station_name",
    fill_value=0,
)
