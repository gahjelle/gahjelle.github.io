import folium

kart = folium.Map(location=(59.9, 10.7), zoom_start=12)
folium.CircleMarker(
    (59.925471, 10.731219),
    tooltip="Bislett stadion",
    popup="Dette vises når du klikker på markøren",
    radius=40,
    fill=True,
).add_to(kart)
folium.Circle(
    (59.925471, 10.731219),
    tooltip="Bislett stadion",
    popup="Dette vises når du klikker på markøren",
    radius=40,
    fill=True,
).add_to(kart)
kart.save("bysykler.html")
