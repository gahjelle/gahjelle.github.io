#
# Introduksjon
#
1 + 2
tall = 42
navn = "Geir Arne"
tall * 3
f"Hei, {navn}"
tall * 3
tall * 3
nvan  # Feil: nvan er en feilstaving av navn
import math
math.sqrt(tall)

import pandas
import finnes_ikke  # Feil: biblioteket "finnes_ikke" finnes ikke

pandas.read_csv

import pandas as pd  # pd er et alias til pandas
pd.read_csv

#
# Les inn en Excelfil
#
pandas.read_excel()
pandas.read_excel("kap1.xlsx")
pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data = pandas.read_excel("kap1.xlsx", header=4, sheet_name="1.2")

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
)
data.info()

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
)
data.info()

data
data["Budsjettiltak"]
data["Budsjettiltak"] + 1
data["Budsjettiltak"] + data["Lån og garantier"]
data["budsjettiltak"] + 1  # Feil: Stor B er viktig
data[""]  # Feil: Dette er ikke navnet på "kolonnen uten navn"
data.columns
data[" "]

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
)

data["land"]
data["tiltak"]
data.info()

#
# Håndtering av manglende verdier
#
data
data.dropna()
data.dropna(axis="columns")
data.fillna(0)
budsjett = data.fillna(0)
data.fillna(123)
data
data.ffill()
data.bfill()

#
# Formler og filtre
#
data["tiltak"]
data["tiltak"] - 5
data["tiltak"] + data["lån"]
budsjett["tiltak"] + budsjett["lån"]
budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"])
budsjett.query("tiltak > 4")
budsjett.query("lån <= 10")
budsjett.query("lån = 0")
budsjett.query("lån == 0")
budsjett.query("tiltak > 4 and lån < 10")
budsjett.query("tiltak > 4 or lån < 10")
budsjett.query("total > 20")  # Feil: "total" er ikke en kolonne i budsjett

budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"])

(
    budsjett
    .assign(total=budsjett["tiltak"] + budsjett["lån"])
    .query("total > 20")
)

(
    budsjett
    .assign(total=budsjett["tiltak"] + budsjett["lån"])
    .query("total > 20")
    .sort_values(by="total")
)

data.mean()  # Feil: kan ikke ta gjennomsnitt av tekstkolonnen, land.

#
# Plotting av data
#
budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"])
budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"]).plot()

# Disse linjene kan være nødvendige for å få plottet til å vise seg
import matplotlib.pyplot as plt
plt.show()

budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"]).plot.bar()
budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"]).plot.barh()
budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"]).plot.barh(x="land")

(
    budsjett
    .assign(total=budsjett["tiltak"] + budsjett["lån"])
    .plot.barh(x="land", stacked=True)
)

(
    budsjett
    .assign(total=budsjett["tiltak"] + budsjett["lån"])
    .plot.barh(x="land", stacked=True, y=["tiltak", "lån"])
)

#
# Skriv til Excel
#
budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"]).to_excel("budsjett.xlsx")


#
# Bysykkeldata
#
import pandas

data = pandas.read_csv("02.csv")
data.groupby("start_station_name").agg(
    duration=("duration", "mean"), num_trips=("start_station_name", "size")
)

# PAUSE til 12:00

pandas.read_csv("02.csv")
turer_fra = data.groupby("start_station_name").agg(
    duration=("duration", "mean"), num_trips=("start_station_name", "size")
)

turer_fra = data.groupby("start_station_name", as_index=False).agg(
    duration=("duration", "mean"), num_trips=("start_station_name", "size")
)

turer_fra = data.groupby("start_station_name", as_index=False).agg(
    duration=("duration", "mean"),
    num_trips=("start_station_name", "size"),
    max_duration=("duration", "max"),
)

turer_til = data.groupby("end_station_name", as_index=False).agg(
    num_trips=("end_station_name", "size"),
)

turer_fra.merge(turer_til)  # Feil: Litt uklart hva som blir slått sammen, sannsynligvis rader med samme antall turer

turer_fra.merge(turer_til, left_on="start_station_name", right_on="end_station_name")

antall_turer = turer_fra.merge(
    turer_til, left_on="start_station_name", right_on="end_station_name"
)

data.groupby(["start_station_name", "end_station_name"], as_index=False)
data.groupby(["start_station_name", "end_station_name"], as_index=False).agg(
    num_trips=("start_station_name", "size")
)
turer = data.groupby(["start_station_name", "end_station_name"], as_index=False).agg(
    num_trips=("start_station_name", "size")
)

turer.pivot_table(
    index="start_station_name", columns="end_station_name", values="num_trips"
)
pivotert = turer.pivot_table(
    index="start_station_name", columns="end_station_name", values="num_trips"
)

#
# Kartvisualisering
#
import folium

kart = folium.Map()
kart.save("bysykler.html")

data

kart = folium.Map(location=(59.9, 10.7))
kart.save("bysykler.html")

kart = folium.Map(location=(59.9, 10.7), zoom_start=12)
kart.save("bysykler.html")

kart = folium.Map(location=(59.9, 10.7), zoom_start=12)
folium.Marker((59.925471, 10.731219), tooltip="Bislett stadion").add_to(kart)
kart.save("bysykler.html")

kart = folium.Map(location=(59.9, 10.7), zoom_start=12)
folium.Marker(
    (59.925471, 10.731219),
    tooltip="Bislett stadion",
    popup="Dette vises når du klikker på markøren",
).add_to(kart)
kart.save("bysykler.html")

kart = folium.Map(location=(59.9, 10.7), zoom_start=12)
folium.CircleMarker(
    (59.925471, 10.731219),
    tooltip="Bislett stadion",
    popup="Dette vises når du klikker på markøren",
).add_to(kart)
kart.save("bysykler.html")

kart = folium.Map(location=(59.9, 10.7), zoom_start=12)
folium.CircleMarker(
    (59.925471, 10.731219),
    tooltip="Bislett stadion",
    popup="Dette vises når du klikker på markøren",
    radius=40,
    fill=True,
).add_to(kart)
kart.save("bysykler.html")

kart = folium.Map(location=(59.9, 10.7), zoom_start=12)
folium.CircleMarker(
    (59.925471, 10.731219),
    tooltip="Bislett stadion",
    popup="Dette vises når du klikker på markøren",
    radius=40,
    fill=True,
).add_to(kart)
folium.Circle(
    (59.925471, 10.731219),
    tooltip="Bislett stadion",
    popup="Dette vises når du klikker på markøren",
    radius=40,
    fill=True,
).add_to(kart)
kart.save("bysykler.html")
