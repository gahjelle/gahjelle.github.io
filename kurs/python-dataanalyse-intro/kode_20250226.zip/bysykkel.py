import pandas

data = pandas.read_csv("02.csv")

turer_fra = data.groupby("start_station_name", as_index=False).agg(
    duration=("duration", "mean"),
    num_trips=("start_station_name", "size"),
    max_duration=("duration", "max"),
)

turer_til = data.groupby("end_station_name", as_index=False).agg(
    num_trips=("end_station_name", "size"),
)

antall_turer = turer_fra.merge(
    turer_til, left_on="start_station_name", right_on="end_station_name"
)

turer = data.groupby(["start_station_name", "end_station_name"], as_index=False).agg(
    num_trips=("start_station_name", "size")
)

pivotert = turer.pivot_table(
    index="start_station_name", columns="end_station_name", values="num_trips"
)
