import pandas

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
)

budsjett = data.fillna(0)

(
    budsjett
    .assign(total=budsjett["tiltak"] + budsjett["lån"])
    .query("total > 20")
    .sort_values(by="total")
)

(
    budsjett
    .assign(total=budsjett["tiltak"] + budsjett["lån"])
    .plot.barh(x="land", stacked=True, y=["tiltak", "lån"])
)

budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"]).to_excel("budsjett.xlsx")
