import pandas as pd

# data = pd.read_csv("08.csv", sep=";")  # Bruk semikolon i stedet for komma
data = pd.read_csv("08.csv", parse_dates=["started_at", "ended_at"])

testdata = data.set_index("started_at").loc["2020-08-12"].reset_index()

antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(
        columns={0: "number_of_trips"}
    )
)

matrise = (
    antall_turer.pivot_table(
        index="start_station_name",
        columns="end_station_name",
        values="number_of_trips"
        )
    )