# Introduksjon

print("Hei alle sammen")
print("Hei Geir Arne")
navn = "Geir Arne"
navn
print(navn)
print("Hei {navn}")
print(f"Hei {navn}")
print(f"Hei {navn})
print(f"Hei {navn}")
navn = input("Hva heter du? ")
print(f"Hei {navn}")


# Revidert statsbudsjett

import pandas
import pandas as pd
pd.read_excel?
data = pd.read_excel(path, sheet_name="1.2", header=4)
data = pd.read_excel(path, sheet_name="1.2", header=4, usecols="A:C")
data = pd.read_excel(path, sheet_name="1.2", header=4, usecols=[0, 1, 2])
data = pd.read_excel(path, sheet_name="1.2", header=4, usecols=[0, 1, 2])
pre = os.path.dirname(os.path.realpath(__file__))

fname = "kap1.xlsx"

path = os.path.join(pre, fname)
path = os.path.join(pre, fname)


data = pd.read_excel(path, sheet_name="1.2", header=4, usecols=[0, 1, 2])
range(0, 3)
list(range(0, 3))
list(range(0, 40))
data
data.info()
data = pd.read_excel(
    path,
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],
    na_values="-"
)
data.info()
data = pd.read_excel(
    path,
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],
    na_values="-",
    index_col=0
)


data = pd.read_excel(
    path,
    sheet_name="1.2",  # Kan også bruke tall, 2 er tredje ark
    header=4,
    usecols=[0, 1, 2],
    na_values="-",
    index_col=0
)
data
data.loc["Norge"]
data.loc[["Norge", "Sverige"]]
data.Budsjettiltak
data.Lån og garantier
data.loc[:, "Lån og garantier"]
data.tiltak
data.lån
data.tiltak + data.lån
2 * data.tiltak - data.lån
data.assign(total=data.tiltak + data.lån)
data = data.assign(total=data.tiltak + data.lån)
data = data.assign(total=data.tiltak + data.lån)
data = data.assign(total3=data.tiltak + data.lån)
budsjett = data.assign(
    total=data.tiltak + data.lån,
    tull=2 * data.tiltak - data.lån
    )

# Pause 1
#
# Gå til https://oslobysykkel.no/apne-data/historisk
# Last ned August 2020, CSV
# Vi starter opp igjen 10:25

data.tiltak > 10
data.lån > 10
budsjett = data.assign(
    total=data.tiltak + data.lån,
    ).sort_values(by="total")
blåbærsyltetøy = 3
budsjett = (
    data.assign(total=data.tiltak + data.lån,)
    .sort_values(by="total")
)
budsjett = (
    data.assign(total=data.tiltak + data.lån,)
    .sort_values(by="total")
    .dropna(how="any")
)
budsjett = (
    data.assign(total=data.tiltak + data.lån,)
    .sort_values(by="total")
    .dropna(how="all")
)
budsjett = (
    data.assign(total=data.tiltak + data.lån,)
    .sort_values(by="total")
    .dropna(how="any")
)
budsjett = (
    data.assign(total=data.tiltak + data.lån,)
    .sort_values(by="total")
    .fillna(value=0)
)
budsjett = (
    data.fillna(value=0)
    .assign(total=data.tiltak + data.lån,)
    .sort_values(by="total")
)
data
data_med_verdier = data.fillna(value=0)
data_med_verdier
data_med_verdier.total + data_med_verdier.lån
data_med_verdier.tiltak + data_med_verdier.lån
data_med_verdier = data.fillna(value=0)
history
budsjett = (
    data.fillna(value=0)
    .assign(total=lambda d: d.tiltak + d.lån,)
    .sort_values(by="total")
)
data
data.index
data.index.isin(["Norge", "Sverige"])
budsjett.lån > 10
budsjett.query("lån > 10")
budsjett.query("total > 10")
budsjett.query("lån > tiltak")
budsjett.query("lån > tiltak and total > 10")
budsjett.query("lån > tiltak or total > 10")
budsjett.query("i_norden")
budsjett.query("i_norden == True")
budsjett.query("i_norden")
budsjett.query("lån == 5")
budsjett.query("lån >= 5")
budsjett.query("lån > 5")
budsjett.query("index == 'Norge'")
budsjett.query("index == "Norge"")  # Feil bruk av fnutter
budsjett.query('index == "Norge"')
"Norge'  # Feil bruk av fnutter
'Norge'
budsjett.total  > 10
budsjett.loc[budsjett.total > 10]
budsjett.query("total > 10")
budsjett.to_excel(ut_fil, sheet_name="Budsjett")

ut_fil = os.path.join(pre, "total.xlsx")

budsjett.to_excel(ut_fil, sheet_name="Budsjett")
ut_fil = os.path.join(pre, "total.xlsx")

budsjett.rename(
    columns = {
        "tiltak": "Budsjettiltak",
        "lån": "Lån og garantier",
        "i_norden": "Norden?"
        }
    ).to_excel(ut_fil, sheet_name="Budsjett")
ut_fil = os.path.join(pre, "total.xlsx")

budsjett.rename(
    columns = {
        "tiltak": "Budsjettiltak",
        "lån": "Lån og garantier",
        "i_norden": "Norden?"
        },
    index = {"Finland": "Soumi"}
    ).to_excel(ut_fil, sheet_name="Budsjett")
ut_fil = os.path.join(pre, "total.xlsx")

budsjett.rename(
    columns = {
        "tiltak": "Budsjettiltak",
        "lån": "Lån og garantier",
        "i_norden": "Norden?"
        },
    index = {"Finland": "Soumi"}
    ).to_excel(ut_fil, sheet_name="Budsjett")
budsjett.plot()
budsjett.plot()
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.bar(stacked=True)
budsjett.loc[:, ["tiltak", "lån"]].plot.bar(stacked=True)
import matplotlib.pyplot as plt
plt.title("Budsjett")
budsjett.loc[:, ["tiltak", "lån"]].plot.bar(stacked=True)
fig = budsjett.loc[:, ["tiltak", "lån"]].plot.bar(stacked=True)
plt.title("Budsjett")
fig = budsjett.loc[:, ["tiltak", "lån"]].plot.bar(stacked=True)

plt.title("Budsjett")
history


# Bysykler

data = pd.read_csv("08.csv")
data
data
data.info()
data = pd.read_csv("08.csv", parse_dates=["started_at", "ended_at"])
data.info()
data.loc[4]
data.set_index("started_at").loc["2020-08-12"]
data.set_index("started_at").loc["2020-08-12 14"]
data.set_index("started_at").loc["2020-08-12"].reset_index()
data.set_index("started_at").loc["2020-07-12"].reset_index()
data.set_index("started_at").head()
testdata.ended_at - testdata.started_at
testdata.duration
history

# Pause 2
#
# Vi starter opp igjen kl 12:00

testdata.plot.scatter(x="started_at", y="duration")
testdata.plot(x="started_at", y="duration")
testdata.plot(x="started_at", y="duration", style=".")
testdata.plot(x="started_at", y="duration", style=".", alpha=0.2)
testdata.plot(x="started_at", y="duration", style=".", alpha=0.05)
pd.__version__
testdata.groupby("start_station_name")
testdata.groupby("start_station_name").size()
testdata.groupby("start_station_name").size().sort_values()
data.groupby("start_station_name").size().sort_values()
data.groupby("start_station_name").median()
start = data.groupby("start_station_name").median()
data.groupby("start_station_name").median().sort_values(by="duration")
(
    data.groupby("start_station_name")
    .median()
    .sort_values(by="duration")
)
(
    data.groupby(["start_station_name", "end_station_name"])
    .median()
    .sort_values(by="duration")
)
(
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
)
antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
)
antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
)
antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(
        columns={0: "number_of_trips"}
    )
)
matrise = (
    antall_turer.pivot_table(
        index="start_station_name",
        columns="end_station_name",
        value="number_of_trips"
        )
    )
matrise = (
    antall_turer.pivot_table(
        index="start_station_name",
        columns="end_station_name",
        values="number_of_trips"
        )
    )
antall_turer.query("number_of_trips > 150")
data.info()
data.loc[:, ["start_station_id", "start_station_name", "start_station_description", "start_station_latitude", "start_station_longitude"]]
data.loc[:, ["start_station_id", "start_station_name", "start_station_description", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
stasjoner
stasjoner.loc[0]
stasjoner.loc[423]


#
# Kart
#
for stasjon in stasjoner.index:
    folium.CircleMarker(
        [59.9203, 10.7608], popup="Schous plass", radius=50, fill=True
    ).add_to(kart)
    print(stasjon)
