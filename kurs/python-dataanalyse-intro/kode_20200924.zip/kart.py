import folium
import pandas as pd

data = pd.read_csv("08.csv", parse_dates=["started_at", "ended_at"])

stasjoner = (
    data.loc[:, [
        "start_station_id",
        "start_station_name",
        "start_station_description",
        "start_station_latitude",
        "start_station_longitude"
    ]]
    .drop_duplicates()
    .rename(
        columns={
            "start_station_id": "id",
            "start_station_name": "name",
            "start_station_description": "description",
            "start_station_latitude": "lat",
            "start_station_longitude": "lon"
            })
    .set_index("id")
)

kart = folium.Map(location=[59.9, 10.75], zoom_start=11)

for stasjon in stasjoner.index:
    folium.CircleMarker(
        [stasjoner.loc[stasjon, "lat"], stasjoner.loc[stasjon, "lon"]],
        popup=stasjoner.loc[stasjon, "name"],
        radius=3 * len(stasjoner.loc[stasjon, "name"]),
        fill=True
    ).add_to(kart)

kart.save("bysykkel.html")
