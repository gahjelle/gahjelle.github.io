import pandas as pd
import os

# Workaround for å finne riktig fil
pre = os.path.dirname(os.path.realpath(__file__))
fname = "kap1.xlsx"
path = os.path.join(pre, fname)

# Les et excelark
data = pd.read_excel(
    path,
    sheet_name="1.2",  # Kan også bruke tall, 2 er tredje ark
    header=4,
    usecols=[0, 1, 2],
    na_values="-",
    index_col=0
).rename(
    columns={
        "Budsjettiltak": "tiltak",
        "Lån og garantier": "lån"
        }
    )

norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
    
budsjett = (
    data.fillna(value=0)
    .assign(
        total=lambda d: d.tiltak + d.lån,
        i_norden=lambda d: d.index.isin(norden),
    )
    .sort_values(by="total")
)

ut_fil = os.path.join(pre, "total.xlsx")
budsjett.rename(
    columns = {
        "tiltak": "Budsjettiltak",
        "lån": "Lån og garantier",
        "i_norden": "Norden?"
        },
    index = {"Finland": "Soumi"}
).to_excel(ut_fil, sheet_name="Budsjett")

import matplotlib.pyplot as plt
fig = budsjett.loc[:, ["tiltak", "lån"]].plot.bar(stacked=True)
plt.title("Budsjett")

