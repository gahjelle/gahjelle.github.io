import pandas

# Les inn excelark
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
)

# Alternativ til names
# .rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån", " ": "land"})

budsjett = data.assign(total=data["tiltak"] + data["lån"], en=1)
