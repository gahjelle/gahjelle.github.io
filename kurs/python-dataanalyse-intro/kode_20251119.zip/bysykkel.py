import pandas

data = pandas.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
turer = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601")
)

turlengde = (
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        count=("start_station_name", "count"),
        length=("duration", "mean"),
        shortest_trip=("duration", "min"),
        # longest_trip=("duration", "max"),
    )
)

strekninger = (
    turer
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(count=("start_station_name", "count"))
    .sort_values(by="count")
)

oversikt = strekninger.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="count",
    fill_value=0,
    aggfunc="sum",
)

stations = turer.groupby("start_station_name").agg(
    name=("start_station_name", "first"),
    lon=("start_station_longitude", "first"),
    lat=("start_station_latitude", "first")
)

pandas.merge(turlengde, stations, left_on="start_station_name", right_on="name")
