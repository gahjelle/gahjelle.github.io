import pandas
import folium

data = pandas.read_csv("10.csv")
stations = data.groupby("start_station_name").agg(
    name=("start_station_name", "first"),
    lon=("start_station_longitude", "first"),
    lat=("start_station_latitude", "first")
)

kart = folium.Map((59.93, 10.7), zoom_start=12)
for station in stations.itertuples():
    folium.CircleMarker(
        (station.lat, station.lon),
        # popup="Hallings gate",
        tooltip=station.name,
        fill=True,
    ).add_to(kart)
kart.save("kart.html")
