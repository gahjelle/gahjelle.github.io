#
# Introduksjon
#
1 + 2
tall = 3
tall
tall + 1
Tall
tall = 3.25
tall = float(3)
tall = 4.0
navn = "Geir Arne"
navn = 'Geir Arne'
Geir Arne  # Feil: Geir Arne er ikke gyldig syntaks i Python
Geir  # Feil: Geir er ikke et variabelnavn Python kjenner igjen

#
# Les inn Excelfil
#
import pandas
pandas
pandas.read_excel()  # Feil: Trenger et filnavn
pandas.read_excel("kap1.xlsx")
pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data.info()
data
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, na_values="-")
data.info()
1.23
1,23  # Komma lager tupler i Python
[1, 4, 8]
["-", ".", "manglende"]
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, na_values=["-", ".", "manglende"])
data
data["Budsjettiltak"]
data["Budsjettiltak"] * 3
data["Budsjettiltak"] * 3 + data["Lån og garantier"]
data["Budsjettiltak"]*3+data["Lån og garantier"]
data["Budsjettiltak"]*  3 +     data["Lån og garantier"]
data["lån og garantier"]  # Feil: liten l i Lån
data["Lån og garantier"]
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, na_values=["-", ".", "manglende"], names=["land", "tiltak", "lån"])
data["tiltak"] + data["lån"]
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5,
    na_values="-",
    names=["land", "tiltak", "lån"]
)
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5,
    na_values="-",
    names=["land", "tiltak", "lån"],
)
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5,
    na_values="-",
    names=["land", "tiltak"],
)
data
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5,
    na_values="-",
    names=["land", "tiltak", "lån", "tull"],
)
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5,
    na_values="-",
    # names=["land", "tiltak", "lån"],
)
data.rename(columns={"Budsjettiltak": "tiltak"})
data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
data
data = data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5,
    na_values="-",
    # names=["land", "tiltak", "lån"],
)
budsjett = data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=5,
    na_values="-",
    # names=["land", "tiltak", "lån"],
).rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
data = data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån", "": "land"})
data.columns
data = data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån", " ": "land"})

# Pause til 10:34

#
# Jobb med manglende data
#
data
data.dropna()
data.dropna(axis="columns")
data.fillna(0)
data["lån"].mean()
data.fillna(data["lån"].mean())
data.fillna(data["lån"].median())
data.ffill()
data.bfill()

#
# Legg til nye kolonner
#
data["tiltak"] + data["lån"]
data.assign(total=data["tiltak"] + data["lån"])
budsjett = data.assign(total=data["tiltak"] + data["lån"])
1
budsjett = data.assign(total=data["tiltak"] + data["lån"], en=1)

#
# Hent ut kolonner og rader
#
budsjett["tiltak"]
budsjett[["tiltak", "lån"]]
budsjett.loc[5]
budsjett.loc[[5, 12, 17]]
budsjett.query("tiltak > 8")
budsjett.query("tiltak > lån")
budsjett.query("land == Norge")
budsjett.query("land == 'Norge'")
budsjett.query("tiltak > lån and total < 5")
budsjett.query("tiltak > lån or total < 5")

#
# Plott data og skriv tilbake til Excel
#
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(x="land")
budsjett.plot.barh(x="land", stacked=True)
budsjett.plot.barh(x="land", stacked=True, y=["tiltak", "lån"])
budsjett.to_excel("budsjett.xlsx")

#
# Bysykkeldata
#
import pandas
data = pandas.read_csv("10.csv")
data.info()
data["ended_at"] - data["started_at"]  # Feil: kan ikke subtrahere tekstkolonner

#
# Datokolonner
#
data = pandas.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
data.info()
pandas.to_datetime(data["started_at"])
pandas.to_datetime(data["started_at"], format="ISO8601")
turer = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601")
)
turer.info()
turer["ended_at"] - turer["started_at"]
(turer["ended_at"] - turer["started_at"]).max()

#
# Grupper og aggreger
#
turer.groupby("start_station_name")
turer.groupby("start_station_name").agg(count=("start_station_name", "count"))
turer.groupby("start_station_name").agg(count=("start_station_name", "count")).sort_values(by="count")
turer.groupby("end_station_name").agg(count=("start_station_name", "count")).sort_values(by="count")
(
    turer
    .groupby("start_station_name")
    .agg(
        count=("start_station_name", "count")
    )
)

(
    turer
    .groupby("start_station_name")
    .agg(
        count=("start_station_name", "count"),
        length=("duration", "mean"),
    )
)

(
    turer
    .groupby("start_station_name")
    .agg(
        count=("start_station_name", "count"),
        length=("duration", "mean"),
        shortest_trip=("duration", "min"),
    )
)

(
    turer
    .groupby("start_station_name")
    .agg(
        count=("start_station_name", "count"),
        length=("duration", "mean"),
        shortest_trip=("duration", "min"),
        longest_trip=("duration", "max"),
    )
)

(
    turer
    .groupby("start_station_name")
    .agg(
        count=("start_station_name", "count"),
        length=("duration", "mean"),
        shortest_trip=("duration", "min"),
        # longest_trip=("duration", "max"),
    )
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        count=("start_station_name", "count"),
        length=("duration", "mean"),
        shortest_trip=("duration", "min"),
        # longest_trip=("duration", "max"),
    )
)

# Pause til 12:03

#
# Sorter rader
#
data.sort_values(by="duration")
data.sort_values(by="duration")[["started_at", "duration"]]
data.sort_values(by="duration", descending=True)[["started_at", "duration"]]
data.sort_values(by="duration", ascending=False)[["started_at", "duration"]]
data.sort_values(by="duration")[["started_at", "duration"]]
data.sort_values(by=["duration", "started_at"])[["started_at", "duration"]]
data.sort_values(by=["duration", "started_at"], ascending=False)[["started_at", "duration"]]
data.sort_values(by=["duration", "started_at"], ascending=[False, True])[["started_at", "duration"]]

#
# Gruppèr på flere kolonner
#
turer.groupby(["start_station_name", "end_station_name"], as_index=False).agg(count=("start_station_name", "count"))
turer.groupby(["start_station_name", "end_station_name"], as_index=False).agg(count=("start_station_name", "count")).sort_values(by="count")

strekninger = (
    turer
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .agg(count=("start_station_name", "count"))
    .sort_values(by="count")
)

strekninger.pivot_table(index="start_station_name", columns="end_station_name", values="count")
strekninger.pivot_table(index="start_station_name", columns="end_station_name", values="count", fill_value=0)
strekninger.pivot_table(index="start_station_name", columns="end_station_name", values="count", fill_value=0, agg_func="sum")
strekninger.pivot_table(index="start_station_name", columns="end_station_name", values="count", fill_value=0, aggfunc="sum")
oversikt = strekninger.pivot_table(index="start_station_name", columns="end_station_name", values="count", fill_value=0, aggfunc="sum")

#
# Slå sammen tabeller
#
september = data
oktober = data
pandas.concat([september, oktober])
pandas.concat([september, oktober]).reset_index()
pandas.concat([september, oktober]).reset_index(drop=True)

stations = turer.groupby("start_station_name").agg(name=("start_station_name", "first"), lon=("start_station_longitude"), lat=("start_station_latitude"))
stations = turer.groupby("start_station_name").agg(name=("start_station_name", "first"), lon=("start_station_longitude", "first"), lat=("start_station_latitude", "first"))
turlengde = (
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        count=("start_station_name", "count"),
        length=("duration", "mean"),
        shortest_trip=("duration", "min"),
        # longest_trip=("duration", "max"),
    )
)
pandas.merge(turlengde, stations)  # Feil: Må spesifisere hvilke kolonner som skal matches
pandas.merge(turlengde, stations, left_on="start_station_name", right_on="name")
pandas.merge(turlengde, stations, left_on="start_station_name", right_on="name", how="right")

#
# Kart
#
import pandas
data = pandas.read_csv("10.csv")
import folium
folium.Map().save("kart.html")

kart = folium.Map()
kart.save("kart.html")

data.loc[0]
kart = folium.Map((59.9, 10.7), zoom_start=6)
kart.save("kart.html")

kart = folium.Map((59.9, 10.7), zoom_start=12)
kart.save("kart.html")

kart = folium.Map((59.93, 10.7), zoom_start=12)
kart.save("kart.html")

kart = folium.Map((59.93, 10.7), zoom_start=12)
folium.Marker(
    (59.922777, 10.738655),
    popup="Hallings gate",
    tooltip="langs Dalsbergstien"
).add_to(kart)
kart.save("kart.html")

kart = folium.Map((59.93, 10.7), zoom_start=12)
folium.CircleMarker(
    (59.922777, 10.738655),
    popup="Hallings gate",
    tooltip="langs Dalsbergstien"
).add_to(kart)
kart.save("kart.html")

kart = folium.Map((59.93, 10.7), zoom_start=12)
folium.CircleMarker(
    (59.922777, 10.738655),
    popup="Hallings gate",
    tooltip="langs Dalsbergstien",
    fill=True,
).add_to(kart)
kart.save("kart.html")

#
# Bruk løkker for å gjenta kode
#
["Geir", "Arne", "Jørgen"]
for navn in ["Geir", "Arne", "Jørgen"]:
    print(f"{navn} har {len(navn)} bokstaver")

stations = data.groupby("start_station_name").agg(
    name=("start_station_name", "first"),
    lon=("start_station_longitude", "first"),
    lat=("start_station_latitude", "first")
)

kart = folium.Map((59.93, 10.7), zoom_start=12)
for station in stations.itertuples():
    folium.CircleMarker(
        (59.922777, 10.738655),
        popup="Hallings gate",
        tooltip="langs Dalsbergstien",
        fill=True,
    ).add_to(kart)
kart.save("kart.html")

kart = folium.Map((59.93, 10.7), zoom_start=12)
for station in stations.itertuples():
    folium.CircleMarker(
        (station.lat, station.lon),
        tooltip=station.name,
        fill=True,
    ).add_to(kart)
kart.save("kart.html")
