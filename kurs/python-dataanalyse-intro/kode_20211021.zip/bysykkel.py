"""Analyse av bysykkeldata"""

import pathlib
import pandas as pd

# data_sep = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
# data_okt = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
# data = pd.concat([data_sep, data_okt]).reset_index(drop=True)

filnavn = pathlib.Path().glob("*.csv")   # Alternativt ["09.csv", "10.csv"]
månedsdata = []
for navn in filnavn:
    print(f"Leser {navn}")
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    månedsdata.append(enkeltdata)
data = pd.concat(månedsdata).reset_index(drop=True)


antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values(ascending=False)
    .reset_index()
    .rename(columns={0: "antall_turer"})
)

turer = antall_turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="antall_turer",
    fill_value=0
)
