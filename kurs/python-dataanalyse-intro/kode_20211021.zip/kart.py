"""Visualisering av bysykkelstasjoner"""

import folium
import pandas as pd

data = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
stasjoner = (
    data.loc[:, [
        "start_station_name",
        "start_station_latitude",
        "start_station_longitude"
    ]].drop_duplicates()
        )

kart = folium.Map(location=[59.92, 10.7], zoom_start=13)

for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=[stasjon.start_station_latitude, stasjon.start_station_longitude],
        popup=stasjon.start_station_name,
        fill=True,
        radius=20,
    ).add_to(kart)

kart.save("bysykkelkart.html")
