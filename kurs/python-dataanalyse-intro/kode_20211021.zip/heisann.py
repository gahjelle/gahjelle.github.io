"""Spør brukeren etter navnet deres"""

navn = input("Hva heter du? ")
print(f"Hei {navn}")
