#
# Intro
#
1 + 2
print(1, 2, 3)
print("Hei alle sammen!")
print('Hei alle sammen!')
navn = "Geir Arne"
navn
print(f"Hei {navn}")
input("Hva heter du?")
navn = input("Hva heter du? ")
print(f"Hei {navn}")

#
# pandas er et Pythonbibliotek for dataanalyse
#
import pandas as pd
pd.read_excel()  # FEIL: trenger et filnavn
pd.read_excel("kap1.xlsx")
pd.read_excel(r"C:\Users\giron\kurs\kap1.xlsx")  # Trenger r foran windows filstier

data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:C")

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols="A:C",
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
)

data.loc[14]

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
    index_col=0,
)

data.loc[14]  # FEIL: 14 er ikke lenger i index'en (radnavn)
data.loc["Norge"]
data.Budsjettiltak
data.Lån og garantier  # FEIL: Kan ikke bruke dot-notasjon på kolonner med mellomrom
data.loc[:, "Lån og garantier"]
data.loc["Sverige", "Lån og garantier"]
data.rename(columns={"Budsjettiltak": "tiltak"})
data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})
data = data.rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
    index_col=0,
).rename(
    columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"}
)

data.tiltak
data.lån
data.tiltak
data.tiltak + 1
data.tiltak + data.lån  # FEIL: .lån er tekst og kan ikke legges til .tiltak
data.lån

# Håndtering av manglende verdier

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
    index_col=0,
    na_values="-",
).rename(
    columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"}
)

data.lån
data.tiltak + data.lån
data.assign(tull=1)
data.assign(total=data.tiltak + data.lån)
budsjett = data.assign(total=data.tiltak + data.lån)

# PAUSE til 10:32

data.info()
8 * 2 * 19
data.assign(tull=1)

# Kast manglende data
budsjett = data.assign(total=data.tiltak + data.lån).dropna()
data.dropna(subset=["lån"])
data.dropna(subset=["tiltak"])
data.dropna(how="any")
data.dropna(how="all")

# Fyll manglende data med gitte verdier (0)
budsjett = data.assign(total=data.tiltak + data.lån).fillna(0)
budsjett = data.fillna(0).assign(total=data.tiltak + data.lån)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],   # Alternativt "A:C",
    index_col=0,
    na_values="-",
).rename(
    columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"}
).fillna(0)
budsjett = data.assign(total=data.tiltak + data.lån)

budsjett
budsjett.lån.mean()  # Håndterer manglende verdier
budsjett.describe()

budsjett = data.assign(total=data.tiltak + data.lån).sort_values("total")

#
# Spørringer
#
budsjett.query("total > 10")
budsjett.query("tiltak > lån")
budsjett.query("tiltak > lån and lån > 2")
budsjett.query("10 < total < 20")
budsjett.query("10 < total and total < 20")

# Legg til i_norden kolonne
norden = ["Norge", "Sverige", "Finland", "Danmark", "Island"]
budsjett.index.isin(norden)
budsjett

budsjett = (
    data
    .assign(
        total=data.tiltak + data.lån,
        i_norden=data.index.isin(norden),
    )
    .sort_values("total")
)

budsjett.query("i_norden")
budsjett.query("not i_norden")
budsjett.query("i_norden and total > 10")

#
# Skriv tilbake til Excel
#
budsjett.to_excel("budsjett.xlsx")
budsjett.rename(columns={"lån": "Lån og garantier"}).to_excel("budsjett.xlsx")
budsjett.rename(columns={"lån": "Lån og garantier"}).to_excel("budsjett.xlsx")
budsjett.query("i_norden").to_excel("norden.xlsx")

#
# Tegn figurer
#
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(stacked=True)
budsjett.loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)

#
# Endre verdier i noen rader
budsjett.query("i_norden")
budsjett.total * 2

budsjett.total = budsjett.query("i_norden").total * 2  # Sletter verdier for land utenfor Norden
budsjett = (
    data
    .assign(
        total=data.tiltak + data.lån,
        i_norden=data.index.isin(norden),
    )
    .sort_values("total")
)

idx = budsjett.i_norden
budsjett.loc[idx, "total"] = budsjett.loc[idx, "total"] * 2
budsjett.loc[idx, "total"] = [10, 20, 30, 40]

#
# Større datasett: Bysykkeldata
#
data = pd.read_csv("10.csv")
data.info()
pd.read_csv("10.csv")
data
data.head()
data.head(10)
data.tail(10)
data.loc[0]

# Bruk dato-typer
data = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
data.info()
data.ended_at - data.started_at

# Aggreger data
data.groupby("start_station_name")
data.groupby("start_station_name").count()
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("end_station_name").size().sort_values()

# Pause til 12:00
data.groupby("end_station_name").mean()
data.groupby("end_station_name").mean().columns

# Grupper på flere kolonner
data.groupby(["start_station_name", "end_station_name"]).size().sort_values()
data.groupby(["start_station_name", "end_station_name"]).size().sort_values(ascending=False)

antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values(ascending=False)
)

antall_turer.index
antall_turer.reset_index()

antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values(ascending=False)
    .reset_index()
    .rename(columns={0: "antall_turer"})
)

antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="antall_turer")
turer = antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="antall_turer")
turer = antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="antall_turer").fillna(0)
turer = antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="antall_turer", fill_value=0)

# Slå sammen flere datasett
data_sep = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
data_okt = pd.read_csv("10.csv", parse_dates=["started_at", "ended_at"])
data_sep.info()
pd.concat([data_sep, data_okt])
pd.concat([data_sep, data_okt]).reset_index()
pd.concat([data_sep, data_okt]).reset_index(drop=True)

antall_turer = (
    data
    .groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values(ascending=False)
    .reset_index()
    .rename(columns={0: "antall_turer"})
)

turer = antall_turer.pivot_table(
    index="start_station_name",
    columns="end_station_name",
    values="antall_turer",
    fill_value=0
)

# Mer fleksibelt med for-løkke
filnavn = ["09.csv", "10.csv"]
for navn in filnavn:
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])

filnavn = ["09.csv", "10.csv"]
for navn in filnavn:
    print(f"Leser {navn}")
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])

filnavn = ["09.csv", "10.csv"]
månedsdata = []
for navn in filnavn:
    print(f"Leser {navn}")
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    månedsdata.append(enkeltdata)
månedsdata

filnavn = ["09.csv", "10.csv"]
månedsdata = []
for navn in filnavn:
    print(f"Leser {navn}")
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    månedsdata.append(enkeltdata)
data = pd.concat(månedsdata).reset_index(drop=True)

# Les filnavn rett fra disk
import pathlib
pathlib.Path()
pathlib.Path().resolve()
pathlib.Path().glob("*")
list(pathlib.Path().glob("*"))
list(pathlib.Path().glob("*.csv"))

filnavn = pathlib.Path().glob("*.csv")   # Alternativt ["09.csv", "10.csv"]
månedsdata = []
for navn in filnavn:
    print(f"Leser {navn}")
    enkeltdata = pd.read_csv(navn, parse_dates=["started_at", "ended_at"])
    månedsdata.append(enkeltdata)
data = pd.concat(månedsdata).reset_index(drop=True)

#
# Visualiser data på kart
import folium
kart = folium.Map()
kart.save("bysykkelkart.html")

data.loc[0]
kart = folium.Map(location=[59.9, 10.7])
kart.save("bysykkelkart.html")

kart = folium.Map(location=[59.9, 10.7], zoom_start=13)
kart.save("bysykkelkart.html")

kart = folium.Map(location=[59.92, 10.7], zoom_start=13)
kart.save("bysykkelkart.html")

kart = folium.Map(location=[59.92, 10.7], zoom_start=13)
folium.CircleMarker(
    location=[59.928132, 10.71842],
    popup="Valkyrieplassen",
).add_to(kart)
kart.save("bysykkelkart.html")

kart = folium.Map(location=[59.92, 10.7], zoom_start=13)
folium.CircleMarker(
    location=[59.928132, 10.71842],
    popup="Valkyrieplassen",
    fill=True,
    radius=20,
).add_to(kart)
kart.save("bysykkelkart.html")

data = pd.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
stasjoner = (
    data.loc[:, [
        "start_station_name",
        "start_station_latitude",
        "start_station_longitude"
    ]].drop_duplicates()
        )

for stasjon in stasjoner:
    print(stasjon)

for stasjon in stasjoner.iterrows():
    print(stasjon)

for idx, stasjon in stasjoner.iterrows():
    print(stasjon)

kart = folium.Map(location=[59.92, 10.7], zoom_start=13)
for idx, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=[stasjon.start_station_latitude, stasjon.start_station_longitude],
        popup=stasjon.start_station_name,
        fill=True,
        radius=20,
    ).add_to(kart)
kart.save("bysykkelkart.html")
