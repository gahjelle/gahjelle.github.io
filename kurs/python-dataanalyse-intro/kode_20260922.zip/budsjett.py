import pandas

data = (
    pandas.read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        names=["land", "tiltak", "lån"],
        na_values=["-", "manglende verdi"],
    )
    .dropna()
    .reset_index(drop=True)
)

data.iloc[:, 1]  # i - int, loc - lokaliser, : - alle rader, 1 - andre kolonne
data["tiltak"] + data["lån"]

budsjett = data.assign(total=data["tiltak"] + data["lån"])

# Spørringer
budsjett[budsjett["tiltak"] > 5]
budsjett[(budsjett["tiltak"] > 5) & (budsjett["lån"] < 5)]

budsjett.query("tiltak > 5")
budsjett.query("tiltak > 5 and lån < 5") 

norden = ["Norge", "Sverige", "Finland", "Danmark", "Island"]
budsjett.query("land.isin(@norden)")
budsjett[budsjett["land"].isin(norden)]

# %%  Celle

# Ny syntaks
# data.assign(total=pandas.col("tiltak") + pandas.col("lån"))

# Parenteser
# () - utfør kommando, gruppere
# [] - lister, hente ut elementer/kolonner
# {} - set (mengde)

# Sammenligning
# == - lik
# != - ulik
# <, >  - mindre enn, større enn
# <= - mindre enn eller lik

