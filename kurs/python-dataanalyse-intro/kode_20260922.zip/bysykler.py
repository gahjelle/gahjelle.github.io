import pandas

data_aug = pandas.read_csv("08.csv")
data_sep = pandas.read_csv("09.csv")
data = pandas.concat([data_aug, data_sep]).reset_index(drop=True)

data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)

data.groupby("end_station_name", as_index=False).size().sort_values(by="size")

def most_common(start_station_name):
    return start_station_name.mode().iloc[0]

end_stations = (
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("end_station_latitude", "first"),
        most_common=("start_station_name", most_common),
    )
    .sort_values(by="latitude")
)

start_stations = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        most_common=("end_station_name", most_common),
    )
    .sort_values(by="latitude")
)

stations = start_stations.merge(
    end_stations,
    left_on="start_station_name",
    right_on="end_station_name",
)
