import pandas
import folium

data = pandas.read_csv("09.csv")

stations = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
)

# Søk "Kartverket Leaflet"
kart = folium.Map(
    (59.9, 10.73),
    zoom_start=13,
    tiles="https://cache.kartverket.no/v1/wmts/1.0.0/topograatone/default/webmercator/{z}/{y}/{x}.png",
    attr="Kartverket",
)
for station in stations.itertuples():
    folium.CircleMarker((station.start_station_latitude, station.start_station_longitude),
                  popup=station.start_station_name, fill=True, radius=30).add_to(kart)

kart.save("kart.html")