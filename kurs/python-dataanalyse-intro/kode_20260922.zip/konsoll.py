#
# Variabler
#
1 + 2
tall = 3
tall
tall * 2
Tall  # Feil: liten og stor bokstav er viktig
nytt tall = 7  # Feil: kan ikke ha mellomrom i variabelnavn
nytt_tall =  7
navn = Geir Arne  # Feil: tekst trenger fnutter
navn = "Geir Arne"
navn
navn + 3  # Feil: kan ikke blande tekst og tall
en_tekst_som_ser_ut_som_et_tall = "42"
en_tekst_som_ser_ut_som_et_tall + 3  # Feil: kan ikke plusse tekst og tall
navn * 3
"-" * 70
en_tekst_som_ser_ut_som_et_tall
"-" * 45
tall=3
tall                    =   5

#
# Les inn Excelfil
#
import pandas
pandas
pandas.read_excel
pandas.read_excel()
pandas.read_excel("Kap1.xlsx")
pandas.read_excel("kap1.xlsx")
pandas.read_excel("C:\underveis\kap1.xlsx") # Feil: Filstier på Windows, med \ må behandles spesielt
print("Geir\nArne")  # \ brukes for å skrive spesialtegn, f.eks. \n er linjeskift
pandas.read_excel(r"C:\underveis\kap1.xlsx")
pandas.read_excel("kap1.xlsx")
pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2")

from pandas import read_excel
read_excel

data = pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data

# Pause til 10:22

data
data["Budsjettiltak"]
data.iloc[0]  # Første rad
data.iloc[:, 0]  # Første kolonne
data.iloc[:, 1]  # Andre kolonne
data["Budsjettiltak"]
data["Budsjettiltak"] * 5
data["Budsjettiltak"] * 5 + 3
data["Budsjettiltak"] > 10
data["Budsjettiltak"] > 5
data["land"] == "Norge"  # Feil: kolonnen heter ikke land, den er "ett mellomrom"
data[" "] == "Norge"
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, names=["land", "tiltak", "lån"])
data["land"]
data.land
data.info()
data["tiltak"] + data["lån"]  # Feil: lån-kolonnen er tekst og ikke tall
3.14 + "2.1"  # Samme feil: kan ikke plusse tall og tekst
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, names=["land", "tiltak", "lån"], na_values="-")
data.info()

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],
    na_values="-",
)

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],
    na_values="-",
)

data
data["tiltak"] + data["lån"]
data["tiltak"].mean()
data["lån"].mean()
data

data.dropna()
clean = data.dropna()
clean
clean.info()
clean = data.dropna().reset_index()
clean
clean = data.dropna().reset_index(drop=True)
clean

data
data.dropna(axis="column")
data.dropna(axis="columns")
data.dropna(subset=["tiltak"])
data.dropna(subset=["tiltak", "lån"])
data.fillna(0)
data.dropna(subset=["tiltak", lån"])  # Feil: mangler en fnutt
data.ffill()
data.bfill()

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],
    na_values="-",
).dropna().reset_index(drop=True)

data
"3.1".isnumeric()
"3.1".isdecimal()
"31".isnumeric()

[1, 2, 3]
["Oslo", "Raufoss", "Trondheim"]
byer = ["Oslo", "Raufoss", "Trondheim"]
byer[0]
byer()  # Feil: kan ikke "utføre" en liste
byer[1]
{"Oslo", "Raufoss", "Trondheim"}
{"Oslo", "Raufoss", "Trondheim", "Oslo"}
byer = {"Oslo", "Raufoss", "Trondheim", "Oslo"}
byer[0]  # Feil: kan ikke nummerere et set
{"Oslo": "Oslo", "Raufoss": "Innlandet", "Trondheim": "Trøndelag"}
fylker = {"Oslo": "Oslo", "Raufoss": "Innlandet", "Trondheim": "Trøndelag"}
fylker["Raufoss"]
data
data.rename(columns={"land": "stat"})

data["land"] == "Norge"
1 == 1
1 = 2  # Feil: ett = tilordner variabler, 1 er ikke et gyldig variabelnavn
1 == 2
1 < 2
1 <= 2
1 <= 1
1 != 1
1 != 2
"Geir Arne"
'Geir Arne"  # Feil: fnutter må komme i par
'Geir Arne'
"Geir Arne" == 'Geir Arne'
'Jonas sa "Hei"'
"Jonas sa "Hei""  # Feil: kan ikke ha nestede fnutter
"Jonas sa \"Hei\""

data = (pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],
    na_values=["-", "manglende verdi"],
).dropna().reset_index(drop=True))

data = (
    pandas.read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        names=["land", "tiltak", "lån"],
        na_values=["-", "manglende verdi"],
    )
    .dropna()
    .reset_index(drop=True)
)

#
# Jobb med data
#
data["tiltak"] + data["lån"]
data.assign(total=data["tiltak"] + data["lån"])
data.assign(total=data["tiltak"] + data["lån"], en=1)
# Ny syntaks i pandas v3, expressions
pandas.__version__
pandas.col("tiltak")
pandas.col("tiltak") + pandas.col("lån")
data.assign(total=pandas.col("tiltak") + pandas.col("lån"))
pandas.col("geirarne")
data.assign(geirarne=pandas.col("geirarne"))  # Feil: kolonnen geirarne finnes ikke i data
data.assign(geirarne=pandas.col("tiltak"))
data = data.assign(geirarne=pandas.col("tiltak"))

data = (
    pandas.read_excel(
        "kap1.xlsx",
        sheet_name="1.2",
        header=4,
        names=["land", "tiltak", "lån"],
        na_values=["-", "manglende verdi"],
    )
    .dropna()
    .reset_index(drop=True)
)

pandas.read_excel("kap1.xlsx")
data
data.assign(total=data["tiltak"] + data["lån"])
budsjett = data.assign(total=data["tiltak"] + data["lån"])
budsjett["tiltak"] > 5
budsjett[budsjett["tiltak"] > 5]

data["tiltak"] * 2
budsjett[budsjett["tiltak"] > 5 & budsjett["lån"] < 5]  # Feil: pandas skjønner ikke hva og (&) binder sammen
budsjett[(budsjett["tiltak"] > 5) & (budsjett["lån"] < 5)]
budsjett.query("tiltak > 5")
budsjett.query("tiltak > 5 and lån < 5")

norden = ["Norge", "Sverige", "Finland", "Danmark", "Island"]
"Norge" in norden
"Tyskland" in norden

budsjett["land"].isin(norden)
budsjett[budsjett["land"].isin(norden)]
budsjett.query("land.isin(norden)")  # Feil: norden finnes ikke som en kolonne i budsjett
budsjett.query("land.isin(@norden)")
budsjett[budsjett["land"].isin(norden)]

#
# Figurer
#
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.bar(x="land")
budsjett.plot.barh(x="land")
budsjett.plot.bar(y="land")  # Feil: y-aksen trenger numeriske verdier
budsjett.plot.barh(x="land")
budsjett.plot.barh(x="land", stacked=True)
budsjett.plot.barh(x="land", y=["tiltak", "lån"], stacked=True)
data.plot.barh(x="land", stacked=True)

budsjett.drop(columns="total")
budsjett.drop(columns="total").plot.barh(x="land")
budsjett.plot.barh(x="land", y=["tiltak", "lån"], stacked=True)
budsjett.plot.bar(x="land", y=["tiltak", "lån"], stacked=True)
budsjett.plot.bar(x="land", y=["tiltak", "lån"], stacked=True, title="Teknakurs")

import pandas as pd
import numpy as np

budsjett.plot.bar(x="land", y=["tiltak", "lån"], stacked=True, title="Teknakurs", cmap="plasma")
budsjett.plot.bar(x="land", y=["tiltak", "lån"], stacked=True, title="Teknakurs", cmap="hsv")
budsjett.to_excel("budsjett.xlsx")

# Pause til 13:50

#
# Bysykler, større datasett
#
import pandas

data = pandas.read_csv("09.csv")
data.info()

data = pandas.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
data.info()

data["ended_at"] - data["started_at"]  # Feil: kolonnene er tekst
pandas.to_datetime(data["started_at"])  # Feil: må angi et format pga inkonsistens
pandas.to_datetime(data["started_at"], format="ISO8601")
data = pandas.read_csv("09.csv")
data = data.assign(  # Kanskje feil: rare tegn i datasettet
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)

data
data.info()
data["ended_at"] - data["started_at"]
(data["ended_at"] - data["started_at"]).max()
(data["ended_at"] - data["started_at"]).median()

data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("start_station_name").size().max()
data.groupby("end_station_name").size().sort_values()

next(iter(data.groupby("end_station_name")))
next(iter(data.groupby("end_station_name")))
next(iter(data.groupby("start_station_name")))

grupper = iter(data.groupby("start_station_name"))
next(grupper)
next(grupper)
next(grupper)

for stasjon in grupper:
    print(stasjon)

#
# Gruppér og aggregér
#
data.groupby("start_station_name").agg(median_duration=("duration", "median"))
data.groupby("start_station_name").agg(median_duration=("duration", "median")).sort_values(by="median_duration")
data.groupby("start_station_name").agg(median_duration=("duration", "median")).sort_values()  # Feil: må angi en kolonne
data.groupby("end_station_name").size().sort_values()
data.groupby("end_station_name").size()
data.groupby("end_station_name").size().info()
data.groupby("end_station_name", as_index=False).size()
data.groupby("end_station_name", as_index=False).size().info()
data.groupby("end_station_name", as_index=True).size()

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median")
    )
)

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median")
    )
    .sort_values(by="median_duration")
)

(
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median")
    )
    .sort_values(by="median_duration")
)

(
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
    )
    .sort_values(by="min_duration")
)

(
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("end_station_latitude", "first"),
    )
    .sort_values(by="min_duration")
)

(
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("end_station_latitude", "first"),
    )
    .sort_values(by="latitude")
)

def acronym(words):
    return words
acronym(["Geir", "Arne", "Hjelle"])
acronym(123)

def acronym(words):
    ac = ""
    for word in words:
        ac = ac + word[0]
    return ac
acronym(["Geir", "Arne", "Hjelle"])

print("hei")

(
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("end_station_latitude", "first"),
        most_common=("start_station_name", "mode"),  # Feil: mode er ikke en tilgjengelig funksjon
    )
    .sort_values(by="latitude")
)

data.mode
data.mode()

(
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("end_station_latitude", "first"),
        most_common=("start_station_name", most_common),  # Feil: har ikke definert most_common enda
    )
    .sort_values(by="latitude")
)

def most_common(noe):
    print(noe)

(
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("end_station_latitude", "first"),
        most_common=("start_station_name", most_common),
    )
    .sort_values(by="latitude")
)

def most_common(start_station_name):
    return start_station_name.iloc[0]

(
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("end_station_latitude", "first"),
        most_common=("start_station_name", most_common),
    )
    .sort_values(by="latitude")
)

name = data["start_station_name"]
name.mode()
name.mode().iloc[0]

def most_common(start_station_name):
    return start_station_name.mode().iloc[0]

(
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("end_station_latitude", "first"),
        most_common=("start_station_name", most_common),
    )
    .sort_values(by="latitude")
)

data.groupby("end_station_name", as_index=False).size().sort_values()  # Feil: trenger kolonne når as_index er False
data.groupby("end_station_name", as_index=False).size().sort_values(by="size")

#
# Slå sammen data
#
data_aug = pandas.read_csv("08.csv")
data_sep = pandas.read_csv("09.csv")

pandas.concat([data_aug, data_sep])
pandas.concat([data_aug, data_sep]).iloc[0]
pandas.concat([data_aug, data_sep]).loc[0]
pandas.concat([data_aug, data_sep]).reset_index(drop=True)

data_aug = pandas.read_csv("08.csv")
data_sep = pandas.read_csv("09.csv")
data = pandas.concat([data_aug, data_sep]).reset_index(drop=True)

end_stations = (
    data
    .groupby("end_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("end_station_latitude", "first"),
        most_common=("start_station_name", most_common),
    )
    .sort_values(by="latitude")
)

start_stations = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        most_common=("end_station_name", most_common),
    )
    .sort_values(by="latitude")
)

start_stations
start_stations.merge(end_stations)  # Gjør noe, men ikke det riktige
start_stations.merge(end_stations, left_on="start_station_name", right_on="end_station_name")
stations = start_stations.merge(end_stations, left_on="start_station_name", right_on="end_station_name")

data["start_station_name"]
data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
stations = data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
stations = (
    data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
    .drop_duplicates()
)
stations.iloc[0]

#
# Kart over bysykkelstasjoner
#
import folium
kart = folium.Map()
kart.save("kart.html")

kart = folium.Map(tiles="https://cache.kartverket.no/v1/wmts/1.0.0/topograatone/default/webmercator/{z}/{y}/{x}.png", attr="Kartverket")
kart.save("kart.html")

kart = folium.Map(
    (59.9, 10.73),
    tiles="https://cache.kartverket.no/v1/wmts/1.0.0/topograatone/default/webmercator/{z}/{y}/{x}.png",
    attr="Kartverket",
)
kart.save("kart.html")

kart = folium.Map(
    (59.9, 10.73),
    zoom_start=13,
    tiles="https://cache.kartverket.no/v1/wmts/1.0.0/topograatone/default/webmercator/{z}/{y}/{x}.png",
    attr="Kartverket",
)
kart.save("kart.html")

kart = folium.Map(
    (59.9, 10.73),
    zoom_start=13,
    tiles="https://cache.kartverket.no/v1/wmts/1.0.0/topograatone/default/webmercator/{z}/{y}/{x}.png",
    attr="Kartverket",
)
folium.Marker((59.91508, 10.730589), popup="7. juni plassen").add_to(kart)
kart.save("kart.html")

kart = folium.Map(
    (59.9, 10.73),
    zoom_start=13,
    tiles="https://cache.kartverket.no/v1/wmts/1.0.0/topograatone/default/webmercator/{z}/{y}/{x}.png",
    attr="Kartverket",
)
folium.CircleMarker((59.91508, 10.730589), popup="7. juni plassen").add_to(kart)
kart.save("kart.html")

kart = folium.Map(
    (59.9, 10.73),
    zoom_start=13,
    tiles="https://cache.kartverket.no/v1/wmts/1.0.0/topograatone/default/webmercator/{z}/{y}/{x}.png",
    attr="Kartverket",
)
folium.Circle((59.91508, 10.730589), popup="7. juni plassen").add_to(kart)
kart.save("kart.html")

kart = folium.Map(
    (59.9, 10.73),
    zoom_start=13,
    tiles="https://cache.kartverket.no/v1/wmts/1.0.0/topograatone/default/webmercator/{z}/{y}/{x}.png",
    attr="Kartverket",
)
for station in stations.itertuples():
    folium.Circle((station.start_station_latitude, station.start_station_longitude),
                  popup=station.start_station_name).add_to(kart)
kart.save("kart.html")

kart = folium.Map(
    (59.9, 10.73),
    zoom_start=13,
    tiles="https://cache.kartverket.no/v1/wmts/1.0.0/topograatone/default/webmercator/{z}/{y}/{x}.png",
    attr="Kartverket",
)
for station in stations.itertuples():
    folium.CircleMarker((station.start_station_latitude, station.start_station_longitude),
                  popup=station.start_station_name, fill=True, radius=30).add_to(kart)
kart.save("kart.html")
