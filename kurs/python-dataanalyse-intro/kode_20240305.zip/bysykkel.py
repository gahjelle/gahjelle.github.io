import pandas

# %% Les inn data

import pathlib

filnavn = sorted(pathlib.Path.cwd().glob("*.csv"))
# filnavn = ["01.csv", "02.csv"]

data_list = []
for fil in filnavn:
    print(f"Leser {fil}")
    data_list.append(pandas.read_csv(fil))

data = pandas.concat(data_list).reset_index(drop=True)

data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)

# %% Analyser data

def most_common(stations):
    return stations.mode()

def most_common_unique(stations):
    return stations.value_counts().index[0]

start_stations = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        longitude=("start_station_longitude", "first"),
        most_common_end_station=("end_station_name", most_common),
    )
)

trips = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .size()
    .pivot_table(
        index="start_station_name", 
        columns="end_station_name",
        values="size",
        fill_value=0,
    )
)

merged_on_index = start_stations.set_index("start_station_name").join(trips)
merged_on_columns = start_stations.join(
    trips.reset_index(), lsuffix="_x", rsuffix="_y"
)
merged = pandas.merge(
    start_stations,
    trips,
    left_on="start_station_name",
    right_index=True,
)
