import folium
import pandas
import math

data = pandas.read_csv("02.csv")
stasjoner = data.groupby([
    "start_station_name",
    "start_station_description",
    "start_station_longitude",
    "start_station_latitude",
], as_index=False).agg(num_trips=("duration", "size"))


kart = folium.Map((59.9, 10.75), zoom_start=12, tiles='https://tiles.stadiamaps.com/tiles/stamen_watercolor/{z}/{x}/{y}.{ext}', attribution="Stadia")

for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=f"{stasjon.start_station_description}: {stasjon.num_trips}",
        radius=math.sqrt(stasjon.num_trips),
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)

kart.save("bysykkel.html")

