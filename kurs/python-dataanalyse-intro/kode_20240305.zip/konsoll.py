#
# Introduksjon
#

1 + 2
tall = 14
tall
Tall  # Feil, det er forskjell på store og små bokstaver
print
print(tall)
tall
pandas  # Feil, pandas må først importeres
import pandas
import pakkesomikkeerinstallert  # Feil, vi kan ikke importere pakker som ikke er installert

#
# Les data fra Excel
#
pandas.read_excel
pandas.read_excel()  # Feil, read_excel() krever et filnavn
pandas.read_excel("kap1.xlsx")
pandas.read_excel("C:\User\kurs\kap1.xlsx")  # Feil, bakoverstrek (\) tolkes spesielt
pandas.read_excel(r"C:\User\kurs\kap1.xlsx")  # Bruk 'r' foran Windows-filstier

data = pandas.read_excel("kap1.xlsx")
data=pandas.read_excel("kap1.xlsx")  # Vi står ganske fritt i bruk av mellomrom
Geir Arne  # Feil, Geir Arne er ikke en Python-kommando
"Geir Arne"
'Geir Arne'  # Kan bruke enten " eller ' for å definere tekststrenger som ikke tolkes av Python
"Geir Arne'  # Feil, må bruke " eller ' på begge sider
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data.info()
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, na_values="-")

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
)

data.Budsjettiltak
data.Budsjettiltak * 3
data.Lån og garantier  # Feil, kan bare bruke .-notasjon med kolonnenavn uten mellomrom
data["Lån og garantier"]
data["Budsjettiltak"] + data["Lån og garantier"]
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    na_values="-",
    names=["land", "tiltak", "lån"],
)
data.info()

pandas.cut(data.tiltak, [0, 3, 5, 6, 9, 11])
data.assign(gruppe=pandas.cut(data.tiltak, [0, 3, 5, 6, 9, 11]))
pandas.__file__  # Kan brukes for å se hvor pandas-biblioteket er installert på datamaskinen

# PAUSE

#
# Manglende data
#
data
data.fillna(0)
data.ffill()
data.bfill()
data
budsjett = data.fillna(0)
data.lån.mean()
budsjett = data.fillna(data["lån"].mean())
budsjett
data.dropna()
data.dropna(axis="columns")

#
# Legg til nye kolonner
#
data.assign(navn=42)
data.assign(total=data["tiltak"] + data["lån"])

budsjett = (
    data
    .fillna(0)
    .assign(total=data["tiltak"] + data["lån"])
)

budsjett = data.fillna(0)
budsjett = budsjett.assign(
    total=budsjett["tiltak"] + budsjett["lån"]
)

budsjett = (
    data
    .fillna(0)
    .assign(
        total=lambda budsjett: budsjett["tiltak"] + budsjett["lån"]
    )
)

pandas.cut(budsjett["total"], [0, 10, 20])

budsjett = data.fillna(0)
budsjett = budsjett.assign(
    total=budsjett["tiltak"] + budsjett["lån"]
)
budsjett = budsjett.assign(
    gruppe=pandas.cut(budsjett["total"], [0, 5, 10, 20, 30, 40])
)

budsjett = (
    data
    .fillna(0)
    .assign(
        total=lambda rader: rader["tiltak"] + rader["lån"],
        gruppe=lambda rader: pandas.cut(rader["total"], [0, 5, 10, 20, 30, 40]),        
    )
)

budsjett.info()
budsjett[["land", "total"]]
budsjett[["land", "total", "tiltak"]]
budsjett[0]  # Feil, må bruke .loc[] for å hente rader
budsjett[["land", "total", "tiltak"]]
data.info()
data.dropna()
data.dropna().info()
data.loc[14]
data.loc[[14, 5, 8]]

data
data.set_index("land")
data.set_index("land").info()
data.set_index("land").loc["Norge"]
data.set_index("land").loc[["Norge", "Sverige", "Danmark"]]
data.query("tiltak > 5")
budsjett.query("tiltak > 5")
tiltak > 5  # Feil, tiltak er en kolonne, ikke et objekt kjent av Python
data.set_index("tiltak")
data.set_index("tiltak").loc[0.7]
budsjett.query("tiltak > 5 or lån > 5")
budsjett.query("tiltak > 5 and lån > 5")
budsjett.query("land == 'Norge'")
budsjett.query("land == "Norge"")  # Feil, kan ikke nøste flere "
budsjett
budsjett.to_excel("budsjett.xlsx")
budsjett.to_excel("budsjett.xlsx", header=["Land", "Budsjettiltak", "Lån og garantier", "Totalt", "Gruppe"])

# PAUSE
#
# https://oslobysykkel.no/apne-data/historisk
# Last ned CSV for januar og februar 2024

budsjett.plot()
budsjett.plot.bar()
budsjett.set_index("land")
budsjett.set_index("land").plot.bar()
budsjett.set_index("land").plot.barh()
budsjett.set_index("land").plot.barh(stacked=True)
budsjett.set_index("land")[["tiltak", "lån"]].plot.barh(stacked=True)
budsjett.sort_values(by="total").set_index("land")[["tiltak", "lån"]].plot.barh(stacked=True)
budsjett.sort_values(by="total").set_index("land")[["tiltak", "lån"]].plot.barh(stacked=True, title="Finanspolitiske tiltak og lån")

#
# Bysykkeldata
#

import pandas as pd
import pandas

data = pandas.read_csv("02.csv")
data.info()
data.loc[0]
data["ended_at"] - data["started_at"]  # Feil, må konvertere kolonnene til datotyper
data = pandas.read_csv(
    "02.csv",
    parse_dates=["started_at", "ended_at"],
)
data.info()
pandas.to_datetime(data["started_at"])
data.loc[1029]  # Problemer med datoformatet i denne raden
pandas.to_datetime(data["started_at"], format="ISO8601")
data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)
data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)
data.info()
data["ended_at"] - data["started_at"]

#
# Gruppering av data
#
data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("end_station_name").size().sort_values()
data.groupby("start_station_name").agg(median_duration=("duration", "median"))

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
    )
)

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
    )
)

)
(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
    )
)

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
    )
)

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        longitude=("start_station_longitude", "first")
    )
)

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        longitude=("start_station_longitude", "first"),
        most_common_end_station=("end_station_name", "mode"),
    )
)  # Feil, mode kan ikke brukes som aggregeringsfunksjon

data["end_station_name"].mode()
data["end_station_name"].value_counts()

def si_hei(navn):
    hilsen = f"Hei, {navn}!"
    print(hilsen)
si_hei("Geir Arne")
si_hei("alle sammen")

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        longitude=("start_station_longitude", "first"),
        most_common_end_station=("end_station_name", si_hei),
    )
)

def most_common(stations):
    return stations.mode()

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        longitude=("start_station_longitude", "first"),
        most_common_end_station=("end_station_name", most_common),
    )
)

def most_common_unique(stations):
    return stations.value_counts().index[0]
(

    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        longitude=("start_station_longitude", "first"),
        most_common_end_station=("end_station_name", most_common_unique),
    )
)

def most_common(stations):
    return stations.mode()

(
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        longitude=("start_station_longitude", "first"),
        most_common_end_station=("end_station_name", most_common),
    )
)

start_stations = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        longitude=("start_station_longitude", "first"),
        most_common_end_station=("end_station_name", most_common),
    )
)

data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"], as_index=False).size()
data.groupby(["start_station_name", "end_station_name"], as_index=False).size().sort_values(by="size")

trips = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .size()
)

trips.pivot_table(index="start_station_name", columns="end_station_name", values="size")

trips = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .size()
    .pivot_table(
        index="start_station_name", 
        columns="end_station_name",
        values="size",
    )
)

trips = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .size()
    .pivot_table(
        index="start_station_name", 
        columns="end_station_name",
        values="size",
        fill_value=0,
    )
)

#
# Kombiner data
#

data_jan = pandas.read_csv(
    "01.csv",
    parse_dates=["started_at", "ended_at"],
)

data_feb = pandas.read_csv(
    "02.csv",
    parse_dates=["started_at", "ended_at"],
)
pandas.concat([data_jan, data_feb])
data = pandas.concat([data_jan, data_feb])
data.info()
data.loc[0]
data = pandas.concat([data_jan, data_feb]).reset_index()
data.info()

data_jan = pandas.read_csv(
    "01.csv",
    parse_dates=["started_at", "ended_at"],
)

data_feb = pandas.read_csv(
    "02.csv",
    parse_dates=["started_at", "ended_at"],
)
data = pandas.concat([data_jan, data_feb]).reset_index()

data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)
data = pandas.concat([data_jan, data_feb]).reset_index(drop=True)
data.info()
def most_common(stations):
    return stations.mode()

def most_common_unique(stations):
    return stations.value_counts().index[0]

start_stations = (
    data
    .groupby("start_station_name", as_index=False)
    .agg(
        num_trips=("duration", "size"),  # Her er duration bare en "dummy"
        median_duration=("duration", "median"),
        min_duration=("duration", "min"),
        latitude=("start_station_latitude", "first"),
        longitude=("start_station_longitude", "first"),
        most_common_end_station=("end_station_name", most_common),
    )
)

trips = (
    data
    .groupby(["start_station_name", "end_station_name"], as_index=False)
    .size()
    .pivot_table(
        index="start_station_name", 
        columns="end_station_name",
        values="size",
        fill_value=0,
    )
)

#
# Bruk løkker til å lese mange filer
#

filnavn = ["01.csv", "02.csv"]
for fil in filnavn:
    print(f"Leser {fil}")

for fil in filnavn:
    print(f"Leser {fil}")
    data = pandas.read_csv(fil)

data_list = []
for fil in filnavn:
    print(f"Leser {fil}")
    data_list.append(pandas.read_csv(fil))

filnavn = ["01.csv", "02.csv"]
data_list = []
for fil in filnavn:
    print(f"Leser {fil}")
    data_list.append(pandas.read_csv(fil))
data = pandas.concat(data_list).reset_index(drop=True)
data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)

import pathlib
pathlib.Path.cwd()
pathlib.Path.cwd().glob("*.csv")
sorted(pathlib.Path.cwd().glob("*.csv"))

filnavn = sorted(pathlib.Path.cwd().glob("*.csv"))
data_list = []
for fil in filnavn:
    print(f"Leser {fil}")
    data_list.append(pandas.read_csv(fil))
data = pandas.concat(data_list).reset_index(drop=True)
data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)

filnavn = sorted(pathlib.Path.cwd().glob("*.csv"))
data_list = []
for fil in filnavn:
    print(f"Leser {fil}")
    data_list.append(pandas.read_csv(fil))
data = pandas.concat(data_list).reset_index(drop=True)
data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)

start_stations.set_index("start_station_name")
merged = start_stations.set_index("start_station_name").join(trips)

start_stations.join(trips.reset_index(), on="start_station_name")
start_stations.join(trips.reset_index(), lsuffix="_x", rsuffix="_y")
merged = start_stations.join(trips.reset_index(), lsuffix="_x", rsuffix="_y")

merged_on_index = start_stations.set_index("start_station_name").join(trips)
merged_on_columns = start_stations.join(
    trips.reset_index(), lsuffix="_x", rsuffix="_y"
)

pandas.merge(start_stations, trips, left_on="start_station_name", right_index=True)
merged = pandas.merge(start_stations, trips, left_on="start_station_name", right_index=True)

#
# Kart
#

import folium
folium.Map()
kart = folium.Map()
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75))
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=13)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
folium.Marker(
    location=(59.911184, 10.730035),
    tooltip="Aker Brygge 1",
    popup="mot Nasjonalmuseet bak muren ved platform G",
    icon=folium.Icon(icon="bike")
).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
folium.Marker(
    location=(59.911184, 10.730035),
    tooltip="Aker Brygge 1",
    popup="mot Nasjonalmuseet bak muren ved platform G",
    icon=folium.Icon(icon="cloud")
).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
folium.CircleMarker(
    location=(59.911184, 10.730035),
    tooltip="Aker Brygge 1",
    popup="mot Nasjonalmuseet bak muren ved platform G",
    radius=25,
    #icon=folium.Icon(icon="cloud")
).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
folium.CircleMarker(
    location=(59.911184, 10.730035),
    tooltip="Aker Brygge 1",
    popup="mot Nasjonalmuseet bak muren ved platform G",
    radius=25,
    fill=True,
    #icon=folium.Icon(icon="cloud")
).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
folium.Circle(
    location=(59.911184, 10.730035),
    tooltip="Aker Brygge 1",
    popup="mot Nasjonalmuseet bak muren ved platform G",
    radius=25,
    fill=True,
    #icon=folium.Icon(icon="cloud")
).add_to(kart)
kart.save("bysykkel.html")

import pandas

data = pandas.read_csv("02.csv")
stasjoner = data[[
    "start_station_name",
    "start_station_description",
    "start_station_longitude",
    "start_station_latitude",
]].drop_duplicates()

for stasjon in stasjoner:
    print(stasjon)

for stasjon in stasjoner.itertuples():
    print(stasjon)

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=stasjon.start_station_description,
        radius=25,
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)
kart.save("bysykkel.html")

stasjoner = data.groupby([
    "start_station_name",
    "start_station_description",
    "start_station_longitude",
    "start_station_latitude",
], as_index=False).agg(num_trips=("duration", "size"))
kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=stasjon.start_station_description,
        radius=25,
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=stasjon.start_station_description,
        radius=stasjon.num_trips,
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=stasjon.start_station_description,
        radius=math.sqrt(stasjon.num_trips),
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)
kart.save("bysykkel.html")

import math

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=stasjon.start_station_description,
        radius=math.sqrt(stasjon.num_trips),
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12) #, tiles="Stamen Watercolor")
for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=f"{stasjon.start_station_description}: {stasjon.num_trips}",
        radius=math.sqrt(stasjon.num_trips),
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12), tiles="Stadia.StamenWatercolor")
for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=f"{stasjon.start_station_description}: {stasjon.num_trips}",
        radius=math.sqrt(stasjon.num_trips),
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12, tiles="Stadia.StamenWatercolor")
for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=f"{stasjon.start_station_description}: {stasjon.num_trips}",
        radius=math.sqrt(stasjon.num_trips),
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map((59.9, 10.75), zoom_start=12, tiles='https://tiles.stadiamaps.com/tiles/stamen_watercolor/{z}/{x}/{y}.{ext}', attribution="Stadia")
for stasjon in stasjoner.itertuples():    
    folium.CircleMarker(
        location=(
            stasjon.start_station_latitude, 
            stasjon.start_station_longitude
        ),
        tooltip=stasjon.start_station_name,
        popup=f"{stasjon.start_station_description}: {stasjon.num_trips}",
        radius=math.sqrt(stasjon.num_trips),
        fill=True,
        #icon=folium.Icon(icon="cloud")
    ).add_to(kart)
kart.save("bysykkel.html")
