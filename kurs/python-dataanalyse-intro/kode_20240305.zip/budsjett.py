import pandas

# %% Les data

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,  # Tilsvarer rad 5 i Excel
    na_values="-",
    names=["land", "tiltak", "lån"],
)

# %% Analyser data

# Oppdater budsjett stegvis

budsjett = data.fillna(0)
budsjett = budsjett.assign(
    total=budsjett["tiltak"] + budsjett["lån"]
)
budsjett = budsjett.assign(
    gruppe=pandas.cut(budsjett["total"], [0, 5, 10, 20, 30, 40])
)

# Lag en kjede av kommandoer

budsjett = (
    data
    .fillna(0)
    .assign(
        total=lambda rader: rader["tiltak"] + rader["lån"],
        gruppe=lambda rader: pandas.cut(rader["total"], [0, 5, 10, 20, 30, 40]),        
    )
)

# %% Resultater

budsjett.to_excel(
    "budsjett.xlsx",
    header=["Land", "Budsjettiltak", "Lån og garantier", "Totalt", "Gruppe"],
)

(
    budsjett
    .sort_values(by="total")
    .set_index("land")[["tiltak", "lån"]]
    .plot
    .barh(
        stacked=True,
        title="Finanspolitiske tiltak og lån"
    )
)

import matplotlib.pyplot as plt
plt.show()
    
