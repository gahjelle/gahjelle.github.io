import folium
import pandas

# %% Les data
turer_aug = pandas.read_csv("08.csv")
turer_sep = pandas.read_csv("09.csv")  # , parse_dates=["started_at", "ended_at"])
turer = pandas.concat([turer_aug, turer_sep]).reset_index(drop=True)

# %% Lag stasjonsliste
stasjoner = (   
    turer[[
       "start_station_name",
       "start_station_description",
       "start_station_latitude",
       "start_station_longitude",
    ]]
    .drop_duplicates()
    .rename(
        columns={
            "start_station_name": "name",
            "start_station_description": "description",
            "start_station_latitude": "latitude",
            "start_station_longitude": "longitude",
        }
    )
)

# %% Lag kart
kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    # tiles="cartodb positron",
)
for stasjon in stasjoner.itertuples():
    folium.CircleMarker(
        location=(stasjon.latitude, stasjon.longitude),
        tooltip=stasjon.name,
        popup=stasjon.description,
        fill=True,
    ).add_to(kart)
kart.save("bysykkel.html")

# %% Ekstra markører
folium.Marker(
    location=(59.917281, 10.708376),
    tooltip="Gimle Kino",
    popup="Dette er en popup",    
).add_to(kart)
folium.CircleMarker(  # Eller Circle
    location=(59.920995, 10.750358),
    tooltip="Fredensborg",
    popup="Dette er en popup", 
    fill=True,
    radius=50,
).add_to(kart)
kart.save("bysykkel.html")
