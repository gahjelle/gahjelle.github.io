#
# Intro
#
1 + 2
1 + 3
tall = 42
tall + 3
3.14
"Geir Arne"
navn = "Geir Arne"
"Hei, navn"
f"Hei, {navn}"
pi
import math
math.pi
import pandas
pandas.__version__

#
# Les Excelfil
pandas.read_excel?   # Bruk ? for å se hjelp

pandas.read_excel("kap1.xlsx")
pandas.read_excel("kap1.xlsx", sheet_name="1.2")
budsjett = pandas.read_excel("kap1.xlsx", sheet_name="1.2")
budsjett = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
budsjett = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
)
pandas.read_excel("kap1.xlsx", "1.2")
pandas.read_excel("1.2", "kap1.xlsx")  # Feil: filnavn først
pandas.read_excel(sheet_name="1.2", "kap1.xlsx")  # Feil: Alltid posisjonelle opsjoner før navngitte
pandas.read_excel("kap1.xlsx", sheet_name="1.2")
pandas.read_excel("kap1.xlsx", header=4, sheet_name="1.2")
pandas.read_excel("../../20240305/underveis/kap1.xlsx")

pandas.read_excel(r"..\..\20240305\underveis\kap1.xlsx") # Windows filstier, r foran fnutter
pandas.read_excel("/home/gahjelle/kurs/python-intro-dataanalyse/20240305/underveis/kap1.xlsx")

budsjett["Budsjettiltak"]
budsjett["Budsjettiltak"] * 2
budsjett["Budsjettiltak"] > 3
budsjett["Lån og garantier"]
budsjett["Lån og garantier"] + 2  # Feil: Lån og garantier er tekst, ikke tall
budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],  # Nye kolonnenavn
)
budsjett["tiltak"]
budsjett.info()

#
# Håndtering av manglende verdier
budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],
    na_values="-",
)
budsjett.info()
budsjett["lån"] + 2
budsjett["lån"].sum()
budsjett.dropna()
budsjett.dropna(axis="columns")
budsjett.fillna(0)
budsjett.ffill()
budsjett.bfill()
budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],
    na_values="-",
).fillna(0)

#
# Filtrering av kolonner og rader
#
budsjett["lån"]
budsjett.loc[14]
budsjett.loc[14, "lån"]
budsjett.query("land == 'Norge'")
budsjett.query("tiltak > 4")
budsjett["tiltak"] > 4
budsjett.loc[budsjett["tiltak"] > 4]
budsjett.query("tiltak > 4")

#
# Transformering av data
#
budsjett["tiltak"] + budsjett["lån"]
budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"])
budsjett.assign(total=budsjett["tiltak"] + budsjett["lån"], tallet_en=1)
analysert = budsjett.assign(
    total=budsjett["tiltak"] + budsjett["lån"],
    tallet_en=1,
)
analysert
analysert.sort_values(by="total")
analysert.sort_values(by="total", ascending=False)
analysert.sort_values(by=["total", "land"], ascending=False)
analysert.sort_values(by=["total", "land"], ascending=[False, True])

# LUNSJPAUSE

pandas.read_excel("kap1.xlsx", sheet_name="1.2", usecols="A:B")
pandas.read_excel("kap1.xlsx", sheet_name="1.2", usecols=[0, 1])
pandas.read_excel("kap1.xlsx", sheet_name="1.2", usecols=[0, 1, 2])
budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],  # Eller "A:C"
    names=["land", "tiltak", "lån"],
    na_values="-",
).fillna(0)
analysert = (
    budsjett
    .assign(
        total=budsjett["tiltak"] + budsjett["lån"],
        tallet_en=1,
    )
    .sort_values(by=["total", "land"], ascending=[False, True])
)
analysert

#
# Indeks/radnavn
#
faktorer = pandas.DataFrame(range(19), columns=["faktor"])
faktorer
analysert["total"] * faktorer["faktor"]
analysert
analysert.reset_index()
analysert.reset_index(drop=True)
analysert = (
    budsjett
    .assign(
        total=budsjett["tiltak"] + budsjett["lån"],
        tallet_en=1,
    )
    .sort_values(by=["total", "land"], ascending=[False, True])
    .reset_index(drop=True)
)
analysert["total"] * faktorer["faktor"]

#
# Rapportering (skriv til Excel, lag plott)
#
analysert.to_excel("analysert.xlsx")
analysert.plot()
analysert.plot.bar()
analysert.plot.bar(x="land")
analysert.plot.barh(x="land")
analysert.plot.barh(x="land", stacked=True)
analysert.plot.barh(x="land", y=["tiltak", "lån"], stacked=True)

#
# Bysykkeldata - større datasett
# 

# Last ned September og August fra https://oslobysykkel.no/apne-data/historisk
# Lag en ny fil i Spyder og kall den bysykkel.py
# Start en ny konsoll!
import pandas
pandas.read_csv("09.csv")
turer = pandas.read_csv("09.csv")
turer.info()
turer.loc[0]
turer.info()

#
# Konverter datokolonner
#
turer = pandas.read_csv("09.csv", parse_dates=["started_at", "ended_at"])
turer.info()  # parse_dates gjorde ingenting, må være mer eksplisitt

pandas.to_datetime(turer["started_at"])  # Feil, må angi format
pandas.to_datetime(turer["started_at"], format="ISO8601")
turer = pandas.read_csv("09.csv")
turer = turer.assign(
    started_at=pandas.datetime(turer["started_at"], format="ISO8601"),
    ended_at=pandas.datetime(turer["ended_at"], format="ISO8601"),
)
turer.info()

# PAUSE TIL 13:15

turer
turer.loc[0]

#
# Gruppering og aggregering
#

turer.groupby("start_station_name")
turer.groupby("start_station_name").size()
turer.groupby("start_station_name", as_index=False).size()
turer.groupby("start_station_name", as_index=False).size().sort_values(by="size")
turer.groupby("end_station_name", as_index=False).size().sort_values(by="size")

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        size=("start_station_name", "size")
    )
    .sort_values(by="size")
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
    )
    .sort_values(by="size")
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
        median_duration=("duration", "median"),
    )
    .sort_values(by="size")
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
        median_duration=("duration", "median"),
        description=("start_station_description", "first")
    )
    .sort_values(by="size")
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        description=("start_station_description", "first")
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
        median_duration=("duration", "median"),
    )
    .sort_values(by="size")
)

turer["start_station_name"].mode()

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        description=("start_station_description", "first"),
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
        median_duration=("duration", "median"),
        common_end_station=("end_station_name", "mode"),
        # FEIL: "mode" kan ikke brukes som funsjon direkte
    )
    .sort_values(by="size")
)

# 
# Definer egne funksjoner
#

def si_hei():
    return "Hei"

si_hei()

def si_hei(navn):
    return f"Hei, {navn}"

si_hei("Geir Arne")
si_hei("Sverre")

def most_common(column_data):
    return column_data.mode()

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        description=("start_station_description", "first"),
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
        median_duration=("duration", "median"),
        common_end_station=("end_station_name", most_common),
    )
    .sort_values(by="size")
)

(
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        description=("start_station_description", "first"),
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
        median_duration=("duration", "median"),
        common_end_station=("end_station_name", most_common),
    )
    .sort_values(by="size")
    .reset_index(drop=True)
)

#
# Lag en stasjonstabell
#
turer["start_station_name"]
turer[["start_station_name"]]
turer[["start_station_name", "start_station_latitude", "start_station_longitude"]]
(   
    turer[[
       "start_station_name",
       "start_station_latitude",
       "start_station_longitude",
    ]].drop_duplicates()
)
(   
    turer[[
       "start_station_name",
       "start_station_latitude",
       "start_station_longitude",
    ]]
    .drop_duplicates()
    .rename(
        columns={
            "start_station_name": "name",
            "start_station_latitude": "latitude",
            "start_station_longtiude": "longitude",
        }
    )
)

stasjoner = (   
    turer[[
       "start_station_name",
       "start_station_latitude",
       "start_station_longitude",
    ]]
    .drop_duplicates()
    .rename(
        columns={
            "start_station_name": "name",
            "start_station_latitude": "latitude",
            "start_station_longitude": "longitude",
        }
    )
)
stasjoner

start_statistikk = (
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        description=("start_station_description", "first"),
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
        median_duration=("duration", "median"),
        common_end_station=("end_station_name", most_common),
    )
    .sort_values(by="size")
    .reset_index(drop=True)
)
start_statistikk
start_statistikk.info()
stasjoner.info()

#
# Slå sammen tabeller (tilsvarende database-join)
#
start_statistikk.merge(stasjoner)  # FEIL: Må angi hvilke kolonner som skal matches
start_statistikk.merge(stasjoner, left_on="start_station_name", right_on="name")

start_statistikk.merge(stasjoner, left_on="start_station_name", right_on="name", validate="one_to_one")  # FEIL: har duplikater i stasjonstabellen
stasjoner["name"].value_counts().sort_values()  # Finner 3 tilfeller av 7. juni plassen

start_statistikk.merge(stasjoner, left_on="start_station_name", right_on="name")
start_statistikk.merge(stasjoner, left_on="start_station_name", right_on="name", how="left")
start_statistikk.merge(stasjoner, left_on="start_station_name", right_on="name", how="right")
start_statistikk.merge(stasjoner, left_on="start_station_name", right_on="name", how="outer")
start_statistikk.merge(stasjoner, left_on="start_station_name", right_on="name", how="inner")

start_statistikk.merge(stasjoner, left_on="start_station_name", right_on="name", how="inner").info()

#
# Slå sammen tabeller (legg dem under hverandre)
#
turer_sep = pandas.read_csv("09.csv")
turer_aug = pandas.read_csv("08.csv")
pandas.concat([turer_aug, turer_sep])

turer_aug = pandas.read_csv("08.csv")
turer_sep = pandas.read_csv("09.csv")
turer = pandas.concat([turer_aug, turer_sep]).reset_index(drop=True)
turer = turer.assign(
    started_at=pandas.to_datetime(turer["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(turer["ended_at"], format="ISO8601"),
)

# Oppdater analyse med aug+sep
start_statistikk = (
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        description=("start_station_description", "first"),
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
        median_duration=("duration", "median"),
        common_end_station=("end_station_name", most_common),
    )
    .sort_values(by="size")
    .reset_index(drop=True)
)

stasjoner = (   
    turer[[
       "start_station_name",
       "start_station_latitude",
       "start_station_longitude",
    ]]
    .drop_duplicates()
    .rename(
        columns={
            "start_station_name": "name",
            "start_station_latitude": "latitude",
            "start_station_longitude": "longitude",
        }
    )
)
start_statistikk

#
# Nettkart
#
import folium
kart = folium.Map()
kart.save("bysykkel.html")

stasjoner.loc[0]
kart = folium.Map(location=(59.9, 10.7))
kart.save("bysykkel.html")

kart = folium.Map(location=(59.9, 10.7), zoom_start=12)
kart.save("bysykkel.html")

kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    tiles="cartodb positron"
)
kart.save("bysykkel.html")

stasjoner.loc[0]
kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    tiles="cartodb positron",
)
folium.Marker(
    location=(59.917281, 10.708376),
    tooltip="Gimle Kino",
    popup="Dette er en popup",    
).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    # tiles="cartodb positron",
)
folium.Marker(
    location=(59.917281, 10.708376),
    tooltip="Gimle Kino",
    popup="Dette er en popup",    
).add_to(kart)
kart.save("bysykkel.html")

stasjoner.loc[1]
kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    # tiles="cartodb positron",
)
folium.Marker(
    location=(59.917281, 10.708376),
    tooltip="Gimle Kino",
    popup="Dette er en popup",    
).add_to(kart)
folium.CircleMarker(
    location=(59.920995, 10.750358),
    tooltip="Fredensborg",
    popup="Dette er en popup",    
).add_to(kart)
kart.save("bysykkel.html")

# Legg på fyll og større radius på sirkelmarkøren
kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    # tiles="cartodb positron",
)
folium.Marker(
    location=(59.917281, 10.708376),
    tooltip="Gimle Kino",
    popup="Dette er en popup",    
).add_to(kart)
folium.CircleMarker(
    location=(59.920995, 10.750358),
    tooltip="Fredensborg",
    popup="Dette er en popup", 
    fill=True,
    radius=50,
).add_to(kart)
kart.save("bysykkel.html")

# Sammenlign sirkelmarkør og sirkel
kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    # tiles="cartodb positron",
)
folium.Marker(
    location=(59.917281, 10.708376),
    tooltip="Gimle Kino",
    popup="Dette er en popup",    
).add_to(kart)
folium.Circle(
    location=(59.920995, 10.750358),
    tooltip="Fredensborg",
    popup="Dette er en popup", 
    fill=True,
    radius=50,
).add_to(kart)
kart.save("bysykkel.html")

#
# Legg på alle stasjoner
#
turer_aug = pandas.read_csv("08.csv")
turer_sep = pandas.read_csv("09.csv")
turer = pandas.concat([turer_aug, turer_sep]).reset_index(drop=True)

stasjoner = (   
    turer[[
       "start_station_name",
       "start_station_latitude",
       "start_station_longitude",
    ]]
    .drop_duplicates()
    .rename(
        columns={
            "start_station_name": "name",
            "start_station_latitude": "latitude",
            "start_station_longitude": "longitude",
        }
    )
)

for stasjon in stasjoner.itertuples():
    print(stasjon)

kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    # tiles="cartodb positron",
)
for stasjon in stasjoner.itertuples():
    folium.CircleMarker(
        location=(stasjon.latitude, stasjon.longitude),
        tooltip=stasjon.name,
    ).add_to(kart)
kart.save("bysykkel.html")

kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    # tiles="cartodb positron",
)
for stasjon in stasjoner.itertuples():
    folium.CircleMarker(
        location=(stasjon.latitude, stasjon.longitude),
        tooltip=stasjon.name,
        popup="Mer info",
        fill=True,
    ).add_to(kart)
kart.save("bysykkel.html")

# Inkluder description i popup
stasjoner = (   
    turer[[
       "start_station_name",
       "start_station_description",
       "start_station_latitude",
       "start_station_longitude",
    ]]
    .drop_duplicates()
    .rename(
        columns={
            "start_station_name": "name",
            "start_station_description": "description",
            "start_station_latitude": "latitude",
            "start_station_longitude": "longitude",
        }
    )
)

kart = folium.Map(
    location=(59.9, 10.7),
    zoom_start=12,
    # tiles="cartodb positron",
)
for stasjon in stasjoner.itertuples():
    folium.CircleMarker(
        location=(stasjon.latitude, stasjon.longitude),
        tooltip=stasjon.name,
        popup=stasjon.description,
        fill=True,
    ).add_to(kart)
kart.save("bysykkel.html")
