import pandas

turer_aug = pandas.read_csv("08.csv")
turer_sep = pandas.read_csv("09.csv")  # , parse_dates=["started_at", "ended_at"])
turer = pandas.concat([turer_aug, turer_sep]).reset_index(drop=True)

turer = turer.assign(
    started_at=pandas.to_datetime(turer["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(turer["ended_at"], format="ISO8601"),
)

def most_common(column_data):
    return column_data.mode()
    

start_statistikk = (
    turer
    .groupby("start_station_name", as_index=False)
    .agg(
        description=("start_station_description", "first"),
        size=("start_station_name", "size"),
        max_duration=("duration", "max"),
        median_duration=("duration", "median"),
        common_end_station=("end_station_name", most_common),
    )
    .sort_values(by="size")
    .reset_index(drop=True)
)

stasjoner = (   
    turer[[
       "start_station_name",
       "start_station_latitude",
       "start_station_longitude",
    ]]
    .drop_duplicates()
    .rename(
        columns={
            "start_station_name": "name",
            "start_station_latitude": "latitude",
            "start_station_longitude": "longitude",
        }
    )
)