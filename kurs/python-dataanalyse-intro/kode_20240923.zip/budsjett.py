import pandas

budsjett = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],  # Eller "A:C"
    names=["land", "tiltak", "lån"],
    na_values="-",
).fillna(0)

analysert = (
    budsjett
    .assign(
        total=budsjett["tiltak"] + budsjett["lån"],
        tallet_en=1,
    )
    .sort_values(by=["total", "land"], ascending=[False, True])
    .reset_index(drop=True)
)

analysert.to_excel("analysert.xlsx")
