import pandas

# Les data fra Excel
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],
    na_values="-",
)

data["lån"] + data["tiltak"]

data.query("tiltak > 4 or lån < 10")
data.loc[(data["tiltak"] > 4) | (data["lån"] < 10)]

# Analyser data
budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .rename(columns={
        "lån": "Lån og garantier",
        "tiltak": "Budsjettiltak"
    })
)

# Skriv data til Excel
budsjett.to_excel("analyserte_data.xlsx")

# Lag plott
(
    budsjett
    .sort_values(by="total")
    .plot
    .barh(
        x="land",
        y=["Budsjettiltak", "Lån og garantier"],
        stacked=True,
    )
)
