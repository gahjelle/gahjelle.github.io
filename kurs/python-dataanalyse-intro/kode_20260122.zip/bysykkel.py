# Last ned CSV for Januar 2026, flytt 01.csv inn i kurskatalogen
# Lag en ny fil, lagre den som bysykkel.py
# Velg i menyen Consoles > New console

import pandas

# Les inn CSV-fila 01.csv

# Fra norsk Excel må vi angi semikolon og komma
# data = pandas.read_csv("01.csv", sep=";", decimal=",")

data = pandas.read_csv("01.csv") # , parse_dates=["started_at", "ended_at"])
data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)

data.groupby("start_station_name").size().sort_values()

# DataFrame med turstatistikk gruppert på stasjon
station_stats = data.groupby("start_station_name", as_index=False).agg(
    num_trips=("duration", "count"),
    mean_duration=("duration", "mean"),  # pandas.col("duration").mean()  ?? 3.0
    max_duration=("duration", "max"),
)

# DataFrame med stasjonsinformasjon
locations = (
    data[
        ["start_station_name", "start_station_latitude", "start_station_longitude"]
    ]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",     
        "start_station_longitude": "lon",
    })
)

locations.merge(station_stats, left_on="name", right_on="start_station_name")
