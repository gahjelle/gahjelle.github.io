# Lag en ny fil, lagre den som kart.py
# Kopier inn kode fra bysykkel.py
# Lag et nytt konsoll i menyen: Consoles > New Console

import folium
import pandas

data = pandas.read_csv("01.csv")

# DataFrame med stasjonsinformasjon
locations = (
    data[
        ["start_station_name", "start_station_latitude", "start_station_longitude"]
    ]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",     
        "start_station_longitude": "lon",
    })
)

kart = folium.Map((59.9, 10.75), zoom_start=12)
for station in locations.itertuples():
    folium.CircleMarker(
        location=(station.lat, station.lon),
        tooltip=station.name,
        popup="Du klikket på meg!",
        fill=True,
    ).add_to(kart)

kart.save("kart.html")
