#
# Introduksjon: variabler
#
1 + 2
tall = 22
kurs_i_python = "Nå"
kurs i python = "Nå"  # Feil: variabelnavn kan ikke inneholde mellomrom
tall
Tall  # Feil: store og små bokstaver er viktig
navn = "Geir Arne"
navn = Geir Arne  # Feil: Tekstdata må skrives i fnutter
navn = Mari  # Feil: Tekstdata må skrives i fnutter
pi = 3.14
1.3 + 4
pi * tall**2

import math
math
math.pi
math.pi * tall**2

math.cos
funk = math.cos
tall_2 = tall + 2
math.cos(pi)
resultat = math.cos(pi)
math.cos(math.pi)

1/3
1/3 + 1/3 + 1/3

2 + 3 == 5
2 + 3 == 4

# Eksempelet jeg egentlig ville vise her er:
0.1 + 0.1 + 0.1
0.1 + 0.1 + 0.1 == 0.3  # False, pga unøyaktigheter i representasjonen av 0.1

#
# Les en Excelfil
#
import pandas
pandas.read_excel
pandas.read_excel()  # Feil: trenger et filnavn
pandas.read_excel("kap1.xlsx")
data = pandas.read_excel("kap1.xlsx")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2")
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4)

# Pause til 10:24

data
data.info()
data["Budsjettiltak"]
data["Budsjettiltak"] + 100
data["Budsjettiltak"] * 6 + 100
data["Budsjettiltak"] * 6 + 100 * 3
data["Budsjettiltak"] * (6 + 100) * 3
score = data["Budsjettiltak"] * 6 + 100 * 3
data.assign(score = data["Budsjettiltak"] * 6 + 100 * 3)
data_med_score = data.assign(score = data["Budsjettiltak"] * 6 + 100 * 3)

data["Lån og garantier"]
data["Lån og garantier"] + data["Budsjettiltak"]  # Feil: Kolonnene har forskjellige datatyper
data.info()
[22, 1, 26]
flere_tall = [22, 1, 26]

data = pandas.read_excel("kap1.xlsx", sheet_name="1.2", header=4, names=["land", "tiltak", "lån"])

data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],
)

data.info()
data["Lån og garantier"]  # Feil: feil kolonnenavn
data["lån"]
data.info()

#
# Håndtering av manglende verdier
#
data = pandas.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    names=["land", "tiltak", "lån"],
    na_values="-",
)

data.info()
data["lån"] + data["tiltak"]
data.assign(total=data["lån"] + data["tiltak"])
data.assign(total=data["lån"] + data["tiltak"]).mean()
data.assign(total=data["lån"] + data["tiltak"]).describe()
data

data.fillna(0)
data.fillna(123)
data.dropna()
data.dropna(axis="columns")
data.ffill()
data.bfill()
data.interpolate()

#
# Hent ut og filtrer data
#
data
data["tiltak"]
data[["tiltak", "land"]]  # Flere kolonner angis i en liste
data.query("tiltak > 4")
data.query(tiltak > 4)
data.query("tiltak > 4 and lån < 10")
data.query("tiltak > 4")
data.query("tiltak > 4 or lån < 10")
data["tiltak"]
data["tiltak"] > 4
data.loc[data["tiltak"] > 4]
data.query("tiltak > 4")
data.loc[(data["tiltak"] > 4) | (data["lån"] < 10)]

# Lunsj til 12:02

#
# Et lite sidespor for å teste innlesing av Sindres datafil
#
pandas.read_table("eksempel_1.asc")
pandas.read_table?
pandas.read_table("eksempel_1.asc", header=16)
pandas.read_table("eksempel_1.asc", header=12)
pandas.read_table("eksempel_1.asc", header=10)
pandas.read_table("eksempel_1.asc", header=9)
pandas.read_table("eksempel_1.asc", header=9, sep=",")
pandas.read_table("eksempel_1.asc", header=9, sep=",").info()
pandas.read_table("eksempel_1.asc", header=[9,10], sep=",").info()
pandas.read_table("eksempel_1.asc", header=[9,10], sep=",")
pandas.read_table("eksempel_1.asc")
pandas.read_table("eksempel_1.asc", header=16, sep=",")
eksempel = pandas.read_table("eksempel_1.asc", sep=",")
eksempel = pandas.read_table("eksempel_1.asc")
eksempel = pandas.read_table("eksempel_1.asc", header=8, sep=",")
eksempel = pandas.read_table("eksempel_1.asc", header=9, sep=",")
eksempel.info()
eksempel = pandas.read_table("eksempel_1.asc", header=9, sep=",", skiprows=[10])
eksempel = pandas.read_table("eksempel_1.asc", header=9, sep=",", skiprows=0)
eksempel = pandas.read_table("eksempel_1.asc", header=[9, 10], sep=",")
eksempel.rename(columns={"før": "etter"})
eksempel.columns
eksempel.rename(columns={(         '          Time',          '           [s]'): "time"})
eksempel.rename(columns={(         '          Time',          '           [s]'): ("time", "")})
eksempel = pandas.read_table("eksempel_1.asc", header=[9, 10], sep=",", names=["time"])
eksempel = pandas.read_table("eksempel_1.asc", header=10, sep=",", names=["time"])
eksempel
eksempel = pandas.read_table("eksempel_1.asc", header=10, sep=",", names=["time", "asda", "asdasd"])
eksempel

pandas.read_table("eksempel_1.asc", header=9, sep=",", skiprows=[17])
pandas.read_table("eksempel_1.asc", header=9, sep=",", skiprows=[17], usecols=[0, 7])
pandas.read_table("eksempel_1.asc", header=9, sep=",", skiprows=[17], usecols=[0, 7], names=["time", "drag"])
pandas.read_table("eksempel_1.asc", header=9, sep=",", skiprows=[17], usecols=[0, 7], names=["time", "drag"]).plot.scatter(x="time", y="drag")
pandas.read_table("eksempel_1.asc", header=9, sep=",", skiprows=[17], usecols=[0, 7], names=["time", "drag"]).plot.line(x="time", y="drag")
pandas.read_table("eksempel_1.asc", header=9, sep=",", skiprows=[17], usecols=[0, 7], names=["time", "drag"])
pandas.read_table("eksempel_1.asc", header=9, sep=",", skiprows=[17], usecols=[0, 7], names=["time", "drag"]).plot.line(x="time", y="drag")

#
# Omnavning og transformasjon av kolonner
#
data
data.rename(columns={"lån": "garantier"})
data.rename(columns={"lån": "Lån og garantier"})
data.rename(columns={"lån": "Lån og garantier", "tiltak": "Budsjettiltak"})
data.assign(total=data["tiltak"] + data["lån"])
budsjett = data.assign(total=data["tiltak"] + data["lån"])
budsjett.rename(columns={
    "lån": "Lån og garantier",
    "tiltak": "Budsjettiltak"
}
)

# 
# Eksporter data
#
budsjett.to_markdown()
print(budsjett.to_markdown())
budsjett = data.assign(total=data["tiltak"] + data["lån"]).rename(columns={
    "lån": "Lån og garantier",
    "tiltak": "Budsjettiltak"
}
)
budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .rename(columns={
        "lån": "Lån og garantier",
        "tiltak": "Budsjettiltak"
    }
)
budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .rename(columns={
        "lån": "Lån og garantier",
        "tiltak": "Budsjettiltak"
    })
)
print(budsjett.to_markdown())
budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .rename(columns={
        "lån": "Lån og garantier",
        "tiltak": "Budsjettiltak"
    })
    .to_excel("analyserte_data.xlsx")
)
budsjett = (
    data
    .assign(total=data["tiltak"] + data["lån"])
    .rename(columns={
        "lån": "Lån og garantier",
        "tiltak": "Budsjettiltak"
    })
)
budsjett.to_excel("analyserte_data.xlsx")

#
# Tegn grafer og figurer
#
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.bar(x="land")
budsjett.plot.barh(x="land")
budsjett.plot.barh(x="land",stacked=True)
budsjett.sort_values(by="total")
budsjett.sort_values(by="total").plot.barh(x="land",stacked=True)
budsjett.sort_values(by="total").plot.barh(x="land", y=["Budsjettiltak", "Lån og garantier"], stacked=True)
budsjett.sort_values(by="total").plot.barh(x="land", y=["Budsjettiltak", "Lån og garantier"], stacked=True, title="Pandemirespons")

# Pause til 13:27

#
# Større datasett: bysykkeldata
#
import pandas

# Les inn CSV-fila 01.csv
data = pandas.read_csv("01.csv")
data.info()
data = pandas.read_csv("01.csv", parse_dates=["started_at", "ended_at"])

data.info()
data["started_at"]
pandas.to_datetime(data["started_at"])  # Feil: datoene er ikke konsistent formattert
pandas.to_datetime(data["started_at"], format="ISO8601")
data = data.assign(started_at=pandas.to_datetime(data["started_at"], format="ISO8601"))

data = pandas.read_csv("01.csv") # , parse_dates=["started_at", "ended_at"])
data = data.assign(
    started_at=pandas.to_datetime(data["started_at"], format="ISO8601"),
    ended_at=pandas.to_datetime(data["ended_at"], format="ISO8601"),
)
data.info()

data["ended_at"] - data["started_at"]

data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby("start_station_name").agg(mean_duration=("duration", "mean"))
data.groupby("start_station_name").agg(
    mean_duration=("duration", "mean"),
    max_duration=("duration", "max"),
)
station_stats = data.groupby("start_station_name").agg(
    mean_duration=("duration", "mean"),  # pandas.col("duration").mean()  ?? 3.0
    max_duration=("duration", "max"),
)
station_stats = data.groupby("start_station_name").agg(
    num_trips=("duration", "count"),
    mean_duration=("duration", "mean"),  # pandas.col("duration").mean()  ?? 3.0
    max_duration=("duration", "max"),
)
data.groupby("start_station_name").agg(
    num_trips=("duration", "count"),
    mean_duration=("duration", "mean"),  # pandas.col("duration").mean()  ?? 3.0
    max_duration=("duration", "max"),
)
data.info()
station_stats.info()
data.groupby("start_station_name", as_index=False).agg(
    num_trips=("duration", "count"),
    mean_duration=("duration", "mean"),  # pandas.col("duration").mean()  ?? 3.0
    max_duration=("duration", "max"),
)
# Pause til 14:50
data
data_des = data  # Dummy: Last ned desemberdata og les med pandas.read_csv()
data_jan = data
pandas.concat([data_des, data_jan])

#
# Lag et stasjonsdatasett med informasjon om posisjoner
#
data[["start_station_name", "start_station_latitude", "start_station_longitude"]]
data[["start_station_name", "start_station_latitude", "start_station_longitude"]].drop_duplicates()
locations = (
    data[
        ["start_station_name", "start_station_latitude", "start_station_longitude"]
    ]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",     
        "start_station_longitude": "lon",
    })
)

data["duration"]
data.__getitem__("duration")  # Under panseret kaller Python .__getitem__() når vi skriver []

station_stats = data.groupby("start_station_name", as_index=False).agg(
    num_trips=("duration", "count"),
    mean_duration=("duration", "mean"),  # pandas.col("duration").mean()  ?? 3.0
    max_duration=("duration", "max"),
)

#
# Slå sammen to tabeller
#
locations.merge(station_stats)  # Feil: Må angi hvilke kolonner som skal matche
locations.merge(station_stats, left_on="name", right_on="start_station_name")
merged = locations.merge(station_stats, left_on="name", right_on="start_station_name")
locations.merge(station_stats, left_on="name", right_on="start_station_name").drop(columns="start_station_name")
merged = locations.merge(station_stats, left_on="name", right_on="start_station_name", how="inner")
import pandas

data = pandas.read_csv("01.csv")

#
# DataFrame med stasjonsinformasjon
#
locations = (
    data[
        ["start_station_name", "start_station_latitude", "start_station_longitude"]
    ]
    .drop_duplicates()
    .rename(columns={
        "start_station_name": "name",
        "start_station_latitude": "lat",     
        "start_station_longitude": "lon",
    })
)

#
# Lag kart over bysykkelstasjoner
#
import folium

kart = folium.Map()
kart.save("kart.html")

locations.loc[0]
kart = folium.Map((59.9, 10.75))
kart.save("kart.html")

kart = folium.Map((59.9, 10.75), zoom_start=12)
kart.save("kart.html")

kart = folium.Map((59.9, 10.75), zoom_start=12)
folium.Marker(
    location=(59.920728, 10.759486),
    tooltip="Schous plass trikkestopp",
).add_to(kart)
kart.save("kart.html")

kart = folium.Map((59.9, 10.75), zoom_start=12)
folium.Marker(
    location=(59.920728, 10.759486),
    tooltip="Schous plass trikkestopp",
    popup="Du klikket på meg!",
).add_to(kart)
kart.save("kart.html")

for tall in [1, 3, 5]:
    print(tall * 3)
for tall in range(100):
    print(tall * 3)

for station in locations.itertuples():
    print(station)

kart = folium.Map((59.9, 10.75), zoom_start=12)
for station in locations.itertuples():
    folium.Marker(
        location=(59.920728, 10.759486),
        tooltip="Schous plass trikkestopp",
        popup="Du klikket på meg!",
    ).add_to(kart)
kart.save("kart.html")

kart = folium.Map((59.9, 10.75), zoom_start=12)
for station in locations.itertuples():
    folium.Marker(
        location=(station.lat, station.lon),
        tooltip=station.name,
        popup="Du klikket på meg!",
    ).add_to(kart)
kart.save("kart.html")

kart = folium.Map((59.9, 10.75), zoom_start=12)
for station in locations.itertuples():
    folium.CircleMarker(
        location=(station.lat, station.lon),
        tooltip=station.name,
        popup="Du klikket på meg!",
    ).add_to(kart)
kart.save("kart.html")

kart = folium.Map((59.9, 10.75), zoom_start=12)
for station in locations.itertuples():
    folium.CircleMarker(
        location=(station.lat, station.lon),
        tooltip=station.name,
        popup="Du klikket på meg!",
        fill=True,
    ).add_to(kart)
kart.save("kart.html")

#
# API-kall
#
import requests
requests.get("https://data.urbansharing.com/oslobysykkel.no/trips/v1/2026/01.csv")
requests.get("https://data.urbansharing.com/oslobysykkel.no/trips/v1/2026/01.csv").text

pandas.read_csv("https://data.urbansharing.com/oslobysykkel.no/trips/v1/2026/01.csv")
