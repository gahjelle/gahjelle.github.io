import folium
import pandas as pd

filer = ["07.csv", "08.csv"]
data_ark = []
for fil in filer:
    ark = pd.read_csv(fil, parse_dates=["started_at", "ended_at"])
    data_ark.append(ark)
data = pd.concat(data_ark).reset_index(drop=True)

stasjoner = data.loc[:, [
    "start_station_name",
    "start_station_latitude",
    "start_station_longitude"]
   ].drop_duplicates()


kart = folium.Map(location=[59.9, 10.75], zoom_start=12)
for id, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=[stasjon.start_station_latitude, stasjon.start_station_longitude],
        popup=stasjon.start_station_name,
        fill=True
    ).add_to(kart)
kart.save("bysykkelkart.html")
