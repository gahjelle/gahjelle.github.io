#
# Intro
#
1 + 2
print
print("Hei alle sammen!")
navn = "Geir Arne"
print(f"Hei {navn}")
navn = "verden"
print(f"Hei {navn}")

# Mellomrom er *som regel* ikke viktig
3*4
3 * 4
navn = "verden"
navn="verden"
print(f"Hei {navn}")

#
# pandas er et Pythonbibliotek for dataanalyse
#
import pandas as pd  # Vanlig konvensjon er å omnavne pandas til pd
import panda  # FEIL: navnet er feilstavet
import pandas
pandas.read_excel
pd.read_excel
import pandas as pannekake  # Kan i teorien omnavne til hva som helst
pannekake.read_excel
print
skriv_ut = print  # Kan også "oversette" kommandoer
skriv_ut("Hei")
name = "Geir Arne"
blåbærsyltetøy = 1  # Norske tegn kan brukes i variabelnavn
pd.read_excel("kap1.xlsx")
pd.read_excel("kap2.xlsx")  # FEIL: filnavnet er feil
pd.read_excel("C:/Users/giron/kurs/kap1.xlsx")  # Kan bruke fullstendig filsti
pd.read_excel("C:\Users\giron\kurs\kap1.xlsx")  # FEIL: \ tolkes spesielt
pd.read_excel(r"C:\Users\giron\kurs\kap1.xlsx")  # Bruk r"" for å unngå spesialtolkning
data = pd.read_excel("kap1.xlsx")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=5)
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols="A:C")
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols=[0, 1, 2])
data = pd.read_excel("kap1.xlsx", sheet_name="1.2", header=4, usecols=[0, 1, 2], index_col=0)

data.info()
data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],
    index_col=0,
    na_values="-"
)

data.head()

data.loc["Norge"]
data.loc["Noge"]  # FEIL: feil navn på kolonne
data.Budsjettiltak
data.info()
data.Lån og garantier  # FEIL: kan ikke bruke . for kolonnenavn med mellomrom
data.loc[:, "Lån og garantier"]
data.loc["Norge", "Lån og garantier"]

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],
    index_col=0,
    na_values="-",
).rename(columns={"Budsjettiltak": "tiltak"})

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],
    index_col=0,
    na_values="-",
).rename(columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"})

data.lån
data.lån + 2
data.lån * 3
data.lån + data.tiltak
data.info()
data.tiltak + data.lån
data.assign(totalt=data.tiltak + data.lån)
data = data.assign(totalt=data.tiltak + data.lån)

# Pause til 10:40
Print  # FEIL: Store og små bokstaver er viktig
budsjett = data.assign(totalt=data.tiltak + data.lån).sort_values(by="totalt")

budsjett = (
           data
           .assign(totalt=data.tiltak + data.lån)
           .sort_values(by="totalt")
)

#
# Håndter manglende data
#
budsjett = (
           data
           .assign(totalt=data.tiltak + data.lån)
           .sort_values(by="totalt")
           .dropna()
)

budsjett = (
           data
           .assign(totalt=data.tiltak + data.lån)
           .sort_values(by="totalt")
           .dropna(how="all")
)

budsjett = (
           data
           .assign(totalt=data.tiltak + data.lån)
           .sort_values(by="totalt")
           .fillna(0)
)

budsjett = (
           data
           .fillna(0)
           .assign(totalt=data.tiltak + data.lån)
           .sort_values(by="totalt")
)

budsjett = (
           data
           .fillna(0)
           .assign(totalt=data.tiltak + data.filna(0).lån)
           .sort_values(by="totalt")
)

budsjett = (
           data
           .fillna(0)
           .assign(totalt=data.tiltak + data.fillna(0).lån)
           .sort_values(by="totalt")
)

budsjett = (
           data
           .fillna(0)
           .assign(totalt=lambda d: d.tiltak + d.lån)  # lambda gir tilgang på dataframe'n akkurat "nå"
           .sort_values(by="totalt")
)

data = pd.read_excel(
    "kap1.xlsx",
    sheet_name="1.2",
    header=4,
    usecols=[0, 1, 2],
    index_col=0,
    na_values="-",
).rename(
    columns={"Budsjettiltak": "tiltak", "Lån og garantier": "lån"}
).fillna(0)
budsjett = (
           data
           .assign(totalt=data.tiltak + data.lån)
           .sort_values(by="totalt")
)

#
# Slå sammen data
#
norden = ["Norge", "Sverige", "Danmark", "Finland", "Island"]
data.index
data.index.isin(norden)

budsjett = (
           data
           .assign(
               totalt=data.tiltak + data.lån,
               i_norden=data.index.isin(norden),
            )
           .sort_values(by="totalt", ascending=False)
)
print(budsjett)

#
# Skriv data tilbake til Excel
#
budsjett.to_excel("budsjett.xlsx")
budsjett.rename(
    columns={"tiltak": "Budsjettiltak", "lån": "Lån og garantier"}
).to_excel("budsjett.xlsx")

#
# Spørringer
#
budsjett.query("tiltak > 8")
budsjett.query("totalt < 8")
budsjett.query("totalt < 8 and tiltak > 2")
budsjett.query("i_norden")
budsjett.query("i_norden").to_excel("norden.xlsx")
budsjett.query("i_norden").drop(columns=["i_norden"])
budsjett.query("i_norden").drop(columns=["i_norden"]).to_excel("norden.xlsx")

#
# Figurer
#
budsjett.plot()
budsjett.plot.bar()
budsjett.plot.barh()
budsjett.plot.barh(stacked=True)
budsjett.loc[:, "tiltak"].plot.barh(stacked=True)
budsjett.loc[:, ["tiltak", "lån"]].plot.barh(stacked=True)


#
# BYSYKLER
#
data = pd.read_csv("08.csv")
data.info()
data
data.head()
data.head(1)
data.head(1).T  # Vis første rad, med kolonner som rader


#
# Håndter datoer som egen datatype
#
data = pd.read_csv("08.csv", parse_dates=["started_at", "ended_at"])
data.info()
data.duration
data.duration.plot()
data.set_index("started_at")
data.set_index("started_at").plot()
data.set_index("started_at").duration.plot()
data.set_index("started_at").loc["2021-08-25"]

# Grupper data
data.groupby("start_station_name")
data.groupby("start_station_name").size()
data.groupby("start_station_name").size().sort_values()
data.groupby(["start_station_name", "end_station_name"]).size()
data.groupby(["start_station_name", "end_station_name"]).size().sort_values()

antall_turer.start_station_name  # FEIL: start_station_name er index ikke kolonne
antall_turer
antall_turer.loc[("Sukkerbiten", "Kværnerbyen")]
antall_turer.reset_index()

antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
)

antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
)

antall_turer.pivot_table(index="start_station_name", columns="end_station_name", values="num_trips")

antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
    .pivot_table(
        index="start_station_name",
        columns="end_station_name",
        values="num_trips",
    )
)

antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
    .pivot_table(
        index="start_station_name",
        columns="end_station_name",
        values="num_trips",
        fill_value=0,
    )
)

# Pause til 12:15

# 
# Statistikk om kolonnene
#
data.describe()
data.duration.mean()
data.duration.median()
data.duration.std()
data.std()
data.describe()

#
# Kombiner flere filer
#
data_jul = pd.read_csv("07.csv", parse_dates=["started_at", "ended_at"])
data_aug = pd.read_csv("08.csv", parse_dates=["started_at", "ended_at"])
pd.concat([data_jul, data_aug])
data = pd.concat([data_jul, data_aug])
data.tail()
data = pd.concat([data_jul, data_aug]).reset_index(drop=True)
data

filer = ["07.csv", "08.csv"]
data_ark = []
for fil in filer:
    ark = pd.read_csv(fil, parse_dates=["started_at", "ended_at"])
    data_ark.append(ark)
data = pd.concat(data_ark).reset_index(drop=True)

for fil in filer:
ark = pd.read_csv(fil, parse_dates=["started_at", "ended_at"])  # FEIL: Innrykk er viktig i løkker

#
# Datotype
#
data.info()
data.ended_at - data.start_at
data.ended_at - data.started_at
data.duration


#
# NETTKART
#
kart = folium.Map()
kart.save("bysykkelkart.html")

kart = folium.Map(location=[59.9, 10.75], zoom_start=11)
kart.save("bysykkelkart.html")

kart = folium.Map(location=[59.9, 10.75], zoom_start=12)
kart.save("bysykkelkart.html")

data.loc[0].T
kart = folium.Map(location=[59.9, 10.75], zoom_start=12)
folium.CircleMarker(location=[59.919111, 10.736179]).add_to(kart)
kart.save("bysykkelkart.html")

kart = folium.Map(location=[59.9, 10.75], zoom_start=12)
folium.CircleMarker(
    location=[59.919111, 10.736179],
    popup="Edvard Storms Gate",
    fill=True
).add_to(kart)
kart.save("bysykkelkart.html")

stasjoner = data.loc[:, [
    "start_station_name",
    "start_station_latitude",
    "start_station_longitude"]
   ].drop_duplicates()

for stasjon in stasjoner:  # Lager løkke over kolonner
    print(stasjon)
    
for stasjon in stasjoner.iterrows():  # Lager løkke over rader, både index og innhold
    print(stasjon)
    
for id, stasjon in stasjoner.iterrows():
    print(stasjon)
    
kart = folium.Map(location=[59.9, 10.75], zoom_start=12)
for id, stasjon in stasjoner.iterrows():
    folium.CircleMarker(
        location=[stasjon.start_station_latitude, stasjon.start_station_longitude],
        popup=stasjon.start_station_name,
        fill=True
    ).add_to(kart)
kart.save("bysykkelkart.html")

stasjoner = data.loc[:, [
    "start_station_name",
    "start_station_lattude",  # FEIL: feil kolonnenavn gir som regel KeyError
    "start_station_longitude"]
   ].drop_duplicates()
