import pandas as pd

# data_jul = pd.read_csv("07.csv", parse_dates=["started_at", "ended_at"])
# data_aug = pd.read_csv("08.csv", parse_dates=["started_at", "ended_at"])
# data = pd.concat([data_jul, data_aug]).reset_index(drop=True)

filer = ["07.csv", "08.csv"]
data_ark = []
for fil in filer:
    ark = pd.read_csv(fil, parse_dates=["started_at", "ended_at"])
    data_ark.append(ark)
data = pd.concat(data_ark).reset_index(drop=True)


# Regn ut antall turer mellom hver start- og sluttstasjon
antall_turer = (
    data.groupby(["start_station_name", "end_station_name"])
    .size()
    .sort_values()
    .reset_index()
    .rename(columns={0: "num_trips"})
    .pivot_table(
        index="start_station_name",
        columns="end_station_name",
        values="num_trips",
        fill_value=0,
    )
)

